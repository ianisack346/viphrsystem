<?php
require_once __DIR__ . '/includes/auth.php';
$user = require_role(['hr', 'admin']);

$db = (new Database())->getConnection();
$body = json_body();

$employeeRef = str_field($body, 'employee_id');
$reviewPeriod = str_field($body, 'review_period');
$reviewDate = str_field($body, 'review_date');
$reviewer = str_field($body, 'reviewer');
$overallRating = str_field($body, 'overall_rating');
$overallScore = float_field($body, 'overall_score', 0);
$metrics = is_array($body['metrics'] ?? null) ? $body['metrics'] : [];
$status = enum_field($body, 'status', ['Draft', 'Completed', 'Pending Review', 'Approved'], 'Draft');
$nextReviewDate = str_field($body, 'next_review_date');

if (!$employeeRef || !$reviewPeriod || !is_valid_date($reviewDate) || !$overallRating) {
    json_error('Employee, review period, review date, and overall rating are required.', 400);
}

// The select's value can be an employee_code or a numeric id — resolve either.
if (ctype_digit($employeeRef)) {
    $stmt = $db->prepare('SELECT id FROM employees WHERE id = ? LIMIT 1');
} else {
    $stmt = $db->prepare('SELECT id FROM employees WHERE employee_code = ? LIMIT 1');
}
$stmt->execute([$employeeRef]);
$employee = $stmt->fetch();
if (!$employee) {
    json_error('Employee not found.', 404);
}

$stmt = $db->prepare(
    'INSERT INTO performance_reviews
        (employee_id, review_period, review_date, reviewer, quality_of_work, productivity, teamwork,
         communication, initiative, attendance_score, overall_rating, overall_score, strengths,
         improvement_areas, goals, comments, status, next_review_date, created_by)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
);
$stmt->execute([
    $employee['id'],
    $reviewPeriod,
    $reviewDate,
    $reviewer,
    int_field($metrics, 'quality_of_work', 0),
    int_field($metrics, 'productivity', 0),
    int_field($metrics, 'teamwork', 0),
    int_field($metrics, 'communication', 0),
    int_field($metrics, 'initiative', 0),
    int_field($metrics, 'attendance', 0),
    $overallRating,
    $overallScore,
    str_field($body, 'strengths', ''),
    str_field($body, 'improvement_areas', ''),
    str_field($body, 'goals', ''),
    str_field($body, 'comments', ''),
    $status,
    is_valid_date($nextReviewDate) ? $nextReviewDate : null,
    $user['id'],
]);
$id = (int)$db->lastInsertId();

log_audit($db, (int)$user['id'], 'performance_review_saved', 'performance', "Saved review #$id ($status)");
json_ok(['message' => 'Performance review saved', 'id' => $id], 201);
