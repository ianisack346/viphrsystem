<?php
require_once __DIR__ . '/includes/auth.php';
$user = require_role(['hr', 'admin']);

$db = (new Database())->getConnection();
$body = json_body();
$applicationId = int_field($body, 'application_id');

if (!$applicationId) {
    json_error('application_id is required.', 400);
}

$stmt = $db->prepare('SELECT id FROM rms_applications WHERE id = ? LIMIT 1');
$stmt->execute([$applicationId]);
if (!$stmt->fetch()) {
    json_error('Application not found.', 404);
}

$stmt = $db->prepare('DELETE FROM rms_applications WHERE id = ?');
$stmt->execute([$applicationId]);

log_audit($db, (int)$user['id'], 'application_deleted', 'recruitment', "Deleted application #$applicationId");
json_ok(['message' => 'Application deleted']);
