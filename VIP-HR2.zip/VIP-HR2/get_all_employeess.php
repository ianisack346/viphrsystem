<?php
require_once __DIR__ . '/includes/auth.php';
require_role(['hr', 'admin', 'manager']);

$db = (new Database())->getConnection();

$status = enum_field($_GET, 'status', ['Active', 'Inactive']);
$department = str_field($_GET, 'department');
$search = str_field($_GET, 'search');

$sql = "SELECT e.id, e.employee_code, e.firstname, e.lastname, e.email, e.phone,
               d.name AS department, e.position, e.status, e.date_hired
        FROM employees e
        LEFT JOIN departments d ON d.id = e.department_id
        WHERE 1=1";
$params = [];

if ($status) {
    $sql .= ' AND e.status = ?';
    $params[] = $status;
}
if ($department) {
    $sql .= ' AND d.name = ?';
    $params[] = $department;
}
if ($search) {
    $sql .= ' AND (e.firstname LIKE ? OR e.lastname LIKE ? OR e.employee_code LIKE ? OR e.email LIKE ?)';
    $like = "%$search%";
    array_push($params, $like, $like, $like, $like);
}
$sql .= ' ORDER BY e.firstname, e.lastname';

$stmt = $db->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

// Alias the primary key under every name different parts of the frontend
// expect (employee_id, staff_profile_id, role) without changing the DB schema.
$employees = array_map(function ($r) {
    return [
        'id' => (int)$r['id'],
        'employee_id' => (int)$r['id'],
        'staff_profile_id' => (int)$r['id'],
        'employee_code' => $r['employee_code'],
        'firstname' => $r['firstname'],
        'lastname' => $r['lastname'],
        'email' => $r['email'],
        'phone' => $r['phone'],
        'department' => $r['department'],
        'position' => $r['position'],
        'role' => $r['position'],
        'status' => $r['status'],
        'date_hired' => $r['date_hired'],
    ];
}, $rows);

json_ok(['employees' => $employees]);
