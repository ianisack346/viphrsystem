<?php
require_once __DIR__ . '/includes/auth.php';
require_role(['hr', 'admin']);

$db = (new Database())->getConnection();
$limit = min(50, max(1, int_field($_GET, 'limit', 10)));

$stmt = $db->prepare(
    "SELECT action_type AS type, description, created_at FROM audit_logs ORDER BY created_at DESC LIMIT ?"
);
$stmt->bindValue(1, $limit, PDO::PARAM_INT);
$stmt->execute();

// Frontend expects a bare JSON array for this one.
http_response_code(200);
echo json_encode($stmt->fetchAll(), JSON_UNESCAPED_SLASHES);
