<?php
require_once __DIR__ . '/includes/auth.php';
require_role(['hr', 'admin']);

$db = (new Database())->getConnection();
[$offset, $limit] = paginate(100, 500);

$stmt = $db->prepare(
    "SELECT e.employee_code, e.firstname AS first_name, e.lastname AS last_name,
            d.name AS department, ar.date, ar.check_in_time, ar.check_out_time,
            CASE WHEN ar.check_in_time IS NOT NULL AND ar.check_out_time IS NOT NULL
                 THEN TIME_FORMAT(TIMEDIFF(ar.check_out_time, ar.check_in_time), '%H:%i')
                 ELSE NULL END AS duration
     FROM attendance_records ar
     JOIN employees e ON e.id = ar.employee_id
     LEFT JOIN departments d ON d.id = e.department_id
     ORDER BY ar.date DESC, e.firstname
     LIMIT ? OFFSET ?"
);
$stmt->bindValue(1, $limit, PDO::PARAM_INT);
$stmt->bindValue(2, $offset, PDO::PARAM_INT);
$stmt->execute();

http_response_code(200);
echo json_encode($stmt->fetchAll(), JSON_UNESCAPED_SLASHES);
