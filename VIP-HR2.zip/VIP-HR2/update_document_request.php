<?php
require_once __DIR__ . '/includes/auth.php';
$user = require_role(['hr', 'admin']);

$db = (new Database())->getConnection();
$body = json_body();

$id = int_field($body, 'request_id');
$status = enum_field($body, 'status', ['approved', 'denied', 'completed']);
$response = str_field($body, 'hr_response', '');

if (!$id || !$status) {
    json_error('request_id and a valid status are required.', 400);
}

$stmt = $db->prepare('SELECT id FROM document_requests WHERE id = ? LIMIT 1');
$stmt->execute([$id]);
if (!$stmt->fetch()) {
    json_error('Request not found.', 404);
}

if ($status === 'completed') {
    $stmt = $db->prepare('UPDATE document_requests SET status = ?, hr_response = ?, completed_date = NOW() WHERE id = ?');
} else {
    $stmt = $db->prepare('UPDATE document_requests SET status = ?, hr_response = ? WHERE id = ?');
}
$stmt->execute([$status, $response, $id]);

log_audit($db, (int)$user['id'], 'document_request_updated', 'documents', "Request #$id → $status");
json_ok(['message' => 'Request updated']);
