<?php
require_once __DIR__ . '/includes/auth.php';
$user = require_role(['hr', 'admin']);

$db = (new Database())->getConnection();
$body = json_body();
$id = int_field($body, 'document_id');
if (!$id) {
    json_error('document_id is required.', 400);
}

$stmt = $db->prepare('SELECT id, title FROM documents WHERE id = ? AND deleted_at IS NULL LIMIT 1');
$stmt->execute([$id]);
$doc = $stmt->fetch();
if (!$doc) {
    json_error('Document not found.', 404);
}

// Soft delete: keep the file + row for audit/compliance, just hide it.
$stmt = $db->prepare('UPDATE documents SET deleted_at = NOW(), status = "archived" WHERE id = ?');
$stmt->execute([$id]);

log_audit($db, (int)$user['id'], 'document_deleted', 'documents', "Deleted document \"{$doc['title']}\" (#$id)");
json_ok(['message' => 'Document deleted']);
