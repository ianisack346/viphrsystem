<?php
require_once __DIR__ . '/includes/auth.php';
require_role(['hr', 'admin']);

$db = (new Database())->getConnection();
$status = enum_field($_GET, 'status', ['pending', 'approved', 'rejected']);

$sql = "SELECT lr.leave_id, e.employee_code, e.id AS employee_id, e.firstname AS first_name,
               e.lastname AS last_name, d.name AS department, lr.leave_type, lr.start_date,
               lr.end_date, lr.days, lr.status, lr.reason, lr.admin_notes,
               lr.proof_document, lr.proof_name, lr.proof_uploaded_at, lr.proof_status,
               lr.attachment, lr.attachment_name, lr.created_at
        FROM leave_requests lr
        JOIN employees e ON e.id = lr.employee_id
        LEFT JOIN departments d ON d.id = e.department_id";
$params = [];
if ($status) {
    $sql .= ' WHERE lr.status = ?';
    $params[] = $status;
}
$sql .= ' ORDER BY lr.created_at DESC';

$stmt = $db->prepare($sql);
$stmt->execute($params);

http_response_code(200);
echo json_encode($stmt->fetchAll(), JSON_UNESCAPED_SLASHES);
