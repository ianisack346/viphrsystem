-- FortishieldMatrix HR — full schema
-- MariaDB 10.4+ / MySQL 8+. InnoDB, utf8mb4 throughout.

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ============================================================
-- Core: departments, employees, HR login accounts
-- ============================================================

CREATE TABLE IF NOT EXISTS departments (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    code VARCHAR(20) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS employees (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    employee_code VARCHAR(30) NOT NULL UNIQUE,   -- e.g. 2025/HR/0001
    firstname VARCHAR(80) NOT NULL,
    lastname VARCHAR(80) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    phone VARCHAR(30) NULL,
    department_id INT UNSIGNED NULL,
    position VARCHAR(100) NULL,                  -- shown as "role" on the frontend
    status ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
    date_hired DATE NULL,
    basic_salary DECIMAL(14,2) NULL,
    profile_photo VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL,
    INDEX idx_emp_status (status),
    INDEX idx_emp_dept (department_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS hr_users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    employee_id INT UNSIGNED NULL,
    username VARCHAR(60) NOT NULL UNIQUE,
    email VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('admin','hr','manager','employee') NOT NULL DEFAULT 'hr',
    full_name VARCHAR(150) NOT NULL,
    profile_photo VARCHAR(255) NULL,
    hr_code VARCHAR(30) NULL,                     -- HR's own attendance code, e.g. 2025/HR/0001
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    last_login TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Leave management
-- ============================================================

CREATE TABLE IF NOT EXISTS leave_requests (
    leave_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    employee_id INT UNSIGNED NOT NULL,
    leave_type VARCHAR(50) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    days INT UNSIGNED NOT NULL,
    reason TEXT NULL,
    status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
    admin_notes TEXT NULL,
    proof_document VARCHAR(255) NULL,
    proof_name VARCHAR(255) NULL,
    proof_uploaded_at TIMESTAMP NULL,
    proof_status ENUM('pending','submitted','verified') NULL,
    attachment VARCHAR(255) NULL,
    attachment_name VARCHAR(255) NULL,
    approved_by INT UNSIGNED NULL,
    approved_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    FOREIGN KEY (approved_by) REFERENCES hr_users(id) ON DELETE SET NULL,
    INDEX idx_leave_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- HR's own leave ("My Leave" in the sidebar) — separate ledger tied to hr_users
CREATE TABLE IF NOT EXISTS hr_leave_requests (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    hr_user_id INT UNSIGNED NOT NULL,
    leave_type VARCHAR(50) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    days INT UNSIGNED NOT NULL,
    reason TEXT NULL,
    status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (hr_user_id) REFERENCES hr_users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Attendance
-- ============================================================

CREATE TABLE IF NOT EXISTS attendance_records (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    employee_id INT UNSIGNED NOT NULL,
    date DATE NOT NULL,
    check_in_time TIME NULL,
    check_out_time TIME NULL,
    status ENUM('present','present_late','late','absent') NOT NULL,
    reason TEXT NULL,
    latitude DECIMAL(10,7) NULL,
    longitude DECIMAL(10,7) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    UNIQUE KEY uniq_emp_date (employee_id, date),
    INDEX idx_att_date (date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- HR's own attendance ("Attendance Surf" / "Time Book")
CREATE TABLE IF NOT EXISTS hr_attendance (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    hr_user_id INT UNSIGNED NOT NULL,
    date DATE NOT NULL,
    check_in_time TIME NULL,
    check_out_time TIME NULL,
    status ENUM('present','present_late','late','absent') NOT NULL,
    reason TEXT NULL,
    latitude DECIMAL(10,7) NULL,
    longitude DECIMAL(10,7) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (hr_user_id) REFERENCES hr_users(id) ON DELETE CASCADE,
    UNIQUE KEY uniq_hr_date (hr_user_id, date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Performance
-- ============================================================

CREATE TABLE IF NOT EXISTS performance_reviews (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    employee_id INT UNSIGNED NOT NULL,
    review_period VARCHAR(30) NOT NULL,
    review_date DATE NOT NULL,
    reviewer VARCHAR(150) NULL,
    quality_of_work TINYINT UNSIGNED NULL,
    productivity TINYINT UNSIGNED NULL,
    teamwork TINYINT UNSIGNED NULL,
    communication TINYINT UNSIGNED NULL,
    initiative TINYINT UNSIGNED NULL,
    attendance_score TINYINT UNSIGNED NULL,
    overall_rating VARCHAR(30) NULL,
    overall_score DECIMAL(4,2) NULL,
    strengths TEXT NULL,
    improvement_areas TEXT NULL,
    goals TEXT NULL,
    comments TEXT NULL,
    status ENUM('Draft','Completed','Pending Review','Approved') NOT NULL DEFAULT 'Draft',
    next_review_date DATE NULL,
    created_by INT UNSIGNED NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES hr_users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Training
-- ============================================================

CREATE TABLE IF NOT EXISTS trainings (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    type VARCHAR(50) NULL,
    description TEXT NULL,
    start_date DATETIME NOT NULL,
    end_date DATETIME NOT NULL,
    duration INT UNSIGNED NULL,
    max_participants INT UNSIGNED NULL,
    current_participants INT UNSIGNED NOT NULL DEFAULT 0,
    format VARCHAR(30) NULL,
    location VARCHAR(255) NULL,
    virtual_details TEXT NULL,
    trainer_name VARCHAR(150) NULL,
    trainer_email VARCHAR(150) NULL,
    trainer_bio TEXT NULL,
    target_audience VARCHAR(50) NULL,
    target_department_id INT UNSIGNED NULL,
    prerequisites TEXT NULL,
    materials_needed TEXT NULL,
    objectives TEXT NULL,
    cost_per_participant DECIMAL(12,2) NULL DEFAULT 0,
    total_budget DECIMAL(12,2) NULL DEFAULT 0,
    budget_code VARCHAR(50) NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'Draft',
    certificate_available TINYINT(1) NOT NULL DEFAULT 0,
    mandatory TINYINT(1) NOT NULL DEFAULT 0,
    send_notifications TINYINT(1) NOT NULL DEFAULT 0,
    created_by INT UNSIGNED NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (target_department_id) REFERENCES departments(id) ON DELETE SET NULL,
    FOREIGN KEY (created_by) REFERENCES hr_users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS training_participants (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    training_id INT UNSIGNED NOT NULL,
    employee_id INT UNSIGNED NOT NULL,
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (training_id) REFERENCES trainings(id) ON DELETE CASCADE,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    UNIQUE KEY uniq_training_emp (training_id, employee_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Recruitment — job postings (HR side) + RMS applications (candidate side)
-- ============================================================

CREATE TABLE IF NOT EXISTS recruitment_vacancies (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    position_title VARCHAR(150) NOT NULL,
    department_id INT UNSIGNED NULL,
    job_description TEXT NULL,
    job_requirements TEXT NULL,
    closing_date DATE NOT NULL,
    priority ENUM('Low','Medium','High','Urgent') NOT NULL DEFAULT 'Medium',
    employment_type VARCHAR(30) NULL,
    min_qualification VARCHAR(30) NULL,
    experience_years TINYINT UNSIGNED NOT NULL DEFAULT 0,
    num_posts SMALLINT UNSIGNED NOT NULL DEFAULT 1,
    location VARCHAR(150) NULL,
    salary_min DECIMAL(14,2) NULL,
    salary_max DECIMAL(14,2) NULL,
    salary_grade VARCHAR(50) NULL,
    internal_notes TEXT NULL,
    status ENUM('open','closed') NOT NULL DEFAULT 'open',
    posted_by INT UNSIGNED NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL,
    FOREIGN KEY (posted_by) REFERENCES hr_users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS rms_candidates (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(80) NOT NULL,
    last_name VARCHAR(80) NOT NULL,
    email VARCHAR(150) NOT NULL,
    phone VARCHAR(30) NULL,
    nin VARCHAR(30) NULL,
    date_of_birth DATE NULL,
    region VARCHAR(80) NULL,
    district VARCHAR(80) NULL,
    ward VARCHAR(80) NULL,
    village VARCHAR(80) NULL,
    address VARCHAR(255) NULL,
    disability_status VARCHAR(50) NULL,
    profession VARCHAR(100) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS rms_applications (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,               -- FK -> rms_candidates.id
    vacancy_id INT UNSIGNED NOT NULL,
    reference_number VARCHAR(40) NOT NULL UNIQUE,
    submission_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('pending','under_review','shortlisted','interview','approved','rejected') NOT NULL DEFAULT 'pending',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES rms_candidates(id) ON DELETE CASCADE,
    FOREIGN KEY (vacancy_id) REFERENCES recruitment_vacancies(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS rms_documents (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    application_id INT UNSIGNED NOT NULL,
    doc_type VARCHAR(50) NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(255) NOT NULL,
    file_size INT UNSIGNED NOT NULL DEFAULT 0,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (application_id) REFERENCES rms_applications(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS rms_education (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    application_id INT UNSIGNED NOT NULL,
    field_key VARCHAR(80) NOT NULL,
    field_value VARCHAR(255) NOT NULL,
    FOREIGN KEY (application_id) REFERENCES rms_applications(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS rms_status_tracker (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    application_id INT UNSIGNED NOT NULL,
    step_name VARCHAR(80) NOT NULL,
    step_status ENUM('pending','completed') NOT NULL DEFAULT 'pending',
    step_date DATE NULL,
    description VARCHAR(255) NULL,
    FOREIGN KEY (application_id) REFERENCES rms_applications(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Documents
-- ============================================================

CREATE TABLE IF NOT EXISTS documents (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT NULL,
    document_type VARCHAR(50) NOT NULL,
    department_id INT UNSIGNED NULL,
    employee_id INT UNSIGNED NULL,
    file_name VARCHAR(255) NOT NULL,
    stored_name VARCHAR(255) NOT NULL,
    file_type VARCHAR(20) NULL,
    file_size INT UNSIGNED NOT NULL DEFAULT 0,
    access_level ENUM('private','department','public') NOT NULL DEFAULT 'private',
    expiry_date DATE NULL,
    status ENUM('active','archived','pending') NOT NULL DEFAULT 'active',
    version_count INT UNSIGNED NOT NULL DEFAULT 1,
    uploaded_by INT UNSIGNED NULL,
    upload_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    download_count INT UNSIGNED NOT NULL DEFAULT 0,
    deleted_at TIMESTAMP NULL,
    FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE SET NULL,
    FOREIGN KEY (uploaded_by) REFERENCES hr_users(id) ON DELETE SET NULL,
    INDEX idx_doc_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS document_requests (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    employee_id INT UNSIGNED NOT NULL,
    document_type VARCHAR(100) NOT NULL,
    reason TEXT NULL,
    urgency ENUM('normal','urgent','immediate') NOT NULL DEFAULT 'normal',
    status ENUM('pending','approved','denied','completed') NOT NULL DEFAULT 'pending',
    hr_response TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_date TIMESTAMP NULL,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS generated_documents (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    employee_id INT UNSIGNED NOT NULL,
    template VARCHAR(30) NOT NULL,
    content LONGTEXT NOT NULL,
    generated_by INT UNSIGNED NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    FOREIGN KEY (generated_by) REFERENCES hr_users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Meetings
-- ============================================================

CREATE TABLE IF NOT EXISTS meetings (
    meeting_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    subject VARCHAR(255) NULL,
    objectives TEXT NULL,
    meeting_date DATE NOT NULL,
    start_time TIME NULL,
    end_time TIME NULL,
    scope ENUM('all','department','managers','specific') NOT NULL DEFAULT 'department',
    department_id INT UNSIGNED NULL,
    location VARCHAR(255) NULL,
    notes TEXT NULL,
    status ENUM('scheduled','completed','cancelled') NOT NULL DEFAULT 'scheduled',
    created_by INT UNSIGNED NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL,
    FOREIGN KEY (created_by) REFERENCES hr_users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS meeting_attendees (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    meeting_id INT UNSIGNED NOT NULL,
    employee_id INT UNSIGNED NOT NULL,
    FOREIGN KEY (meeting_id) REFERENCES meetings(meeting_id) ON DELETE CASCADE,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    UNIQUE KEY uniq_meeting_emp (meeting_id, employee_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Announcements
-- ============================================================

CREATE TABLE IF NOT EXISTS announcements (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    audience ENUM('all','role','department','specific') NOT NULL DEFAULT 'all',
    target_role VARCHAR(30) NULL,
    target_department_id INT UNSIGNED NULL,
    target_user_ids TEXT NULL, -- comma-separated employee ids when audience = specific
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    posted_by INT UNSIGNED NULL,
    date_posted TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (target_department_id) REFERENCES departments(id) ON DELETE SET NULL,
    FOREIGN KEY (posted_by) REFERENCES hr_users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Payroll
-- ============================================================

CREATE TABLE IF NOT EXISTS payroll (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    employee_id INT UNSIGNED NOT NULL,
    pay_period VARCHAR(10) NOT NULL, -- YYYY-MM
    basic_salary DECIMAL(14,2) NOT NULL,
    allowances DECIMAL(14,2) NOT NULL DEFAULT 0,
    tax DECIMAL(14,2) NOT NULL DEFAULT 0,
    insurance DECIMAL(14,2) NOT NULL DEFAULT 0,
    other_deductions DECIMAL(14,2) NOT NULL DEFAULT 0,
    net_salary DECIMAL(14,2) NOT NULL,
    status ENUM('pending','approved','denied','processing','paid') NOT NULL DEFAULT 'pending',
    payment_date DATE NULL,
    processed_by INT UNSIGNED NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    FOREIGN KEY (processed_by) REFERENCES hr_users(id) ON DELETE SET NULL,
    UNIQUE KEY uniq_emp_period (employee_id, pay_period)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Events (dashboard widget)
-- ============================================================

CREATE TABLE IF NOT EXISTS company_events (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    event_date DATE NOT NULL,
    location VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Settings & audit
-- ============================================================

CREATE TABLE IF NOT EXISTS system_settings (
    setting_key VARCHAR(80) PRIMARY KEY,
    setting_value TEXT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS audit_logs (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    action_type VARCHAR(60) NOT NULL,
    module VARCHAR(60) NULL,
    description TEXT NULL,
    hr_user_id INT UNSIGNED NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (hr_user_id) REFERENCES hr_users(id) ON DELETE SET NULL,
    INDEX idx_audit_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================
-- Seed data (safe to re-run — INSERT IGNORE)
-- ============================================================

INSERT IGNORE INTO departments (id, name, code) VALUES
 (1,'Human Resources','HR'), (2,'Information Technology','IT'), (3,'Finance','FIN'),
 (4,'Marketing','MKT'), (5,'Security','SEC'), (6,'Operations','OPS'),
 (7,'Sales','SLS'), (8,'Administration','ADM');

-- Example HR login (CHANGE THIS PASSWORD IMMEDIATELY — this hash is for 'ChangeMe123!')
-- INSERT IGNORE INTO hr_users (username, email, password_hash, role, full_name, hr_code)
-- VALUES ('hr.admin', 'hr@fortishieldmatrix.co.tz', '$2y$10$replace_with_password_hash', 'hr', 'HR Manager', '2025/HR/0001');
