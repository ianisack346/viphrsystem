<?php
require_once __DIR__ . '/includes/auth.php';
require_role(['hr', 'admin']);

$db = (new Database())->getConnection();
[$offset, $limit] = paginate(100, 500);

$stmt = $db->prepare(
    "SELECT al.id, al.action_type, al.module, al.description, al.created_at,
            COALESCE(hu.full_name, 'System') AS hr_name
     FROM audit_logs al
     LEFT JOIN hr_users hu ON hu.id = al.hr_user_id
     ORDER BY al.created_at DESC
     LIMIT ? OFFSET ?"
);
$stmt->bindValue(1, $limit, PDO::PARAM_INT);
$stmt->bindValue(2, $offset, PDO::PARAM_INT);
$stmt->execute();

json_ok(['logs' => $stmt->fetchAll()]);
