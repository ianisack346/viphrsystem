<?php
require_once __DIR__ . '/includes/auth.php';
$user = require_role(['hr', 'admin']);

$db = (new Database())->getConnection();

$title = str_field($_POST, 'title');
$message = str_field($_POST, 'message');
$audience = enum_field($_POST, 'audience', ['all', 'role', 'department', 'specific'], 'all');

if (!$title || !$message) {
    json_error('Title and message are required.', 400);
}

$targetRole = $audience === 'role' ? enum_field($_POST, 'target_role', ['employee', 'cso', 'admin', 'dept_manager']) : null;
$targetDepartmentId = $audience === 'department' ? int_field($_POST, 'target_department_id') : null;
$targetUserIds = null;
if ($audience === 'specific') {
    $raw = str_field($_POST, 'user_ids', '');
    $ids = array_filter(array_map('intval', explode(',', $raw)));
    $targetUserIds = $ids ? implode(',', $ids) : null;
}

$stmt = $db->prepare(
    'INSERT INTO announcements (title, message, audience, target_role, target_department_id, target_user_ids, status, posted_by)
     VALUES (?, ?, ?, ?, ?, ?, "active", ?)'
);
$stmt->execute([$title, $message, $audience, $targetRole, $targetDepartmentId, $targetUserIds, $user['id']]);
$id = (int)$db->lastInsertId();

log_audit($db, (int)$user['id'], 'announcement_created', 'announcements', "Posted \"$title\"");
json_ok(['message' => 'Announcement created', 'id' => $id], 201);
