<?php
require_once __DIR__ . '/includes/auth.php';
require_role(['hr', 'admin']);

$db = (new Database())->getConnection();
$applicationId = int_field($_GET, 'application_id');
if (!$applicationId) {
    json_error('application_id is required.', 400);
}

$stmt = $db->prepare(
    "SELECT a.*, c.first_name, c.last_name, c.email, c.phone, c.nin, c.date_of_birth,
            c.region, c.district, c.ward, c.village, c.address, c.disability_status, c.profession,
            v.position_title, v.reference_number AS vacancy_ref
     FROM rms_applications a
     JOIN rms_candidates c ON c.id = a.user_id
     JOIN recruitment_vacancies v ON v.id = a.vacancy_id
     WHERE a.id = ?"
);
$stmt->execute([$applicationId]);
$application = $stmt->fetch();

if (!$application) {
    json_error('Application not found.', 404);
}

$stmt = $db->prepare('SELECT * FROM rms_education WHERE application_id = ? ORDER BY id');
$stmt->execute([$applicationId]);
$education = $stmt->fetchAll();

$stmt = $db->prepare('SELECT * FROM rms_documents WHERE application_id = ? ORDER BY doc_type');
$stmt->execute([$applicationId]);
$documents = $stmt->fetchAll();

$stmt = $db->prepare('SELECT * FROM rms_status_tracker WHERE application_id = ? ORDER BY id');
$stmt->execute([$applicationId]);
$statusTracker = $stmt->fetchAll();

json_ok([
    'application' => $application,
    'education' => $education,
    'documents' => $documents,
    'status_tracker' => $statusTracker,
]);
