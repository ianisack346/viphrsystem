<?php
require_once __DIR__ . '/includes/auth.php';
$user = require_role(['hr', 'admin']);

$db = (new Database())->getConnection();
$body = json_body();

$employeeCode = str_field($body, 'employee_id'); // text code typed into the form
$leaveType = str_field($body, 'leave_type');
$startDate = str_field($body, 'start_date');
$endDate = str_field($body, 'end_date');
$reason = str_field($body, 'reason', '');

if (!$employeeCode || !$leaveType || !is_valid_date($startDate) || !is_valid_date($endDate)) {
    json_error('Employee code, leave type, and valid start/end dates are required.', 400);
}
if ($endDate < $startDate) {
    json_error('End date must be on or after the start date.', 400);
}

$stmt = $db->prepare('SELECT id FROM employees WHERE employee_code = ? LIMIT 1');
$stmt->execute([$employeeCode]);
$employee = $stmt->fetch();
if (!$employee) {
    json_error('No employee found with that code.', 404);
}

$days = (new DateTime($startDate))->diff(new DateTime($endDate))->days + 1;

$stmt = $db->prepare(
    'INSERT INTO leave_requests (employee_id, leave_type, start_date, end_date, days, reason, status)
     VALUES (?, ?, ?, ?, ?, ?, "pending")'
);
$stmt->execute([$employee['id'], $leaveType, $startDate, $endDate, $days, $reason]);
$leaveId = (int)$db->lastInsertId();

log_audit($db, (int)$user['id'], 'leave_created', 'leave', "Created leave request #$leaveId for employee $employeeCode");

json_ok(['message' => 'Leave request created', 'leave_id' => $leaveId], 201);
