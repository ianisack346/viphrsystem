<?php
require_once __DIR__ . '/includes/auth.php';
require_role(['hr', 'admin', 'manager']);

$db = (new Database())->getConnection();
$departments = $db->query('SELECT id, name, code FROM departments ORDER BY name')->fetchAll();

json_ok(['departments' => $departments]);
