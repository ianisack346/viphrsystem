﻿<?php
$hash = '$2y$10$NUUb.AS5/beJRNYZN/mYD.y17ib8mqi1pePCCW0YWPy9SvXAVxglW';
$candidates = ['Test@1234', 'Test1234', 'test@1234', 'Admin@123', 'Password@123'];
foreach ($candidates as $p) {
    printf("%-15s => %s\n", $p, password_verify($p, $hash) ? 'MATCH' : 'no');
}
echo "Hash valid format: " . (password_get_info($hash)['algoName'] ?? 'unknown') . PHP_EOL;
