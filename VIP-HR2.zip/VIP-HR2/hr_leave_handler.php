<?php
require_once __DIR__ . '/includes/auth.php';
$user = require_login(); // any authenticated HR-side user can manage their own leave

$db = (new Database())->getConnection();
$method = $_SERVER['REQUEST_METHOD'];
$body = $method === 'POST' ? json_body() : [];
$action = $_GET['action'] ?? ($body['action'] ?? null);

const ANNUAL_ENTITLEMENT = 28;

if ($method === 'GET' && $action === 'list') {
    $status = enum_field($_GET, 'status', ['pending', 'approved', 'rejected']);
    $sql = 'SELECT id, leave_type, start_date, end_date, days, reason, status, created_at
            FROM hr_leave_requests WHERE hr_user_id = ?';
    $params = [$user['id']];
    if ($status) {
        $sql .= ' AND status = ?';
        $params[] = $status;
    }
    $sql .= ' ORDER BY created_at DESC';
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $leaves = $stmt->fetchAll();

    $taken = 0;
    $pending = 0;
    foreach ($leaves as $l) {
        if ($l['status'] === 'approved') {
            $taken += (int)$l['days'];
        }
        if ($l['status'] === 'pending') {
            $pending++;
        }
    }

    json_ok([
        'summary' => [
            'entitlement' => ANNUAL_ENTITLEMENT,
            'taken' => $taken,
            'remaining' => max(0, ANNUAL_ENTITLEMENT - $taken),
            'pending' => $pending,
        ],
        'leaves' => $leaves,
    ]);
}

if ($method === 'POST' && $action === 'request') {
    $leaveType = str_field($body, 'leave_type');
    $startDate = str_field($body, 'start_date');
    $endDate = str_field($body, 'end_date');
    $reason = str_field($body, 'reason');
    if (!$leaveType || !is_valid_date($startDate) || !is_valid_date($endDate) || !$reason) {
        json_error('All fields are required.', 400);
    }
    if ($endDate < $startDate) {
        json_error('End date must be on or after the start date.', 400);
    }
    $days = (new DateTime($startDate))->diff(new DateTime($endDate))->days + 1;

    $stmt = $db->prepare(
        'INSERT INTO hr_leave_requests (hr_user_id, leave_type, start_date, end_date, days, reason, status)
         VALUES (?, ?, ?, ?, ?, ?, "pending")'
    );
    $stmt->execute([$user['id'], $leaveType, $startDate, $endDate, $days, $reason]);
    log_audit($db, (int)$user['id'], 'hr_leave_requested', 'leave', 'Requested personal leave');
    json_ok(['message' => 'Leave request submitted'], 201);
}

if ($method === 'POST' && $action === 'cancel') {
    $leaveId = int_field($body, 'leave_id');
    if (!$leaveId) {
        json_error('leave_id is required.', 400);
    }
    $stmt = $db->prepare('SELECT id, status FROM hr_leave_requests WHERE id = ? AND hr_user_id = ?');
    $stmt->execute([$leaveId, $user['id']]);
    $row = $stmt->fetch();
    if (!$row) {
        json_error('Leave request not found.', 404);
    }
    if ($row['status'] === 'rejected') {
        json_error('This leave has already been rejected.', 409);
    }
    $stmt = $db->prepare('DELETE FROM hr_leave_requests WHERE id = ?');
    $stmt->execute([$leaveId]);
    log_audit($db, (int)$user['id'], 'hr_leave_cancelled', 'leave', "Cancelled personal leave #$leaveId");
    json_ok(['message' => 'Leave cancelled']);
}

json_error('Unsupported request.', 400);
