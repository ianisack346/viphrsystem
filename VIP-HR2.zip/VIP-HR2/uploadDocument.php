<?php
require_once __DIR__ . '/includes/auth.php';
$user = require_role(['hr', 'admin']);

$db = (new Database())->getConnection();

$title = str_field($_POST, 'title');
$docType = str_field($_POST, 'document_type');
if (!$title || !$docType) {
    json_error('Title and document type are required.', 400);
}
if (!isset($_FILES['document'])) {
    json_error('A file is required.', 400);
}

$uploaded = handle_secure_upload(
    $_FILES['document'],
    DOC_UPLOAD_DIR,
    ALLOWED_DOC_EXT,
    ALLOWED_DOC_MIME,
    MAX_UPLOAD_BYTES
);

$departmentId = int_field($_POST, 'department_id');
$accessLevel = enum_field($_POST, 'access_level', ['private', 'department', 'public'], 'private');
$expiryDate = str_field($_POST, 'expiry_date');
$expiryDate = is_valid_date($expiryDate) ? $expiryDate : null;

$stmt = $db->prepare(
    'INSERT INTO documents
        (title, description, document_type, department_id, file_name, stored_name, file_type,
         file_size, access_level, expiry_date, status, version_count, uploaded_by)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "active", 1, ?)'
);
$stmt->execute([
    $title,
    str_field($_POST, 'description', ''),
    $docType,
    $departmentId,
    $uploaded['file_name'],
    $uploaded['stored_name'],
    pathinfo($uploaded['file_name'], PATHINFO_EXTENSION),
    $uploaded['size'],
    $accessLevel,
    $expiryDate,
    $user['id'],
]);
$id = (int)$db->lastInsertId();

log_audit($db, (int)$user['id'], 'document_uploaded', 'documents', "Uploaded \"$title\"");
json_ok(['message' => 'Document uploaded', 'id' => $id], 201);
