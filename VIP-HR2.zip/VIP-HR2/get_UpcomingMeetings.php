<?php
require_once __DIR__ . '/includes/auth.php';
require_role(['hr', 'admin']);

$db = (new Database())->getConnection();
$limit = min(200, max(1, int_field($_GET, 'limit', 5)));

$stmt = $db->prepare(
    "SELECT m.meeting_id, m.title, m.subject, m.objectives, m.meeting_date, m.meeting_date AS date,
            m.start_time, m.end_time, m.start_time AS time, m.scope, d.name AS department_name, m.status
     FROM meetings m
     LEFT JOIN departments d ON d.id = m.department_id
     ORDER BY m.meeting_date DESC, m.start_time DESC
     LIMIT ?"
);
$stmt->bindValue(1, $limit, PDO::PARAM_INT);
$stmt->execute();

http_response_code(200);
echo json_encode($stmt->fetchAll(), JSON_UNESCAPED_SLASHES);
