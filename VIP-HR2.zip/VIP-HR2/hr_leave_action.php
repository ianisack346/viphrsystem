<?php
require_once __DIR__ . '/includes/auth.php';
$user = require_role(['hr', 'admin']);

$db = (new Database())->getConnection();
$body = json_body();

$action = enum_field($body, 'action', ['approve', 'reject']);
$leaveId = int_field($body, 'leave_id');
if (!$action || !$leaveId) {
    json_error('Action and leave_id are required.', 400);
}

$stmt = $db->prepare('SELECT * FROM leave_requests WHERE leave_id = ? LIMIT 1');
$stmt->execute([$leaveId]);
$leave = $stmt->fetch();
if (!$leave) {
    json_error('Leave request not found.', 404);
}
if ($leave['status'] !== 'pending') {
    json_error('This leave request has already been processed.', 409);
}

if ($action === 'approve') {
    $comment = str_field($body, 'comment', '');
    $stmt = $db->prepare(
        "UPDATE leave_requests SET status='approved', admin_notes=?, approved_by=?, approved_at=NOW(),
         proof_status = IF(leave_type LIKE 'Sick%', 'pending', proof_status) WHERE leave_id = ?"
    );
    $stmt->execute([$comment, $user['id'], $leaveId]);
    log_audit($db, (int)$user['id'], 'leave_approved', 'leave', "Approved leave #$leaveId");
    json_ok(['message' => 'Leave approved']);
}

// reject
$reason = str_field($body, 'reason');
if (!$reason) {
    json_error('A reason is required to reject a leave request.', 400);
}
$stmt = $db->prepare(
    "UPDATE leave_requests SET status='rejected', admin_notes=?, approved_by=?, approved_at=NOW() WHERE leave_id = ?"
);
$stmt->execute([$reason, $user['id'], $leaveId]);
log_audit($db, (int)$user['id'], 'leave_rejected', 'leave', "Rejected leave #$leaveId: $reason");
json_ok(['message' => 'Leave rejected']);
