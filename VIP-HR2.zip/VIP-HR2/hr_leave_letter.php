<?php
require_once __DIR__ . '/includes/auth.php';
$user = require_role(['hr', 'admin']);

$db = (new Database())->getConnection();
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? (json_body()['action'] ?? null);

function fetch_leave_with_employee(PDO $db, int $leaveId): ?array
{
    $stmt = $db->prepare(
        'SELECT lr.*, e.firstname, e.lastname, e.email, e.employee_code
         FROM leave_requests lr JOIN employees e ON e.id = lr.employee_id
         WHERE lr.leave_id = ? LIMIT 1'
    );
    $stmt->execute([$leaveId]);
    $row = $stmt->fetch();
    return $row ?: null;
}

function build_letter_html(array $leave): string
{
    $name = h($leave['firstname'] . ' ' . $leave['lastname']);
    $decision = $leave['status'] === 'approved' ? 'approved' : 'declined';
    $decisionColor = $leave['status'] === 'approved' ? '#2ecc71' : '#e74c3c';
    $date = date('F j, Y');
    $notes = $leave['admin_notes'] ? '<p><strong>Notes:</strong> ' . h($leave['admin_notes']) . '</p>' : '';
    return "
        <div style='padding:24px;font-family:sans-serif;color:#2c3e50;'>
            <h3>FortishieldMatrix — Leave Request Decision</h3>
            <p>Date: $date</p>
            <p>Dear $name,</p>
            <p>Your " . h($leave['leave_type']) . " request from " . h($leave['start_date']) . " to " . h($leave['end_date']) .
            " (" . (int)$leave['days'] . " day(s)) has been
            <strong style='color:$decisionColor'>$decision</strong>.</p>
            $notes
            <p>Regards,<br>Human Resources</p>
        </div>";
}

if ($method === 'GET' && $action === 'preview') {
    $leaveId = int_field($_GET, 'leave_id');
    if (!$leaveId) {
        json_error('leave_id is required.', 400);
    }
    $leave = fetch_leave_with_employee($db, $leaveId);
    if (!$leave) {
        json_error('Leave request not found.', 404);
    }
    if ($leave['status'] === 'pending') {
        json_error('This leave request has not been decided yet.', 409);
    }
    json_ok(['letter' => build_letter_html($leave)]);
}

if ($method === 'POST') {
    $body = json_body();
    $leaveId = int_field($body, 'leave_id');
    $method2 = enum_field($body, 'method', ['email', 'portal', 'both'], 'both');
    if (!$leaveId) {
        json_error('leave_id is required.', 400);
    }
    $leave = fetch_leave_with_employee($db, $leaveId);
    if (!$leave) {
        json_error('Leave request not found.', 404);
    }

    $letter = build_letter_html($leave);

    if (in_array($method2, ['email', 'both'], true)) {
        // Wire up to your real mailer (PHPMailer/SMTP) here. We don't fail
        // the whole request if mail isn't configured — we log instead.
        $sent = @mail($leave['email'], 'Your leave request decision', strip_tags($letter));
        if (!$sent) {
            error_log("[LEAVE LETTER] mail() failed for leave #$leaveId to {$leave['email']}");
        }
    }
    if (in_array($method2, ['portal', 'both'], true)) {
        // Store a generated-document record the employee portal can read.
        $stmt = $db->prepare(
            'INSERT INTO generated_documents (employee_id, template, content, generated_by) VALUES (?, "leave_letter", ?, ?)'
        );
        $stmt->execute([$leave['employee_id'], $letter, $user['id']]);
    }

    log_audit($db, (int)$user['id'], 'leave_letter_sent', 'leave', "Sent leave letter for #$leaveId via $method2");
    json_ok(['message' => 'Letter sent']);
}

json_error('Unsupported request.', 400);
