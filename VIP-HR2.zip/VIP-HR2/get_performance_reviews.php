<?php
require_once __DIR__ . '/includes/auth.php';
require_role(['hr', 'admin']);

$db = (new Database())->getConnection();
[$offset, $limit] = paginate(100, 500);

$stmt = $db->prepare(
    "SELECT pr.id, CONCAT(e.firstname, ' ', e.lastname) AS employee_name,
            pr.review_period, pr.review_date, pr.overall_score, pr.status
     FROM performance_reviews pr
     JOIN employees e ON e.id = pr.employee_id
     ORDER BY pr.review_date DESC
     LIMIT ? OFFSET ?"
);
$stmt->bindValue(1, $limit, PDO::PARAM_INT);
$stmt->bindValue(2, $offset, PDO::PARAM_INT);
$stmt->execute();

json_ok(['reviews' => $stmt->fetchAll()]);
