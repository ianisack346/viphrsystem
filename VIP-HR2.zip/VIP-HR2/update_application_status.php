<?php
require_once __DIR__ . '/includes/auth.php';
$user = require_role(['hr', 'admin']);

$db = (new Database())->getConnection();
$body = json_body();

$applicationId = int_field($body, 'application_id');
$status = enum_field($body, 'status', ['under_review', 'shortlisted', 'interview', 'approved', 'rejected']);
$stepName = str_field($body, 'step_name');
$stepStatus = enum_field($body, 'step_status', ['pending', 'completed'], 'completed');
$description = str_field($body, 'description', '');

if (!$applicationId) {
    json_error('application_id is required.', 400);
}

$stmt = $db->prepare('SELECT id FROM rms_applications WHERE id = ? LIMIT 1');
$stmt->execute([$applicationId]);
if (!$stmt->fetch()) {
    json_error('Application not found.', 404);
}

$db->beginTransaction();
try {
    if ($status) {
        $stmt = $db->prepare('UPDATE rms_applications SET status = ?, updated_at = NOW() WHERE id = ?');
        $stmt->execute([$status, $applicationId]);
    }
    if ($stepName) {
        $stmt = $db->prepare(
            'UPDATE rms_status_tracker SET step_status = ?, step_date = CURDATE(), description = ?
             WHERE application_id = ? AND step_name = ?'
        );
        $stmt->execute([$stepStatus, $description, $applicationId, $stepName]);
    }
    $db->commit();
} catch (Throwable $e) {
    $db->rollBack();
    error_log('[APPLICATION STATUS] ' . $e->getMessage());
    json_error('Could not update application.', 500);
}

log_audit(
    $db,
    (int)$user['id'],
    'application_status_updated',
    'recruitment',
    "Application #$applicationId" . ($status ? " → $status" : '') . ($stepName ? "; stage \"$stepName\" → $stepStatus" : '')
);

json_ok(['message' => 'Status updated successfully']);
