<?php
require_once __DIR__ . '/includes/auth.php';
require_role(['hr', 'admin']);

$db = (new Database())->getConnection();
$id = int_field($_GET, 'id');
if (!$id) {
    json_error('id is required.', 400);
}

$stmt = $db->prepare('SELECT stored_name, file_name FROM documents WHERE id = ? AND deleted_at IS NULL LIMIT 1');
$stmt->execute([$id]);
$doc = $stmt->fetch();
if (!$doc) {
    json_error('Document not found.', 404);
}

// stored_name is always our own random hex+extension — never derived from
// user input — so this is safe against path traversal.
$path = DOC_UPLOAD_DIR . '/' . basename($doc['stored_name']);
if (!is_file($path)) {
    json_error('File is missing from storage.', 404);
}

$db->prepare('UPDATE documents SET download_count = download_count + 1 WHERE id = ?')->execute([$id]);

header_remove('Content-Type');
header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . basename($doc['file_name']) . '"');
header('Content-Length: ' . filesize($path));
header('X-Content-Type-Options: nosniff');
readfile($path);
exit;
