<?php
require_once __DIR__ . '/includes/auth.php';
require_role(['hr', 'admin']);

$db = (new Database())->getConnection();
$limit = min(20, max(1, int_field($_GET, 'limit', 5)));

$stmt = $db->prepare(
    "SELECT title, start_date, trainer_name AS trainer
     FROM trainings
     WHERE start_date >= NOW() AND status NOT IN ('Cancelled','Completed')
     ORDER BY start_date ASC
     LIMIT ?"
);
$stmt->bindValue(1, $limit, PDO::PARAM_INT);
$stmt->execute();

http_response_code(200);
echo json_encode($stmt->fetchAll(), JSON_UNESCAPED_SLASHES);
