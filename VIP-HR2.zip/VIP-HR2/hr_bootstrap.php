<?php
/**
 * hr_bootstrap.php
 * -----------------------------------------------------------------------------
 * Shared foundation for every VIP HR endpoint. Loaded first by every PHP file.
 * -----------------------------------------------------------------------------
 */

declare(strict_types=1);

if (defined('FSM_HR_BOOTSTRAP_LOADED')) { return; }
define('FSM_HR_BOOTSTRAP_LOADED', true);

ini_set('display_errors', '0');
ini_set('display_startup_errors', '0');
ini_set('log_errors', '1');
error_reporting(E_ALL);

// ---- Session hardening -------------------------------------------------------
if (session_status() !== PHP_SESSION_ACTIVE) {
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
              || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');

    session_name('VIP_HRSESS');

    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'domain'   => '',
        'secure'   => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);

    session_start();
}

if (!isset($_SESSION['__created'])) {
    $_SESSION['__created'] = time();
} elseif (time() - (int)$_SESSION['__created'] > 1800) {
    session_regenerate_id(true);
    $_SESSION['__created'] = time();
}

// ---- Database ---------------------------------------------------------------
const DB_HOST = '127.0.0.1';
const DB_PORT = 3306;
const DB_NAME = 'VIP_hr';
const DB_USER = 'VIP_hr_app';
const DB_PASS = 'ChangeThisStrongPass123!';

function db(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $dsn = sprintf(
        'mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4',
        DB_HOST, DB_PORT, DB_NAME
    );

    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::ATTR_STRINGIFY_FETCHES  => false,
            PDO::ATTR_PERSISTENT         => false,
        ]);
    } catch (PDOException $e) {
        error_log('[db] connection failed: ' . $e->getMessage());
        json_out(['success' => false, 'message' => 'Database unavailable.'], 500);
    }

    return $pdo;
}

// ---- JSON output -------------------------------------------------------------
function json_out(array $payload, int $code = 200): never {
    if (!headers_sent()) {
        http_response_code($code);
        header('Content-Type: application/json; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        header('Referrer-Policy: same-origin');
        header('Cache-Control: no-store');
    }
    echo json_encode(
        $payload,
        JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE
    );
    exit;
}

function ok(array $data = [], string $msg = ''): never {
    json_out(['success' => true, 'message' => $msg] + $data);
}

function fail(string $msg, int $code = 400): never {
    json_out(['success' => false, 'message' => $msg], $code);
}

// ---- Auth --------------------------------------------------------------------
function current_user(): ?array {
    return $_SESSION['hr_user'] ?? null;
}

function require_login(): array {
    $u = current_user();
    if (!$u) {
        fail('Not authenticated.', 401);
    }
    return $u;
}

function require_role(...$roles): array {
    if (count($roles) === 1 && is_array($roles[0])) { $roles = $roles[0]; }
    $u = require_login();
    if (!in_array($u['role'] ?? '', $roles, true)) {
        fail('You do not have permission to perform this action.', 403);
    }
    return $u;
}

// ---- CSRF --------------------------------------------------------------------
function csrf_token(): string {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf']           = bin2hex(random_bytes(32));
        $_SESSION['csrf_issued_at'] = time();
    }
    return $_SESSION['csrf'];
}

function require_csrf(): void {
    $sent = $_SERVER['HTTP_X_CSRF_TOKEN']
        ?? $_POST['csrf_token']
        ?? '';

    $expected = $_SESSION['csrf'] ?? '';

    if ($expected === '' || $sent === '' || !hash_equals($expected, (string)$sent)) {
        fail('Invalid or expired CSRF token.', 419);
    }
}

// ---- Input helpers -----------------------------------------------------------
function json_body(): array {
    $raw = file_get_contents('php://input');
    if ($raw === false || $raw === '') {
        return [];
    }
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : [];
}

function only_method(string ...$allowed): void {
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    if (!in_array($method, $allowed, true)) {
        header('Allow: ' . implode(', ', $allowed));
        fail('Method not allowed.', 405);
    }
}

function int_param(string $key, ?int $default = null): ?int {
    $v = $_GET[$key] ?? $_POST[$key] ?? null;
    if ($v === null || $v === '') {
        return $default;
    }
    if (!is_numeric($v)) {
        fail("Parameter '{$key}' must be numeric.");
    }
    return (int)$v;
}

function str_param(string $key, string $default = ''): string {
    $v = $_GET[$key] ?? $_POST[$key] ?? $default;
    return is_string($v) ? trim($v) : $default;
}

// ---- Audit -------------------------------------------------------------------
function audit(string $action, string $module, string $description): void {
    try {
        $u = current_user();
        db()->prepare(
            'INSERT INTO audit_logs (action_type, module, description, hr_user_id)
             VALUES (?, ?, ?, ?)'
        )->execute([
            $action,
            $module,
            $description,
            $u['id'] ?? null,
        ]);
    } catch (Throwable $e) {
        error_log('[audit] ' . $e->getMessage());
    }
}

// ---- Rate limiting -----------------------------------------------------------
function is_rate_limited(string $bucket, int $maxAttempts, int $windowSeconds): bool {
    try {
        $pdo = db();
        $now = time();

        $stmt = $pdo->prepare(
            'SELECT attempts, first_seen FROM login_attempts WHERE bucket = ? LIMIT 1'
        );
        $stmt->execute([$bucket]);
        $row = $stmt->fetch();

        if (!$row) {
            return false;
        }

        $firstSeen = (int)$row['first_seen'];
        $attempts  = (int)$row['attempts'];

        if (($now - $firstSeen) > $windowSeconds) {
            clear_rate_limit($bucket);
            return false;
        }

        return $attempts >= $maxAttempts;
    } catch (Throwable $e) {
        error_log('[rate_limit:check] ' . $e->getMessage());
        return false;
    }
}

function record_failed_attempt(string $bucket): void {
    try {
        $pdo = db();
        $now = time();

        $sql = '
            INSERT INTO login_attempts (bucket, attempts, first_seen, last_seen)
            VALUES (:b, 1, :now, :now)
            ON DUPLICATE KEY UPDATE
                attempts   = IF(:now - first_seen > 900, 1, attempts + 1),
                first_seen = IF(:now - first_seen > 900, :now, first_seen),
                last_seen  = :now
        ';
        $pdo->prepare($sql)->execute([':b' => $bucket, ':now' => $now]);
    } catch (Throwable $e) {
        error_log('[rate_limit:record] ' . $e->getMessage());
    }
}

function clear_rate_limit(string $bucket): void {
    try {
        db()->prepare('DELETE FROM login_attempts WHERE bucket = ?')->execute([$bucket]);
    } catch (Throwable $e) {
        error_log('[rate_limit:clear] ' . $e->getMessage());
    }
}
// Aliases for legacy endpoint naming.
if (!function_exists('json_ok')) {
    function json_ok(array $data = [], string $msg = ''): never { ok($data, $msg); }
}
if (!function_exists('json_error')) {
    function json_error(string $msg, int $code = 400): never { fail($msg, $code); }
}

// ============================================================
// Compatibility layer for legacy endpoints.
// Provides the Database class + input helpers that files
// written before hr_bootstrap.php exist still expect.
// ============================================================

if (!class_exists('Database')) {
    class Database {
        private ?PDO $conn = null;
        public function getConnection(): PDO {
            if ($this->conn === null) {
                $this->conn = db();
            }
            return $this->conn;
        }
    }
}

if (!function_exists('str_field')) {
    function str_field(array $src, string $key, string $default = ''): string {
        $v = $src[$key] ?? $default;
        return is_string($v) ? trim($v) : $default;
    }
}

if (!function_exists('int_field')) {
    function int_field(array $src, string $key, ?int $default = null): ?int {
        $v = $src[$key] ?? null;
        if ($v === null || $v === '') return $default;
        return is_numeric($v) ? (int)$v : $default;
    }
}

if (!function_exists('enum_field')) {
    function enum_field(array $src, string $key, array $allowed, string $default = ''): string {
        $v = isset($src[$key]) && is_string($src[$key]) ? trim($src[$key]) : '';
        return in_array($v, $allowed, true) ? $v : $default;
    }
}

if (!function_exists('paginate')) {
    function paginate(int $defaultLimit = 100, int $maxLimit = 500): array {
        $limit  = int_field($_GET, 'limit', $defaultLimit) ?? $defaultLimit;
        $limit  = max(1, min($limit, $maxLimit));
        $page   = max(1, int_field($_GET, 'page', 1) ?? 1);
        $offset = ($page - 1) * $limit;
        return [$offset, $limit];
    }
}
