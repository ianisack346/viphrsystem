<?php
require_once __DIR__ . '/includes/auth.php';
$user = require_role(['hr', 'admin']);

$db = (new Database())->getConnection();
$body = json_body();

$template = enum_field($body, 'template', ['offer_letter', 'contract', 'warning', 'nda']);
$employeeId = int_field($body, 'employee_id');
if (!$template || !$employeeId) {
    json_error('template and employee_id are required.', 400);
}

$stmt = $db->prepare(
    "SELECT e.*, d.name AS department_name FROM employees e
     LEFT JOIN departments d ON d.id = e.department_id WHERE e.id = ? LIMIT 1"
);
$stmt->execute([$employeeId]);
$employee = $stmt->fetch();
if (!$employee) {
    json_error('Employee not found.', 404);
}

$name = h($employee['firstname'] . ' ' . $employee['lastname']);
$today = date('F j, Y');
$titles = [
    'offer_letter' => 'Offer of Employment',
    'contract' => 'Employment Contract',
    'warning' => 'Formal Warning Letter',
    'nda' => 'Non-Disclosure Agreement',
];

switch ($template) {
    case 'offer_letter':
        $salary = float_field($body, 'salary');
        $startDate = str_field($body, 'start_date');
        $position = str_field($body, 'position', $employee['position']);
        if (!$salary || !is_valid_date($startDate)) {
            json_error('Salary and a valid start date are required.', 400);
        }
        $content = "<h2>{$titles[$template]}</h2><p>Date: $today</p>
            <p>Dear $name,</p>
            <p>We are pleased to offer you the position of <strong>" . h($position) . "</strong>
            in the " . h($employee['department_name'] ?? 'N/A') . " department, at a monthly salary of
            TZS " . number_format($salary, 2) . ", starting " . h($startDate) . ".</p>
            <p>Regards,<br>Human Resources</p>";
        break;

    case 'contract':
        $salary = float_field($body, 'salary');
        $startDate = str_field($body, 'start_date');
        $duration = str_field($body, 'duration');
        $terms = str_field($body, 'terms', '');
        if (!$salary || !is_valid_date($startDate) || !$duration) {
            json_error('Salary, start date, and duration are required.', 400);
        }
        $content = "<h2>{$titles[$template]}</h2><p>Date: $today</p>
            <p>This contract is entered into between FortishieldMatrix and $name for the position of
            " . h($employee['position']) . ", effective " . h($startDate) . ", for a duration of " . h($duration) . ",
            at a monthly salary of TZS " . number_format($salary, 2) . ".</p>
            " . ($terms ? '<p><strong>Additional terms:</strong> ' . h($terms) . '</p>' : '') . "
            <p>Regards,<br>Human Resources</p>";
        break;

    case 'warning':
        $violation = str_field($body, 'violation');
        $action = str_field($body, 'action_taken');
        if (!$violation || !$action) {
            json_error('Violation and action taken are required.', 400);
        }
        $content = "<h2>{$titles[$template]}</h2><p>Date: $today</p>
            <p>Dear $name,</p>
            <p>This letter serves as formal notice regarding the following matter:</p>
            <p>" . nl2br(h($violation)) . "</p>
            <p><strong>Action taken:</strong> " . nl2br(h($action)) . "</p>
            <p>Regards,<br>Human Resources</p>";
        break;

    case 'nda':
        $project = str_field($body, 'project');
        $duration = str_field($body, 'duration', '1 year');
        $confInfo = str_field($body, 'confidential_info', '');
        if (!$project) {
            json_error('Project name is required.', 400);
        }
        $content = "<h2>{$titles[$template]}</h2><p>Date: $today</p>
            <p>This Non-Disclosure Agreement is made between FortishieldMatrix and $name regarding
            project <strong>" . h($project) . "</strong>, valid for " . h($duration) . ".</p>
            " . ($confInfo ? '<p><strong>Confidential information covers:</strong> ' . h($confInfo) . '</p>' : '') . "
            <p>Regards,<br>Human Resources</p>";
        break;
}

$db->beginTransaction();
try {
    $stmt = $db->prepare('INSERT INTO generated_documents (employee_id, template, content, generated_by) VALUES (?, ?, ?, ?)');
    $stmt->execute([$employeeId, $template, $content, $user['id']]);
    $genId = (int)$db->lastInsertId();

    // Persist as a real file so it also shows up in the Document Management table.
    if (!is_dir(DOC_UPLOAD_DIR)) {
        mkdir(DOC_UPLOAD_DIR, 0755, true);
    }
    $storedName = bin2hex(random_bytes(16)) . '.html';
    file_put_contents(DOC_UPLOAD_DIR . '/' . $storedName, "<!DOCTYPE html><html><body>$content</body></html>");
    $fileSize = filesize(DOC_UPLOAD_DIR . '/' . $storedName);
    $displayName = $titles[$template] . ' - ' . $employee['firstname'] . ' ' . $employee['lastname'] . '.html';

    $stmt = $db->prepare(
        'INSERT INTO documents (title, description, document_type, employee_id, file_name, stored_name,
            file_type, file_size, access_level, status, version_count, uploaded_by)
         VALUES (?, ?, ?, ?, ?, ?, "html", ?, "private", "active", 1, ?)'
    );
    $stmt->execute([
        $titles[$template],
        'Auto-generated document',
        $template,
        $employeeId,
        $displayName,
        $storedName,
        $fileSize,
        $user['id'],
    ]);

    $db->commit();
} catch (Throwable $e) {
    $db->rollBack();
    error_log('[GENERATE DOCUMENT] ' . $e->getMessage());
    json_error('Could not generate document.', 500);
}

log_audit($db, (int)$user['id'], 'document_generated', 'documents', "Generated $template for $name");
json_ok(['message' => 'Document generated', 'id' => $genId]);
