<?php
require_once __DIR__ . '/includes/auth.php';
$user = require_role(['hr', 'admin']);

$db = (new Database())->getConnection();
$body = json_body();

$title = str_field($body, 'title');
$startDate = str_field($body, 'start_date'); // datetime-local string, e.g. 2026-10-05T09:00
$endDate = str_field($body, 'end_date');
$trainerName = str_field($body, 'trainer_name');

if (!$title || !$startDate || !$endDate || !$trainerName) {
    json_error('Title, start/end date, and trainer name are required.', 400);
}

$startDt = DateTime::createFromFormat('Y-m-d\TH:i', $startDate) ?: DateTime::createFromFormat('Y-m-d H:i:s', $startDate);
$endDt = DateTime::createFromFormat('Y-m-d\TH:i', $endDate) ?: DateTime::createFromFormat('Y-m-d H:i:s', $endDate);
if (!$startDt || !$endDt) {
    json_error('Invalid date format.', 400);
}
if ($endDt <= $startDt) {
    json_error('End date must be after start date.', 400);
}

$targetDeptId = null;
$targetDeptName = str_field($body, 'target_department');
if ($targetDeptName) {
    $stmt = $db->prepare('SELECT id FROM departments WHERE name = ? LIMIT 1');
    $stmt->execute([$targetDeptName]);
    $d = $stmt->fetch();
    $targetDeptId = $d ? (int)$d['id'] : null;
}

$status = str_field($body, 'status', 'Draft');
$allowedStatuses = ['Draft', 'Scheduled', 'Open for Registration', 'In Progress', 'Completed', 'Cancelled'];
if (!in_array($status, $allowedStatuses, true)) {
    $status = 'Draft';
}

$participants = is_array($body['participants'] ?? null) ? $body['participants'] : [];

$db->beginTransaction();
try {
    $stmt = $db->prepare(
        'INSERT INTO trainings
            (title, type, description, start_date, end_date, duration, max_participants, format,
             location, virtual_details, trainer_name, trainer_email, trainer_bio, target_audience,
             target_department_id, prerequisites, materials_needed, objectives, cost_per_participant,
             total_budget, budget_code, status, certificate_available, mandatory, send_notifications, created_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );
    $stmt->execute([
        $title,
        str_field($body, 'type'),
        str_field($body, 'description'),
        $startDt->format('Y-m-d H:i:s'),
        $endDt->format('Y-m-d H:i:s'),
        int_field($body, 'duration', 0),
        int_field($body, 'max_participants', 0),
        str_field($body, 'format'),
        str_field($body, 'location'),
        str_field($body, 'virtual_details'),
        $trainerName,
        str_field($body, 'trainer_email'),
        str_field($body, 'trainer_bio'),
        str_field($body, 'target_audience'),
        $targetDeptId,
        str_field($body, 'prerequisites'),
        str_field($body, 'materials_needed'),
        str_field($body, 'objectives'),
        float_field($body, 'cost_per_participant', 0),
        float_field($body, 'total_budget', 0),
        str_field($body, 'budget_code'),
        $status,
        !empty($body['certificate_available']) ? 1 : 0,
        !empty($body['mandatory']) ? 1 : 0,
        !empty($body['send_notifications']) ? 1 : 0,
        $user['id'],
    ]);
    $trainingId = (int)$db->lastInsertId();

    $added = 0;
    if ($participants) {
        $pStmt = $db->prepare('INSERT IGNORE INTO training_participants (training_id, employee_id) VALUES (?, ?)');
        foreach ($participants as $p) {
            $empId = int_field(is_array($p) ? $p : [], 'employee_id');
            if ($empId) {
                $pStmt->execute([$trainingId, $empId]);
                $added++;
            }
        }
        if ($added > 0) {
            $db->prepare('UPDATE trainings SET current_participants = ? WHERE id = ?')->execute([$added, $trainingId]);
        }
    }

    $db->commit();
} catch (Throwable $e) {
    $db->rollBack();
    error_log('[SAVE TRAINING] ' . $e->getMessage());
    json_error('Could not save training.', 500);
}

log_audit($db, (int)$user['id'], 'training_saved', 'training', "Saved training \"$title\" ($status)");
json_ok(['message' => 'Training saved', 'id' => $trainingId], 201);
