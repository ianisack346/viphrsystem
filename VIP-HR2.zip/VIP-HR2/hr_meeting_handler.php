<?php
require_once __DIR__ . '/includes/auth.php';
$user = require_role(['hr', 'admin']);

$db = (new Database())->getConnection();
$body = json_body();
$action = enum_field($body, 'action', ['schedule', 'cancel']);

if ($action === 'cancel') {
    $meetingId = int_field($body, 'meeting_id');
    if (!$meetingId) {
        json_error('meeting_id is required.', 400);
    }
    $stmt = $db->prepare("UPDATE meetings SET status='cancelled' WHERE meeting_id = ? AND status = 'scheduled'");
    $stmt->execute([$meetingId]);
    if ($stmt->rowCount() === 0) {
        json_error('Meeting not found or already resolved.', 404);
    }
    log_audit($db, (int)$user['id'], 'meeting_cancelled', 'meetings', "Cancelled meeting #$meetingId");
    json_ok(['message' => 'Meeting cancelled']);
}

if ($action === 'schedule') {
    $title = str_field($body, 'title');
    $subject = str_field($body, 'subject');
    $objective = str_field($body, 'objective');
    $date = str_field($body, 'meeting_date');
    $start = str_field($body, 'start_time');
    $end = str_field($body, 'end_time');
    $scope = enum_field($body, 'scope', ['all', 'department', 'managers', 'specific']);

    if (!$title || !$subject || !$objective || !is_valid_date($date) || !$start || !$end || !$scope) {
        json_error('All required meeting fields must be filled.', 400);
    }
    if ($end <= $start) {
        json_error('End time must be after start time.', 400);
    }

    $departmentId = null;
    $deptName = str_field($body, 'department');
    if ($deptName) {
        $stmt = $db->prepare('SELECT id FROM departments WHERE name = ? LIMIT 1');
        $stmt->execute([$deptName]);
        $d = $stmt->fetch();
        $departmentId = $d ? (int)$d['id'] : null;
    }

    $db->beginTransaction();
    try {
        $stmt = $db->prepare(
            'INSERT INTO meetings (title, subject, objectives, meeting_date, start_time, end_time, scope,
                department_id, location, notes, status, created_by)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "scheduled", ?)'
        );
        $stmt->execute([
            $title, $subject, $objective, $date, $start, $end, $scope,
            $departmentId, str_field($body, 'location'), str_field($body, 'notes'), $user['id'],
        ]);
        $meetingId = (int)$db->lastInsertId();

        $attendeesRaw = str_field($body, 'attendees', '');
        if ($attendeesRaw) {
            $ids = array_filter(array_map('intval', explode(',', $attendeesRaw)));
            if ($ids) {
                $stmt = $db->prepare('INSERT IGNORE INTO meeting_attendees (meeting_id, employee_id) VALUES (?, ?)');
                foreach ($ids as $eid) {
                    $stmt->execute([$meetingId, $eid]);
                }
            }
        }
        $db->commit();
    } catch (Throwable $e) {
        $db->rollBack();
        error_log('[MEETING SCHEDULE] ' . $e->getMessage());
        json_error('Could not schedule meeting.', 500);
    }

    log_audit($db, (int)$user['id'], 'meeting_scheduled', 'meetings', "Scheduled \"$title\"");
    json_ok(['message' => 'Meeting scheduled', 'meeting_id' => $meetingId], 201);
}

json_error('Unsupported request.', 400);
