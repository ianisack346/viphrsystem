<?php
require_once __DIR__ . '/includes/auth.php';
require_role(['hr', 'admin']);

$db = (new Database())->getConnection();

$statusCounts = $db->query(
    "SELECT status, COUNT(*) c FROM payroll GROUP BY status"
)->fetchAll();
$byStatus = ['pending' => 0, 'processing' => 0, 'paid' => 0];
foreach ($statusCounts as $row) {
    $byStatus[$row['status']] = (int)$row['c'];
}
$totalEmployees = (int)$db->query("SELECT COUNT(*) FROM employees WHERE status='Active'")->fetchColumn();

$department = str_field($_GET, 'department');
$month = str_field($_GET, 'month'); // YYYY-MM
$status = enum_field($_GET, 'status', ['pending', 'approved', 'denied', 'processing', 'paid']);

$sql = "SELECT e.employee_code, CONCAT(e.firstname,' ',e.lastname) AS employee_name, d.name AS department,
               p.pay_period, p.basic_salary, (p.tax + p.insurance + p.other_deductions) AS deductions,
               p.net_salary, p.status, p.payment_date
        FROM payroll p
        JOIN employees e ON e.id = p.employee_id
        LEFT JOIN departments d ON d.id = e.department_id
        WHERE 1=1";
$params = [];
if ($department) {
    $sql .= ' AND d.name = ?';
    $params[] = $department;
}
if ($month) {
    $sql .= ' AND p.pay_period = ?';
    $params[] = $month;
}
if ($status) {
    $sql .= ' AND p.status = ?';
    $params[] = $status;
}
$sql .= ' ORDER BY p.created_at DESC';

$stmt = $db->prepare($sql);
$stmt->execute($params);

json_ok([
    'stats' => [
        'total_employees' => $totalEmployees,
        'pending' => $byStatus['pending'],
        'processing' => $byStatus['processing'],
        'completed' => $byStatus['paid'],
    ],
    'payrolls' => $stmt->fetchAll(),
]);
