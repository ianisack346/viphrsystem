<?php
require_once __DIR__ . '/includes/auth.php';
require_role(['hr', 'admin']);

$db = (new Database())->getConnection();
$today = date('Y-m-d');

$totalEmployees = (int)$db->query("SELECT COUNT(*) FROM employees WHERE status='Active'")->fetchColumn();

$pendingLeaves = (int)$db->query("SELECT COUNT(*) FROM leave_requests WHERE status='pending'")->fetchColumn();

$stmt = $db->prepare("SELECT status, COUNT(*) c FROM attendance_records WHERE date = ? GROUP BY status");
$stmt->execute([$today]);
$byStatus = ['present' => 0, 'present_late' => 0, 'late' => 0, 'absent' => 0];
foreach ($stmt->fetchAll() as $row) {
    $byStatus[$row['status']] = (int)$row['c'];
}

$overdueTrainings = (int)$db->query(
    "SELECT COUNT(*) FROM trainings WHERE end_date < NOW() AND status NOT IN ('Completed','Cancelled')"
)->fetchColumn();

// Leave type breakdown for the dashboard donut/gauge widget
$leaveTypes = ['Annual', 'Sick', 'Personal', 'Maternity'];
$leaveCounts = [];
foreach ($leaveTypes as $type) {
    $stmt = $db->prepare("SELECT COUNT(*) FROM leave_requests WHERE leave_type LIKE CONCAT(?, '%') AND status='approved'");
    $stmt->execute([$type]);
    $leaveCounts[] = (int)$stmt->fetchColumn();
}

json_ok([
    'total_employees' => $totalEmployees,
    'pending_leaves' => $pendingLeaves,
    'present_today' => $byStatus['present'],
    'present_late_today' => $byStatus['present'] + $byStatus['present_late'],
    'late_employees' => $byStatus['late'],
    'absent_today' => $byStatus['absent'],
    'overdue_trainings' => $overdueTrainings,
    'leave_types' => $leaveTypes,
    'leave_counts' => $leaveCounts,
]);
