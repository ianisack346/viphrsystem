<?php
require_once __DIR__ . '/includes/auth.php';
require_role(['hr', 'admin']);

$db = (new Database())->getConnection();
[$offset, $limit] = paginate(100, 500);

$stmt = $db->prepare(
    "SELECT id, title, type, start_date, end_date, duration, max_participants,
            current_participants, status
     FROM trainings
     ORDER BY start_date DESC
     LIMIT ? OFFSET ?"
);
$stmt->bindValue(1, $limit, PDO::PARAM_INT);
$stmt->bindValue(2, $offset, PDO::PARAM_INT);
$stmt->execute();

json_ok(['trainings' => $stmt->fetchAll()]);
