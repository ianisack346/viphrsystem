<?php
require_once __DIR__ . '/includes/auth.php';
require_role(['hr', 'admin']);

$db = (new Database())->getConnection();
[$offset, $limit] = paginate(100, 500);

$stmt = $db->prepare(
    "SELECT hu.full_name AS employee_name, hu.hr_code AS employee_code,
            ha.check_in_time AS check_in, ha.check_out_time AS check_out,
            CASE WHEN ha.check_in_time IS NOT NULL AND ha.check_out_time IS NOT NULL
                 THEN TIME_FORMAT(TIMEDIFF(ha.check_out_time, ha.check_in_time), '%H:%i')
                 ELSE NULL END AS total_hours,
            ha.status
     FROM hr_attendance ha
     JOIN hr_users hu ON hu.id = ha.hr_user_id
     ORDER BY ha.date DESC, hu.full_name
     LIMIT ? OFFSET ?"
);
$stmt->bindValue(1, $limit, PDO::PARAM_INT);
$stmt->bindValue(2, $offset, PDO::PARAM_INT);
$stmt->execute();

http_response_code(200);
echo json_encode($stmt->fetchAll(), JSON_UNESCAPED_SLASHES);
