<?php
require_once __DIR__ . '/includes/auth.php';
$user = require_login();

$db = (new Database())->getConnection();
$method = $_SERVER['REQUEST_METHOD'];
$today = date('Y-m-d');

if ($method === 'GET' && ($_GET['action'] ?? '') === 'get_today_status') {
    $stmt = $db->prepare('SELECT status, check_in_time, check_out_time FROM hr_attendance WHERE hr_user_id = ? AND date = ?');
    $stmt->execute([$user['id'], $today]);
    $record = $stmt->fetch();
    json_ok(['record' => $record ?: null]);
}

if ($method === 'POST') {
    $body = json_body();
    $action = enum_field($body, 'action', ['check_in', 'check_out']);

    if ($action === 'check_in') {
        $status = enum_field($body, 'status', ['present', 'present_late', 'late', 'absent']);
        $reason = str_field($body, 'reason', '');
        $lat = float_field($body, 'latitude');
        $lng = float_field($body, 'longitude');

        if (!$status) {
            json_error('A valid status is required.', 400);
        }
        if (in_array($status, ['late', 'absent'], true) && !$reason) {
            json_error('A reason is required for late or absent check-ins.', 400);
        }
        if ($lat === null || $lng === null) {
            json_error('Location is required to check in.', 400);
        }

        $dow = (int)date('N');
        if ($dow === 7) {
            json_error('Check-ins are not allowed on Sundays.', 403);
        }

        $stmt = $db->prepare('SELECT id FROM hr_attendance WHERE hr_user_id = ? AND date = ?');
        $stmt->execute([$user['id'], $today]);
        if ($stmt->fetch()) {
            json_error('You have already checked in today.', 409);
        }

        $now = date('H:i:s');
        $stmt = $db->prepare(
            'INSERT INTO hr_attendance (hr_user_id, date, check_in_time, status, reason, latitude, longitude)
             VALUES (?, ?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([$user['id'], $today, $now, $status, $reason, $lat, $lng]);
        log_audit($db, (int)$user['id'], 'hr_check_in', 'attendance', "Checked in as $status");
        json_ok(['message' => 'Checked in', 'check_in_time' => $now]);
    }

    if ($action === 'check_out') {
        $stmt = $db->prepare('SELECT id, check_out_time FROM hr_attendance WHERE hr_user_id = ? AND date = ?');
        $stmt->execute([$user['id'], $today]);
        $record = $stmt->fetch();
        if (!$record) {
            json_error('You have not checked in today.', 409);
        }
        if ($record['check_out_time']) {
            json_error('You have already checked out today.', 409);
        }
        $now = date('H:i:s');
        $stmt = $db->prepare('UPDATE hr_attendance SET check_out_time = ? WHERE id = ?');
        $stmt->execute([$now, $record['id']]);
        log_audit($db, (int)$user['id'], 'hr_check_out', 'attendance', 'Checked out');
        json_ok(['message' => 'Checked out', 'check_out_time' => $now]);
    }
}

json_error('Unsupported request.', 400);
