<?php
declare(strict_types=1);
require_once __DIR__ . '/hr_bootstrap.php';

only_method('POST');
require_csrf();

const LOGIN_DUMMY_HASH = '$2y$10$e0NRzDv7o1X7zN4z7O4nZeQfKb7Qw7hNqkR1a0cW9pL9mS8bN0m2C';

$body     = json_body();
$username = isset($body['username']) ? trim((string)$body['username']) : '';
$password = isset($body['password']) ? (string)$body['password'] : '';

if ($username === '' || $password === '') {
    fail('Username and password are required.', 400);
}

$ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

if (is_rate_limited('ip:' . $ip, 5, 900)) {
    fail('Too many attempts. Please try again later.', 429);
}

$pdo = db();

$stmt = $pdo->prepare(
    "SELECT id, username, email, password_hash, role, full_name,
            profile_photo, hr_code, status
     FROM hr_users
     WHERE username = :u1 OR email = :u2
     LIMIT 1"
);
$stmt->execute([':u1' => $username, ':u2' => $username]);
$user = $stmt->fetch();

$hashToCheck = ($user && !empty($user['password_hash'])) ? $user['password_hash'] : LOGIN_DUMMY_HASH;
$ok          = password_verify($password, $hashToCheck);
$active      = $user && ($user['status'] ?? 'inactive') === 'active';

error_log('[debug] user=' . ($user ? ($user['username'] ?? '?') : 'NULL') . ' ok=' . ($ok ? '1' : '0') . ' active=' . ($active ? '1' : '0') . ' input=' . $username);

if (!($ok && $user && $active)) {
    record_failed_attempt('ip:' . $ip);
    audit('login_failed', 'auth', "Failed login for $username from $ip");
    usleep(random_int(150000, 450000));
    fail('Invalid username or password.', 401);
}

session_regenerate_id(true);

$_SESSION['hr_user'] = [
    'id'            => (int)$user['id'],
    'username'      => $user['username'],
    'email'         => $user['email'],
    'full_name'     => $user['full_name'],
    'role'          => $user['role'],
    'hr_code'       => $user['hr_code'],
    'profile_photo' => $user['profile_photo'] ?: 'logo.png',
];
$_SESSION['__created']      = time();
$_SESSION['csrf']           = bin2hex(random_bytes(32));
$_SESSION['csrf_issued_at'] = time();

clear_rate_limit('ip:' . $ip);

$pdo->prepare("UPDATE hr_users SET last_login = NOW() WHERE id = :id")
    ->execute([':id' => $user['id']]);

audit('login_success', 'auth', "Successful login for {$user['username']}");

ok([
    'user' => $_SESSION['hr_user'],
    'csrf' => $_SESSION['csrf'],
], 'Signed in.');