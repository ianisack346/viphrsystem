<?php
require_once __DIR__ . '/includes/auth.php';

$db = (new Database())->getConnection();
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? ($method === 'POST' ? 'save' : 'load');

if ($action === 'load') {
    require_role(['hr', 'admin']);
    $rows = $db->query('SELECT setting_key, setting_value FROM system_settings')->fetchAll();
    $settings = [];
    foreach ($rows as $r) {
        $settings[$r['setting_key']] = $r['setting_value'];
    }
    json_ok(['settings' => $settings]);
}

if ($action === 'save') {
    $user = require_role(['hr', 'admin']);
    $body = json_body();
    $settings = $body['settings'] ?? [];
    if (!is_array($settings) || empty($settings)) {
        json_error('No settings supplied.', 400);
    }

    // Whitelist of settings keys we actually persist — never let arbitrary
    // client-supplied keys get written straight into the table.
    $allowedKeys = [
        'companyName', 'companyTimezone', 'companyCurrency',
        'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday',
        'workStartTime', 'workEndTime', 'gracePeriod', 'autoCheckout', 'remoteWorkDays',
        'overtimeRate', 'annualLeave', 'sickLeave', 'carryForward', 'approvalHierarchy',
        'passwordExpiry', 'maxLoginAttempts', 'twoFactorAuth', 'deviceRestrictions',
        'sessionTimeout', 'auditLogging', 'smtpServer', 'smtpPort', 'fromEmail', 'fromName',
        'leaveReminders', 'attendanceReminders', 'payrollReminders',
        'uiTheme', 'defaultDashboard', 'auditRetention', 'attendanceRetention',
        'performanceRetention', 'payrollRetention', 'backupFrequency', 'backupTime', 'backupLocation',
    ];

    $db->beginTransaction();
    try {
        $stmt = $db->prepare(
            'INSERT INTO system_settings (setting_key, setting_value) VALUES (?, ?)
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)'
        );
        foreach ($settings as $key => $value) {
            if (!in_array($key, $allowedKeys, true)) {
                continue;
            }
            $stmt->execute([$key, (string)$value]);
        }
        $db->commit();
    } catch (Throwable $e) {
        $db->rollBack();
        error_log('[SETTINGS SAVE] ' . $e->getMessage());
        json_error('Could not save settings.', 500);
    }

    log_audit($db, (int)$user['id'], 'settings_update', 'settings', 'Updated system settings');
    json_ok(['message' => 'Settings saved']);
}

json_error('Unknown action.', 400);
