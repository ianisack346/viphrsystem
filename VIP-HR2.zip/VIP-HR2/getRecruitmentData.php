<?php
require_once __DIR__ . '/includes/auth.php';
require_role(['hr', 'admin']);

$db = (new Database())->getConnection();

$status = enum_field($_GET, 'status', ['pending', 'under_review', 'shortlisted', 'interview', 'approved', 'rejected']);
$department = str_field($_GET, 'department');
$priority = enum_field($_GET, 'priority', ['Low', 'Medium', 'High', 'Urgent']);
$search = str_field($_GET, 'search');

$sql = "SELECT a.id AS application_id, a.id, v.position_title AS position_applied, v.position_title AS position,
               v.priority, CONCAT(c.first_name, ' ', c.last_name) AS applicant_name, c.email, c.phone,
               a.status, DATE(a.submission_date) AS application_date
        FROM rms_applications a
        JOIN rms_candidates c ON c.id = a.user_id
        JOIN recruitment_vacancies v ON v.id = a.vacancy_id
        LEFT JOIN departments d ON d.id = v.department_id
        WHERE 1=1";
$params = [];

if ($status) {
    $sql .= ' AND a.status = ?';
    $params[] = $status;
}
if ($department) {
    $sql .= ' AND d.name = ?';
    $params[] = $department;
}
if ($priority) {
    $sql .= ' AND v.priority = ?';
    $params[] = $priority;
}
if ($search) {
    $sql .= ' AND (c.first_name LIKE ? OR c.last_name LIKE ? OR c.email LIKE ?)';
    $like = "%$search%";
    array_push($params, $like, $like, $like);
}
$sql .= ' ORDER BY a.submission_date DESC';

$stmt = $db->prepare($sql);
$stmt->execute($params);

json_ok(['data' => $stmt->fetchAll()]);
