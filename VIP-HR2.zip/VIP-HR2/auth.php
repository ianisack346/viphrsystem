<?php
/**
 * auth.php
 * Session bootstrap + role gate + lightweight CSRF (Origin/Referer check)
 * for every endpoint. Include this (not db_connect.php directly) at the
 * top of any protected endpoint:
 *
 *   require_once __DIR__ . '/includes/auth.php';
 *   $hrUser = require_role(['hr', 'admin']);
 *
 * $hrUser is the full session-derived user array (id, role, full_name...).
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db_connect.php';
require_once __DIR__ . '/functions.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Allowed origins for state-changing requests. Add your real domain(s).
 * When the app is served from the same origin as these PHP files (the
 * normal case), same-origin requests never send a cross-origin Origin
 * header mismatch, so this only blocks *other* sites' pages from
 * POSTing here with the victim's cookies.
 */
function allowed_origins(): array
{
    $configured = getenv('APP_ALLOWED_ORIGINS');
    if ($configured) {
        return array_map('trim', explode(',', $configured));
    }
    // Fallback: derive from the current host so it works out of the box.
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    return ["$scheme://$host"];
}

/**
 * For any state-changing method, require the Origin (or, failing that,
 * the Referer) header to match an allowed origin. GET requests are not
 * checked since they should not change state.
 */
function check_csrf(): void
{
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    if (!in_array($method, ['POST', 'PUT', 'PATCH', 'DELETE'], true)) {
        return;
    }
    $origin = $_SERVER['HTTP_ORIGIN'] ?? null;
    $referer = $_SERVER['HTTP_REFERER'] ?? null;
    $candidate = $origin ?: $referer;

    if ($candidate === null) {
        // Some same-origin XHR/fetch calls omit both headers depending on
        // browser/proxy config; do not hard-fail on absence alone, but do
        // log it so it's visible in an audit trail if it becomes common.
        error_log('[CSRF] Missing Origin/Referer header on ' . ($_SERVER['REQUEST_URI'] ?? ''));
        return;
    }

    $candidateOrigin = parse_origin($candidate);
    foreach (allowed_origins() as $allowed) {
        if (parse_origin($allowed) === $candidateOrigin) {
            return; // ok
        }
    }

    json_error('Request blocked (origin verification failed).', 403);
}

function parse_origin(string $url): string
{
    $parts = parse_url($url);
    $scheme = $parts['scheme'] ?? '';
    $host = $parts['host'] ?? '';
    $port = isset($parts['port']) ? ':' . $parts['port'] : '';
    return "$scheme://$host$port";
}

/**
 * Returns the current session user array, or null if not logged in.
 */
function current_user(): ?array
{
    if (empty($_SESSION['hr_user_id'])) {
        return null;
    }
    static $cached = null;
    if ($cached !== null) {
        return $cached;
    }
    $db = (new Database())->getConnection();
    $stmt = $db->prepare(
        'SELECT id, employee_id, username, email, role, full_name, profile_photo, hr_code, status
         FROM hr_users WHERE id = ? AND status = "active" LIMIT 1'
    );
    $stmt->execute([$_SESSION['hr_user_id']]);
    $user = $stmt->fetch();
    if (!$user) {
        return null;
    }
    $cached = $user;
    return $cached;
}

/**
 * Require a logged-in session. Emits 401 JSON and exits if not present.
 */
function require_login(): array
{
    $user = current_user();
    if (!$user) {
        json_error('Not authenticated. Please log in again.', 401);
    }
    check_csrf();
    return $user;
}

/**
 * Require a logged-in session whose role is in $roles.
 * @param string[] $roles
 */
function require_role(array $roles): array
{
    $user = require_login();
    if (!in_array($user['role'], $roles, true)) {
        json_error('You do not have permission to perform this action.', 403);
    }
    return $user;
}
