<?php
// Compatibility shim for legacy endpoints that expect includes/config.php.
// All real configuration lives in /hr_bootstrap.php at the project root.
declare(strict_types=1);

require_once __DIR__ . '/../hr_bootstrap.php';