<?php
/**
 * includes/auth.php
 * Compatibility shim for legacy endpoints.
 *
 * Loads the modern bootstrap and exposes the same helper functions the legacy
 * files call (require_login, current_user, etc. ? those already live in
 * hr_bootstrap.php so we just inherit them). We do NOT redirect on missing
 * session here ? legacy files decide that for themselves, and calling fail()
 * on include would break the login flow.
 */
declare(strict_types=1);

require_once __DIR__ . '/../hr_bootstrap.php';

// Some legacy endpoints expect a connection variable named $pdo or $conn.
// Expose them for compatibility without duplicating the connection.
if (!isset($pdo) || !($pdo instanceof PDO)) {
    $pdo = db();
}
if (!isset($conn) || !($conn instanceof PDO)) {
    $conn = db();
}

// Legacy endpoints sometimes call getDBConnection() or getConnection().
if (!function_exists('getDBConnection')) {
    function getDBConnection(): PDO { return db(); }
}
if (!function_exists('getConnection')) {
    function getConnection(): PDO { return db(); }
}