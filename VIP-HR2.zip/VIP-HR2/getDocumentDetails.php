<?php
require_once __DIR__ . '/includes/auth.php';
require_role(['hr', 'admin']);

$db = (new Database())->getConnection();
$id = int_field($_GET, 'id');
if (!$id) {
    json_error('id is required.', 400);
}

$stmt = $db->prepare(
    "SELECT d.*, dept.name AS department_name, e.firstname AS first_name, e.lastname AS last_name,
            hu.full_name AS uploaded_by_name
     FROM documents d
     LEFT JOIN departments dept ON dept.id = d.department_id
     LEFT JOIN employees e ON e.id = d.employee_id
     LEFT JOIN hr_users hu ON hu.id = d.uploaded_by
     WHERE d.id = ? AND d.deleted_at IS NULL LIMIT 1"
);
$stmt->execute([$id]);
$doc = $stmt->fetch();

if (!$doc) {
    json_error('Document not found.', 404);
}
$doc['document_id'] = (int)$doc['id'];

json_ok(['data' => $doc]);
