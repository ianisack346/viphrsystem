<?php
/**
 * hr_register.php
 * -----------------------------------------------------------------------------
 * Creates a new HR user account.
 *
 * Security & correctness:
 *  - POST-only, CSRF-verified.
 *  - Rate-limited per IP (identical bucket system as login) so scripted
 *    account-farming attempts are throttled.
 *  - Username, email, and hr_code are checked for uniqueness *inside* a
 *    transaction with SELECT ... FOR UPDATE to prevent two concurrent signups
 *    from racing each other to create the same username.
 *  - Password rules are enforced server-side (client validation is UX only).
 *  - Password is hashed with password_hash(PASSWORD_DEFAULT) — never stored raw.
 *  - Role is whitelisted to a safe subset — new signups cannot create admins.
 *  - Department ID is validated against the departments table.
 *  - Both the successful creation and any rejection are audit-logged.
 *  - The response never echoes back the password or the hash.
 *
 * Request JSON:
 *   {
 *     "full_name":  "Jane Doe",
 *     "username":   "jane.doe",
 *     "hr_code":    "2025/HR/0001",
 *     "email":      "jane@company.tz",
 *     "role":       "hr" | "manager" | "employee",
 *     "department": 2,
 *     "password":   "..."
 *   }
 * -----------------------------------------------------------------------------
 */

declare(strict_types=1);

require_once __DIR__ . '/hr_bootstrap.php';

// ---- Guards -----------------------------------------------------------------
only_method('POST');
require_csrf();
header('Cache-Control: no-store');

// ---- Tunables ---------------------------------------------------------------
const REG_MAX_ATTEMPTS_PER_WINDOW = 10;
const REG_WINDOW_SECONDS          = 3600;
const REG_MAX_NAME_LEN            = 150;
const REG_MAX_USERNAME_LEN        = 30;
const REG_MIN_USERNAME_LEN        = 3;
const REG_MAX_EMAIL_LEN           = 150;
const REG_MAX_PASSWORD_LEN        = 200;

// Roles that a self-signup is allowed to pick. Never allow 'admin' here.
const REG_ALLOWED_ROLES = ['hr', 'manager', 'employee'];

// ---- Rate limit -------------------------------------------------------------
$ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
if (is_rate_limited('reg:' . $ip, REG_MAX_ATTEMPTS_PER_WINDOW, REG_WINDOW_SECONDS)) {
    audit('register_rate_limited', 'auth', "Registration rate limit hit for {$ip}");
    fail('Too many registration attempts. Please try again later.', 429);
}

// ---- Parse & sanitise -------------------------------------------------------
$body      = json_body();
$fullName  = isset($body['full_name']) ? trim((string)$body['full_name']) : '';
$username  = isset($body['username'])  ? strtolower(trim((string)$body['username']))  : '';
$hrCode    = isset($body['hr_code'])   ? trim((string)$body['hr_code'])   : '';
$email     = isset($body['email'])     ? strtolower(trim((string)$body['email']))     : '';
$role      = isset($body['role'])      ? trim((string)$body['role'])      : '';
$deptId    = isset($body['department']) ? (int)$body['department']        : 0;
$password  = isset($body['password'])  ? (string)$body['password']        : '';

// Length guards first (fail fast before any regex work).
if (strlen($fullName)  > REG_MAX_NAME_LEN)     fail('Full name is too long.', 400);
if (strlen($username)  > REG_MAX_USERNAME_LEN) fail('Username is too long.', 400);
if (strlen($email)     > REG_MAX_EMAIL_LEN)    fail('Email is too long.', 400);
if (strlen($password)  > REG_MAX_PASSWORD_LEN) fail('Password is too long.', 400);

// ---- Field-level validation -------------------------------------------------
if ($fullName === '' || mb_strlen($fullName) < 3) {
    fail('Please enter your full name.', 400);
}
if (!preg_match('/^[a-z0-9._-]{' . REG_MIN_USERNAME_LEN . ',' . REG_MAX_USERNAME_LEN . '}$/', $username)) {
    fail('Username must be 3-30 characters: letters, digits, dot, dash, underscore.', 400);
}
if (!preg_match('#^\d{4}/HR/\d{4}$#', $hrCode)) {
    fail('HR code must match YYYY/HR/XXXX (e.g. 2025/HR/0001).', 400);
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    fail('Please provide a valid email address.', 400);
}
if (!in_array($role, REG_ALLOWED_ROLES, true)) {
    fail('Invalid role selected.', 400);
}
if ($deptId <= 0) {
    fail('Please select a department.', 400);
}
if (
    strlen($password) < 8 ||
    !preg_match('/[A-Z]/', $password) ||
    !preg_match('/[a-z]/', $password) ||
    !preg_match('/[0-9]/', $password) ||
    !preg_match('/[^A-Za-z0-9]/', $password)
) {
    fail('Password does not meet the required strength.', 400);
}

// ---- Transactional create ---------------------------------------------------
$pdo = db();
$pdo->beginTransaction();

try {
    // Verify the department exists. FOR UPDATE locks the row against deletion.
    $stmt = $pdo->prepare('SELECT id FROM departments WHERE id = ? FOR UPDATE');
    $stmt->execute([$deptId]);
    if (!$stmt->fetchColumn()) {
        $pdo->rollBack();
        fail('Selected department does not exist.', 400);
    }

    // Uniqueness checks — inside the transaction to prevent races.
    $stmt = $pdo->prepare(
        'SELECT id FROM hr_users
         WHERE username = :u OR email = :e OR hr_code = :h
         LIMIT 1
         FOR UPDATE'
    );
    $stmt->execute([':u' => $username, ':e' => $email, ':h' => $hrCode]);
    if ($stmt->fetchColumn()) {
        $pdo->rollBack();
        fail('That username, email or HR code is already registered.', 409);
    }

    // Create the linked employee row first so hr_users can reference it.
    // We use the HR code as the employee_code value — one-to-one mapping.
    $empCode  = $hrCode;
    $nameParts = preg_split('/\s+/', $fullName, 2);
    $first    = $nameParts[0] ?? $fullName;
    $last     = $nameParts[1] ?? '';

    $pdo->prepare(
        'INSERT INTO employees
            (employee_code, firstname, lastname, email, department_id, position, status)
         VALUES (?, ?, ?, ?, ?, ?, "Active")'
    )->execute([
        $empCode,
        $first,
        $last,
        $email,
        $deptId,
        'HR',  // Position placeholder — HR can update later
    ]);
    $employeeId = (int)$pdo->lastInsertId();

    // Now create the login account.
    $hash = password_hash($password, PASSWORD_DEFAULT);

    $pdo->prepare(
        'INSERT INTO hr_users
            (employee_id, username, email, password_hash, role, full_name, hr_code, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, "active")'
    )->execute([
        $employeeId,
        $username,
        $email,
        $hash,
        $role,
        $fullName,
        $hrCode,
    ]);
    $newUserId = (int)$pdo->lastInsertId();

    $pdo->commit();

    audit(
        'register_success',
        'auth',
        sprintf('New %s account created: %s (%s)', $role, $username, $email)
    );

    // Return minimal identity — never the hash.
    ok([
        'user' => [
            'id'        => $newUserId,
            'username'  => $username,
            'email'     => $email,
            'full_name' => $fullName,
            'role'      => $role,
            'hr_code'   => $hrCode,
        ],
    ], 'Account created.');

} catch (PDOException $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    // Handle unique constraint race — if someone slipped in between our check
    // and insert, we still return a clean error rather than a 500.
    if ($e->getCode() === '23000') {
        fail('That username, email or HR code is already registered.', 409);
    }

    error_log('[hr_register] ' . $e->getMessage());
    fail('Registration failed. Please try again.', 500);

} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('[hr_register] unexpected: ' . $e->getMessage());
    fail('Registration failed. Please try again.', 500);
}