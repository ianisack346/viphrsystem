<?php
/**
 * csrf_token.php
 * Issues a CSRF token bound to the current session.
 */

declare(strict_types=1);

require_once __DIR__ . '/hr_bootstrap.php';

only_method('GET');

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');

const CSRF_LIFETIME_SECONDS = 1800;

$rotate = isset($_GET['rotate']) && $_GET['rotate'] === '1';

if ($rotate || empty($_SESSION['csrf'])) {
    $_SESSION['csrf']           = bin2hex(random_bytes(32));
    $_SESSION['csrf_issued_at'] = time();
}

if (
    !empty($_SESSION['csrf_issued_at'])
    && (time() - (int)$_SESSION['csrf_issued_at']) > CSRF_LIFETIME_SECONDS
) {
    $_SESSION['csrf']           = bin2hex(random_bytes(32));
    $_SESSION['csrf_issued_at'] = time();
}

json_out([
    'success'    => true,
    'csrf'       => $_SESSION['csrf'],
    'expires_in' => CSRF_LIFETIME_SECONDS,
    'issued_at'  => (int)($_SESSION['csrf_issued_at'] ?? time()),
]);
?>