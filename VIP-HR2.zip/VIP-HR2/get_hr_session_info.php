<?php
declare(strict_types=1);
require_once __DIR__ . '/hr_bootstrap.php';

only_method('GET');

$user = current_user();
if (!$user) {
    fail('Not authenticated.', 401);
}

$stmt = db()->prepare('SELECT id, username, email, role, full_name, profile_photo, hr_code, status FROM hr_users WHERE id = ? LIMIT 1');
$stmt->execute([$user['id']]);
$row = $stmt->fetch();

if (!$row || $row['status'] !== 'active') {
    $_SESSION = [];
    session_destroy();
    fail('Account no longer active.', 401);
}

$_SESSION['hr_user'] = [
    'id'            => (int)$row['id'],
    'username'      => $row['username'],
    'email'         => $row['email'],
    'full_name'     => $row['full_name'],
    'role'          => $row['role'],
    'hr_code'       => $row['hr_code'],
    'profile_photo' => $row['profile_photo'] ?: 'logo.png',
];

ok([
    'user'    => $_SESSION['hr_user'],
    'hr_code' => $row['hr_code'],
    'csrf'    => csrf_token(),
]);