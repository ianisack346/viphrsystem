<?php
require_once __DIR__ . '/includes/auth.php';
require_role(['hr', 'admin']);

$db = (new Database())->getConnection();
$status = enum_field($_GET, 'status', ['active', 'inactive']);

// This endpoint is only reachable by authenticated HR/admin staff, so it
// always returns the full management view regardless of the hr_view flag
// the frontend sends — audience targeting is enforced on the employee
// portal, not here.
$sql = "SELECT a.id, a.title, a.message, a.audience, a.target_role, a.target_department_id,
               a.status, COALESCE(hu.full_name, 'HR') AS posted_by, a.date_posted
        FROM announcements a
        LEFT JOIN hr_users hu ON hu.id = a.posted_by
        WHERE 1=1";
$params = [];
if ($status) {
    $sql .= ' AND a.status = ?';
    $params[] = $status;
}
$sql .= ' ORDER BY a.date_posted DESC';

$limit = min(200, max(1, int_field($_GET, 'limit', 100)));
$sql .= ' LIMIT ' . $limit;

$stmt = $db->prepare($sql);
$stmt->execute($params);

json_ok(['data' => $stmt->fetchAll()]);
