<?php
require_once __DIR__ . '/includes/auth.php';
require_role(['hr', 'admin']);

$db = (new Database())->getConnection();

function format_bytes(int $bytes): string
{
    $units = ['B', 'KB', 'MB', 'GB'];
    $size = abs($bytes);
    $i = 0;
    while ($size >= 1024 && $i < count($units) - 1) {
        $size /= 1024;
        $i++;
    }
    return round($size, 2) . ' ' . $units[$i];
}

$sql = "SELECT d.id, d.title, d.description, d.document_type, d.file_name, d.file_type, d.file_size,
               d.version_count, d.status, d.expiry_date, d.upload_date, d.download_count,
               dept.name AS department_name,
               e.firstname AS emp_first_name, e.lastname AS emp_last_name,
               hu.full_name AS uploaded_by_name
        FROM documents d
        LEFT JOIN departments dept ON dept.id = d.department_id
        LEFT JOIN employees e ON e.id = d.employee_id
        LEFT JOIN hr_users hu ON hu.id = d.uploaded_by
        WHERE d.deleted_at IS NULL
        ORDER BY d.upload_date DESC";
$rows = $db->query($sql)->fetchAll();

$totalStorage = 0;
$typeDistribution = [];
$recentUploads = 0;
$cutoff = strtotime('-7 days');

foreach ($rows as &$r) {
    $totalStorage += (int)$r['file_size'];
    $r['file_size_formatted'] = format_bytes((int)$r['file_size']);
    $typeDistribution[$r['document_type']] = ($typeDistribution[$r['document_type']] ?? 0) + 1;
    if (strtotime($r['upload_date']) >= $cutoff) {
        $recentUploads++;
    }
}
unset($r);

json_ok([
    'data' => $rows,
    'total_count' => count($rows),
    'statistics' => [
        'total_storage' => $totalStorage,
        'recent_uploads' => $recentUploads,
        'type_distribution' => array_map(
            fn($k, $v) => ['type' => $k, 'count' => $v],
            array_keys($typeDistribution),
            $typeDistribution
        ),
    ],
]);
