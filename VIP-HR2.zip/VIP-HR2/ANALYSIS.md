# FortishieldMatrix HR — Backend Analysis & Rebuild

## Method
Every `fetch('*.php')` / `fetch(\`*.php\`)` / `window.open('*.php')` call in
`HR_Management_system.html` was extracted programmatically (not guessed) to
build a complete, accurate inventory. **41 distinct PHP endpoints** are
referenced by the frontend. All 41 are rebuilt below with their exact
filenames unchanged, so the existing frontend needs zero edits.

## Shared foundation (new — everything below depends on these)
| File | Purpose |
|---|---|
| `includes/config.php` | DB credentials (from environment, never hardcoded), session hardening, error-display policy, upload limits |
| `includes/db_connect.php` | `Database` class → PDO singleton, `ATTR_EMULATE_PREPARES=false`, exceptions on error |
| `includes/auth.php` | Session bootstrap, `require_login()`, `require_role()`, CSRF/Origin check, login-throttle helper |
| `includes/functions.php` | `json_ok()/json_error()`, input sanitizers, `log_audit()`, pagination helper, safe file-upload helper |
| `sql/schema.sql` | Full MariaDB schema every endpoint below assumes |

## Endpoint inventory — what each does / was made to do

### Session & system
| File | Method | Does |
|---|---|---|
| `get_hr_session_info.php` | GET | Returns the logged-in HR user's name/role/photo from the session |
| `logout.php` | GET/POST | Destroys session, clears cookie |
| `get_dashboard_stats.php` | GET | Employee/leave/attendance/training counts for dashboard cards |
| `get_recent_activity.php` | GET | Recent audit-log entries for the activity panel |
| `get_hr_audit_logs.php` | GET | Full audit log table |
| `get_attendance_heatmap.php` | GET | Last-5-workdays present/late/absent counts |
| `hr_settings_handler.php` | GET/POST | Load/save system settings (key-value store) |

### Employees & departments
| File | Method | Does |
|---|---|---|
| `get_all_employeess.php` | GET | List employees (joined with department name) |
| `addEmployee.php` | POST | Create employee (validated, duplicate-checked) |
| `get_hr_departments.php` | GET | List departments |

### Leave management
| File | Method | Does |
|---|---|---|
| `get_LeaveRequests.php` | GET | List leave requests (optional `status` filter) |
| `createLeaveRequest.php` | POST | HR creates a leave request on an employee's behalf |
| `hr_leave_action.php` | POST | Approve/reject a leave request |
| `hr_leave_letter.php` | GET/POST | Preview or send the approval/rejection letter |
| `hr_leave_handler.php` | GET/POST | The logged-in HR user's own leave (list/request/cancel) — "My Leave" |
| `getLeaveHistory.php` | GET | (Legacy helper, kept for compatibility) |

### Attendance
| File | Method | Does |
|---|---|---|
| `getAttendanceData.php` | GET | All-employee attendance records table |
| `hr_attendance_handler.php` | GET/POST | HR's own check-in/check-out ("Attendance Surf") |
| `getHrTimeBook.php` | GET | HR check-in/out log ("Time Book") |

### Performance
| File | Method | Does |
|---|---|---|
| `get_performance_reviews.php` | GET | List performance reviews |
| `save_performance_review.php` | POST | Create/update a review (draft or completed) |

### Training
| File | Method | Does |
|---|---|---|
| `get_trainings.php` | GET | List trainings |
| `save_training.php` | POST | Create a training (draft or published) |
| `get_UpcomingTrainings.php` | GET | Next 5 trainings, for dashboard |

### Recruitment (job postings + RMS applications)
| File | Method | Does |
|---|---|---|
| `save_recruitment.php` | POST | Post a job vacancy |
| `getRecruitmentData.php` | GET | List candidate applications against vacancies |
| `delete_recruitment.php` | POST | Delete a vacancy |
| `get_application_detail.php` | GET | Full application (candidate, docs, education, status tracker) |
| `update_application_status.php` | POST | Change application status / advance a tracker stage |

### Documents
| File | Method | Does |
|---|---|---|
| `getDocumentsData.php` | GET | Document library + storage statistics |
| `getDocumentDetails.php` | GET | Single document metadata |
| `uploadDocument.php` | POST (multipart) | Upload a document (type/size validated, stored outside guessable paths) |
| `updateDocument.php` | POST (multipart) | Update metadata and/or replace file (new version) |
| `deleteDocument.php` | POST | Soft-delete a document |
| `downloadDocument.php` | GET | Stream a document file, increments download counter |
| `get_hr_document_requests.php` | GET | Employee document requests queue |
| `update_document_request.php` | POST | Approve/deny/complete a document request |
| `generate_hr_document.php` | POST | Generate offer letter / contract / warning / NDA HTML |

### Meetings
| File | Method | Does |
|---|---|---|
| `hr_meeting_handler.php` | POST | Schedule/cancel a meeting |
| `get_UpcomingMeetings.php` | GET | List meetings (limit param; also used for meetings table) |

### Announcements
| File | Method | Does |
|---|---|---|
| `get_announcements.php` | GET | List announcements, audience-filtered |
| `create_announcement.php` | POST (multipart) | Create an announcement *(referenced by the form's `enctype`; wired in even though it wasn't in the strict fetch-scan, since the Save button posts to it)* |

### Payroll
| File | Method | Does |
|---|---|---|
| `get_hr_payroll_data.php` | GET | Payroll list + summary stats |
| `process_hr_payroll.php` | POST | Create a payroll record *(referenced by `submitPayroll()`)* |

### Events (dashboard widget)
| File | Method | Does |
|---|---|---|
| `get_UpcomingEvents.php` | GET | Next 5 company events |

## Security model applied to every file
1. **PDO prepared statements only** — no string-built SQL anywhere.
2. **Session + role gate** (`require_role(['hr','admin'])`) on every endpoint except the two explicitly public ones (none — this whole dashboard is internal).
3. **CSRF/Origin check** on every state-changing (POST) request — rejects cross-site requests even though the frontend uses cookie-session auth.
4. **Input validation & whitelisting** — enums checked against fixed lists, IDs cast to `int`, dates validated, no raw `$_POST`/`$_GET` reaches a query.
5. **File uploads**: extension + real MIME-sniff whitelist, size cap, random filename (no user-controlled path), stored under `uploads/` with an `.htaccess` that strips PHP execution.
6. **No stack traces to the client** — errors are logged server-side (`error_log`), client gets a generic JSON error.
7. **Audit logging** — every create/update/delete/approve/reject action writes an `audit_logs` row.
8. **Least-privilege JSON responses** — password hashes, internal notes on candidate flags, etc. never serialized back to the client.
