<?php
require_once __DIR__ . '/includes/auth.php';
$user = require_role(['hr', 'admin']);

$db = (new Database())->getConnection();
$body = json_body();

$positionTitle = str_field($body, 'position_title');
$departmentName = str_field($body, 'department');
$closingDate = str_field($body, 'closing_date');

if (!$positionTitle || !$departmentName || !is_valid_date($closingDate)) {
    json_error('Position title, department, and a valid closing date are required.', 400);
}

$departmentId = null;
$stmt = $db->prepare('SELECT id FROM departments WHERE name = ? LIMIT 1');
$stmt->execute([$departmentName]);
$dept = $stmt->fetch();
$departmentId = $dept ? (int)$dept['id'] : null;

$priority = enum_field($body, 'priority', ['Low', 'Medium', 'High', 'Urgent'], 'Medium');

$stmt = $db->prepare(
    'INSERT INTO recruitment_vacancies
        (position_title, department_id, job_description, job_requirements, closing_date, priority,
         employment_type, min_qualification, experience_years, num_posts, location, salary_min,
         salary_max, salary_grade, internal_notes, status, posted_by)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "open", ?)'
);
$stmt->execute([
    $positionTitle,
    $departmentId,
    str_field($body, 'job_description'),
    str_field($body, 'job_requirements'),
    $closingDate,
    $priority,
    str_field($body, 'employment_type'),
    str_field($body, 'min_qualification'),
    int_field($body, 'experience_years', 0),
    int_field($body, 'num_posts', 1),
    str_field($body, 'location'),
    float_field($body, 'salary_min'),
    float_field($body, 'salary_max'),
    str_field($body, 'salary_grade'),
    str_field($body, 'internal_notes'),
    $user['id'],
]);
$id = (int)$db->lastInsertId();

$notified = !empty($body['notify']);
log_audit($db, (int)$user['id'], 'vacancy_posted', 'recruitment', "Posted vacancy \"$positionTitle\"" . ($notified ? ' (candidates notified)' : ''));

json_ok(['message' => 'Vacancy posted', 'id' => $id], 201);
