<?php
require_once __DIR__ . '/includes/auth.php';
require_role(['hr', 'admin']);

$db = (new Database())->getConnection();

// Last 5 workdays ending today (Mon-Fri), oldest first.
$days = [];
$cursor = new DateTime('today');
while (count($days) < 5) {
    $dow = (int)$cursor->format('N'); // 1=Mon .. 7=Sun
    if ($dow <= 5) {
        $days[] = $cursor->format('Y-m-d');
    }
    $cursor->modify('-1 day');
}
$days = array_reverse($days);

$present = [];
$late = [];
$absent = [];
$labels = [];

$stmt = $db->prepare(
    "SELECT status, COUNT(*) c FROM attendance_records WHERE date = ? GROUP BY status"
);

foreach ($days as $date) {
    $stmt->execute([$date]);
    $counts = ['present' => 0, 'present_late' => 0, 'late' => 0, 'absent' => 0];
    foreach ($stmt->fetchAll() as $row) {
        $counts[$row['status']] = (int)$row['c'];
    }
    $labels[] = (new DateTime($date))->format('D');
    $present[] = $counts['present'] + $counts['present_late'];
    $late[] = $counts['late'];
    $absent[] = $counts['absent'];
}

json_ok([
    'days' => $labels,
    'present' => $present,
    'late' => $late,
    'absent' => $absent,
]);
