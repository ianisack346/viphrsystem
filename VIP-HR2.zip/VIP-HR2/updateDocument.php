<?php
require_once __DIR__ . '/includes/auth.php';
$user = require_role(['hr', 'admin']);

$db = (new Database())->getConnection();
$id = int_field($_POST, 'document_id');
if (!$id) {
    json_error('document_id is required.', 400);
}

$stmt = $db->prepare('SELECT * FROM documents WHERE id = ? AND deleted_at IS NULL LIMIT 1');
$stmt->execute([$id]);
$doc = $stmt->fetch();
if (!$doc) {
    json_error('Document not found.', 404);
}

$title = str_field($_POST, 'title', $doc['title']);
$description = str_field($_POST, 'description', $doc['description']);
$docType = str_field($_POST, 'document_type', $doc['document_type']);
$departmentId = int_field($_POST, 'department_id', $doc['department_id']);
$accessLevel = enum_field($_POST, 'access_level', ['private', 'department', 'public'], $doc['access_level']);
$expiryDateRaw = str_field($_POST, 'expiry_date');
$expiryDate = is_valid_date($expiryDateRaw) ? $expiryDateRaw : $doc['expiry_date'];

$newStoredName = $doc['stored_name'];
$newFileName = $doc['file_name'];
$newFileType = $doc['file_type'];
$newFileSize = $doc['file_size'];
$versionIncrement = 0;

if (!empty($_FILES['document']) && $_FILES['document']['error'] !== UPLOAD_ERR_NO_FILE) {
    $uploaded = handle_secure_upload($_FILES['document'], DOC_UPLOAD_DIR, ALLOWED_DOC_EXT, ALLOWED_DOC_MIME, MAX_UPLOAD_BYTES);
    // Remove the old physical file only after the new one is safely stored.
    $oldPath = DOC_UPLOAD_DIR . '/' . $doc['stored_name'];
    if (is_file($oldPath)) {
        @unlink($oldPath);
    }
    $newStoredName = $uploaded['stored_name'];
    $newFileName = $uploaded['file_name'];
    $newFileType = pathinfo($uploaded['file_name'], PATHINFO_EXTENSION);
    $newFileSize = $uploaded['size'];
    $versionIncrement = 1;
}

$stmt = $db->prepare(
    'UPDATE documents SET title=?, description=?, document_type=?, department_id=?, access_level=?,
     expiry_date=?, file_name=?, stored_name=?, file_type=?, file_size=?, version_count = version_count + ?
     WHERE id = ?'
);
$stmt->execute([
    $title, $description, $docType, $departmentId, $accessLevel, $expiryDate,
    $newFileName, $newStoredName, $newFileType, $newFileSize, $versionIncrement, $id,
]);

log_audit($db, (int)$user['id'], 'document_updated', 'documents', "Updated document #$id");
json_ok(['message' => 'Document updated']);
