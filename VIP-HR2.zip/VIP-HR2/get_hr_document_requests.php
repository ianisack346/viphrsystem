<?php
require_once __DIR__ . '/includes/auth.php';
require_role(['hr', 'admin']);

$db = (new Database())->getConnection();
$status = enum_field($_GET, 'status', ['pending', 'approved', 'denied', 'completed']);
$urgency = enum_field($_GET, 'urgency', ['normal', 'urgent', 'immediate']);

$sql = "SELECT dr.id, dr.employee_id, CONCAT(e.firstname, ' ', e.lastname) AS employee_name,
               e.employee_code, d.name AS department, dr.document_type, dr.reason, dr.urgency,
               dr.status, dr.created_at
        FROM document_requests dr
        JOIN employees e ON e.id = dr.employee_id
        LEFT JOIN departments d ON d.id = e.department_id
        WHERE 1=1";
$params = [];
if ($status) {
    $sql .= ' AND dr.status = ?';
    $params[] = $status;
}
if ($urgency) {
    $sql .= ' AND dr.urgency = ?';
    $params[] = $urgency;
}
$sql .= ' ORDER BY FIELD(dr.urgency,"immediate","urgent","normal"), dr.created_at DESC';

$stmt = $db->prepare($sql);
$stmt->execute($params);

json_ok(['requests' => $stmt->fetchAll()]);
