<?php
require_once __DIR__ . '/includes/auth.php';

$user = current_user();
if ($user) {
    $db = (new Database())->getConnection();
    log_audit($db, (int)$user['id'], 'logout', 'auth', $user['full_name'] . ' logged out');
}

$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $p = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
}
session_destroy();

json_ok(['message' => 'Logged out']);
