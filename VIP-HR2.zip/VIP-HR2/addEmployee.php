<?php
require_once __DIR__ . '/includes/auth.php';
$user = require_role(['hr', 'admin']);

$db = (new Database())->getConnection();
$body = json_body();

$employeeCode = str_field($body, 'employee_id'); // free-text code from the Add Employee form
$firstName = str_field($body, 'first_name');
$lastName = str_field($body, 'last_name');
$email = str_field($body, 'email');
$departmentName = str_field($body, 'department');
$position = str_field($body, 'position');
$status = enum_field($body, 'status', ['active', 'inactive'], 'active');

if (!$employeeCode || !$firstName || !$lastName) {
    json_error('Employee ID, first name and last name are required.', 400);
}
if ($email && !is_valid_email($email)) {
    json_error('Invalid email address.', 400);
}
if (!$email) {
    // addEmployee.php's caller always derives an email, but guard anyway.
    $email = strtolower(preg_replace('/[^a-z0-9]/i', '', $employeeCode)) . '@company.local';
}

// Duplicate checks
$stmt = $db->prepare('SELECT id FROM employees WHERE employee_code = ? OR email = ? LIMIT 1');
$stmt->execute([$employeeCode, $email]);
if ($stmt->fetch()) {
    json_error('An employee with that code or email already exists.', 409);
}

$departmentId = null;
if ($departmentName) {
    $stmt = $db->prepare('SELECT id FROM departments WHERE name = ? LIMIT 1');
    $stmt->execute([$departmentName]);
    $dept = $stmt->fetch();
    if ($dept) {
        $departmentId = (int)$dept['id'];
    } else {
        $stmt = $db->prepare('INSERT INTO departments (name) VALUES (?)');
        $stmt->execute([$departmentName]);
        $departmentId = (int)$db->lastInsertId();
    }
}

$stmt = $db->prepare(
    'INSERT INTO employees (employee_code, firstname, lastname, email, department_id, position, status, date_hired)
     VALUES (?, ?, ?, ?, ?, ?, ?, CURDATE())'
);
$stmt->execute([
    $employeeCode,
    $firstName,
    $lastName,
    $email,
    $departmentId,
    $position,
    ucfirst(strtolower($status)),
]);
$newId = (int)$db->lastInsertId();

log_audit($db, (int)$user['id'], 'employee_added', 'employees', "Added employee {$firstName} {$lastName} ({$employeeCode})");

json_ok(['message' => 'Employee created', 'id' => $newId], 201);
