"""config.py — loads .env, exposes Config class"""
import os
from dotenv import load_dotenv

load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env"))


class Config:
    APP_ENV = os.getenv("APP_ENV", "production")
    SECRET_KEY = os.getenv("SECRET_KEY", os.urandom(32).hex())

    DB_HOST = os.getenv("DB_HOST", "127.0.0.1")
    DB_PORT = int(os.getenv("DB_PORT", "3306"))
    DB_NAME = os.getenv("DB_NAME", "vip_hr")
    DB_USER = os.getenv("DB_USER", "VIP_hr_app")
    DB_PASS = os.getenv("DB_PASS", "")

    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    UPLOAD_ROOT = os.path.abspath(os.path.join(BASE_DIR, "..", "uploads"))
    DOC_UPLOAD_DIR = os.path.join(UPLOAD_ROOT, "documents")
    PHOTO_UPLOAD_DIR = os.path.join(UPLOAD_ROOT, "photos")
    RECRUITMENT_UPLOAD_DIR = os.path.join(UPLOAD_ROOT, "recruitment")

    MAX_UPLOAD_BYTES = 50 * 1024 * 1024
    ALLOWED_DOC_EXT = {"pdf", "doc", "docx", "xls", "xlsx", "jpg", "jpeg", "png"}
    ALLOWED_DOC_MIME = {
        "application/pdf",
        "application/msword",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/vnd.ms-excel",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "image/jpeg",
        "image/png",
    }

    SESSION_COOKIE_NAME = "VIP_HRSESS"
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = os.getenv("SESSION_COOKIE_SECURE", "0") == "1"
    PERMANENT_SESSION_LIFETIME = 1800

    TIMEZONE = "Africa/Nairobi"