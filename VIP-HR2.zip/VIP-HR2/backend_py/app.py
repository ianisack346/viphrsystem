"""app.py — Flask entrypoint. Serves the frontend AND the API."""
import os
from flask import Flask, jsonify, send_from_directory
from config import Config

from db import close_db

from routes.auth_routes import bp as auth_bp
from routes.dashboard import bp as dashboard_bp
from routes.employees import bp as employees_bp
from routes.leave import bp as leave_bp
from routes.attendance import bp as attendance_bp
from routes.performance import bp as performance_bp
from routes.training import bp as training_bp
from routes.recruitment import bp as recruitment_bp
from routes.announcements import bp as announcements_bp
from routes.documents import bp as documents_bp
from routes.payroll import bp as payroll_bp
from routes.meetings import bp as meetings_bp
from routes.audit import bp as audit_bp
from routes.departments import bp as departments_bp
from routes.settings import bp as settings_bp
from routes.device_pull import bp as device_pull_bp
from routes.attendance_aggregator import bp as attendance_agg_bp


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    app.config["SESSION_COOKIE_NAME"] = Config.SESSION_COOKIE_NAME
    app.config["SESSION_COOKIE_HTTPONLY"] = Config.SESSION_COOKIE_HTTPONLY
    app.config["SESSION_COOKIE_SAMESITE"] = Config.SESSION_COOKIE_SAMESITE
    app.config["SESSION_COOKIE_SECURE"] = Config.SESSION_COOKIE_SECURE
    app.config["PERMANENT_SESSION_LIFETIME"] = Config.PERMANENT_SESSION_LIFETIME

    os.makedirs(Config.DOC_UPLOAD_DIR, exist_ok=True)
    os.makedirs(Config.PHOTO_UPLOAD_DIR, exist_ok=True)
    os.makedirs(Config.RECRUITMENT_UPLOAD_DIR, exist_ok=True)

    for blueprint in (
        auth_bp, dashboard_bp, employees_bp, leave_bp, attendance_bp,
        performance_bp, training_bp, recruitment_bp, announcements_bp,
        documents_bp, payroll_bp, meetings_bp, audit_bp, departments_bp,
        settings_bp, device_pull_bp, attendance_agg_bp,
    ):
        app.register_blueprint(blueprint)

    app.teardown_appcontext(close_db)

    PROJECT_ROOT = os.path.abspath(os.path.join(Config.BASE_DIR, ".."))

    @app.route("/")
    def index():
        return send_from_directory(PROJECT_ROOT, "vip_hr_login.html")

    @app.route("/<path:filename>")
    def static_files(filename):
        if filename.endswith(".php"):
            return jsonify({"success": False,
                            "message": "This endpoint is not implemented in Python."}), 404
        return send_from_directory(PROJECT_ROOT, filename)

    @app.errorhandler(404)
    def not_found(_):
        return jsonify({"success": False, "message": "Endpoint not found."}), 404

    @app.errorhandler(500)
    def server_error(_):
        return jsonify({"success": False, "message": "Server error."}), 500

    # Start background scheduler
    from scheduler import start_scheduler
    start_scheduler(app)

    return app


if __name__ == "__main__":
    application = create_app()
    debug_mode = os.getenv("APP_ENV", "production") == "development"
    # Disable Flask reloader in dev when scheduler is active, to avoid
    # double-starting the background job
    application.run(host="127.0.0.1", port=5000,
                    debug=debug_mode, use_reloader=False)