"""db.py — per-request MySQL connection (thread-safe)"""
import pymysql
from pymysql.cursors import DictCursor
from flask import g
from config import Config


def _new_conn():
    return pymysql.connect(
        host=Config.DB_HOST,
        port=Config.DB_PORT,
        user=Config.DB_USER,
        password=Config.DB_PASS,
        database=Config.DB_NAME,
        charset="utf8mb4",
        cursorclass=DictCursor,
        autocommit=False,
    )


def db():
    """Returns a connection scoped to the current Flask request."""
    conn = getattr(g, "_db_conn", None)
    if conn is None or not getattr(conn, "open", False):
        conn = _new_conn()
        g._db_conn = conn
    return conn


class Database:
    """Legacy shim — same as PHP's Database class."""
    def getConnection(self):
        return db()


def close_db(exception=None):
    conn = g.pop("_db_conn", None)
    if conn is not None and getattr(conn, "open", False):
        try:
            conn.close()
        except Exception:
            pass