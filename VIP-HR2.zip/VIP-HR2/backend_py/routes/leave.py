"""leave.py — get_LeaveRequests, createLeaveRequest, hr_leave_action,
hr_leave_handler, hr_leave_letter"""
from datetime import datetime
from flask import Blueprint, request, g, jsonify
from db import db
from helpers import (
    json_ok, json_error, json_body, str_field, int_field, enum_field,
    is_valid_date, log_audit, h,
)
from auth import role_required, login_required

bp = Blueprint("leave", __name__)
ANNUAL_ENTITLEMENT = 28


@bp.route("/get_LeaveRequests.php", methods=["GET"])
@role_required(["hr", "admin"])
def get_leave_requests():
    conn = db()
    status = enum_field(request.args, "status", ["pending", "approved", "rejected"])
    sql = (
        "SELECT lr.leave_id, e.employee_code, e.id AS employee_id, "
        "e.firstname AS first_name, e.lastname AS last_name, d.name AS department, "
        "lr.leave_type, lr.start_date, lr.end_date, lr.days, lr.status, lr.reason, "
        "lr.admin_notes, lr.proof_document, lr.proof_name, lr.proof_uploaded_at, "
        "lr.proof_status, lr.attachment, lr.attachment_name, lr.created_at "
        "FROM leave_requests lr "
        "JOIN employees e ON e.id = lr.employee_id "
        "LEFT JOIN departments d ON d.id = e.department_id"
    )
    params = []
    if status:
        sql += " WHERE lr.status = %s"
        params.append(status)
    sql += " ORDER BY lr.created_at DESC"

    with conn.cursor() as cur:
        cur.execute(sql, params)
        rows = cur.fetchall()
    for r in rows:
        for k in ("start_date", "end_date", "created_at", "proof_uploaded_at"):
            if r.get(k) is not None:
                r[k] = str(r[k])
    return jsonify(rows), 200


@bp.route("/createLeaveRequest.php", methods=["POST"])
@role_required(["hr", "admin"])
def create_leave_request():
    conn = db()
    body = json_body()

    employee_code = str_field(body, "employee_id")
    leave_type = str_field(body, "leave_type")
    start_date = str_field(body, "start_date")
    end_date = str_field(body, "end_date")
    reason = str_field(body, "reason")

    if not employee_code or not leave_type or not is_valid_date(start_date) or not is_valid_date(end_date):
        return json_error("Employee code, leave type, and valid start/end dates are required.", 400)
    if end_date < start_date:
        return json_error("End date must be on or after the start date.", 400)

    with conn.cursor() as cur:
        cur.execute("SELECT id FROM employees WHERE employee_code=%s LIMIT 1", (employee_code,))
        emp = cur.fetchone()
        if not emp:
            return json_error("No employee found with that code.", 404)

        days = (datetime.strptime(end_date, "%Y-%m-%d")
                - datetime.strptime(start_date, "%Y-%m-%d")).days + 1

        cur.execute(
            "INSERT INTO leave_requests "
            "(employee_id, leave_type, start_date, end_date, days, reason, status) "
            "VALUES (%s, %s, %s, %s, %s, %s, 'pending')",
            (emp["id"], leave_type, start_date, end_date, days, reason),
        )
        leave_id = cur.lastrowid
    conn.commit()

    log_audit(conn, int(g.current_user["id"]), "leave_created", "leave",
              f"Created leave request #{leave_id} for employee {employee_code}")
    return json_ok({"message": "Leave request created", "leave_id": leave_id}, status=201)


@bp.route("/hr_leave_action.php", methods=["POST"])
@role_required(["hr", "admin"])
def hr_leave_action():
    conn = db()
    body = json_body()
    action = enum_field(body, "action", ["approve", "reject"])
    leave_id = int_field(body, "leave_id")
    if not action or not leave_id:
        return json_error("Action and leave_id are required.", 400)

    with conn.cursor() as cur:
        cur.execute("SELECT * FROM leave_requests WHERE leave_id=%s LIMIT 1", (leave_id,))
        leave = cur.fetchone()
        if not leave:
            return json_error("Leave request not found.", 404)
        if leave["status"] != "pending":
            return json_error("This leave request has already been processed.", 409)

        if action == "approve":
            comment = str_field(body, "comment")
            cur.execute(
                "UPDATE leave_requests SET status='approved', admin_notes=%s, "
                "approved_by=%s, approved_at=NOW() WHERE leave_id=%s",
                (comment, g.current_user["id"], leave_id),
            )
            conn.commit()
            log_audit(conn, int(g.current_user["id"]), "leave_approved", "leave",
                      f"Approved leave #{leave_id}")
            return json_ok({"message": "Leave approved"})

        reason = str_field(body, "reason")
        if not reason:
            return json_error("A reason is required to reject a leave request.", 400)
        cur.execute(
            "UPDATE leave_requests SET status='rejected', admin_notes=%s, "
            "approved_by=%s, approved_at=NOW() WHERE leave_id=%s",
            (reason, g.current_user["id"], leave_id),
        )
    conn.commit()
    log_audit(conn, int(g.current_user["id"]), "leave_rejected", "leave",
              f"Rejected leave #{leave_id}: {reason}")
    return json_ok({"message": "Leave rejected"})


@bp.route("/hr_leave_handler.php", methods=["GET", "POST"])
@login_required
def hr_leave_handler():
    conn = db()
    user = g.current_user
    method = request.method
    body = json_body() if method == "POST" else {}
    action = request.args.get("action") or body.get("action")

    if method == "GET" and action == "list":
        status = enum_field(request.args, "status", ["pending", "approved", "rejected"])
        sql = ("SELECT id, leave_type, start_date, end_date, days, reason, status, created_at "
               "FROM hr_leave_requests WHERE hr_user_id=%s")
        params = [user["id"]]
        if status:
            sql += " AND status=%s"
            params.append(status)
        sql += " ORDER BY created_at DESC"
        with conn.cursor() as cur:
            cur.execute(sql, params)
            leaves = cur.fetchall()

        for l in leaves:
            for k in ("start_date", "end_date", "created_at"):
                if l.get(k):
                    l[k] = str(l[k])

        taken = sum(int(l["days"]) for l in leaves if l["status"] == "approved")
        pending = sum(1 for l in leaves if l["status"] == "pending")
        return json_ok({
            "summary": {
                "entitlement": ANNUAL_ENTITLEMENT,
                "taken": taken,
                "remaining": max(0, ANNUAL_ENTITLEMENT - taken),
                "pending": pending,
            },
            "leaves": leaves,
        })

    if method == "POST" and action == "request":
        leave_type = str_field(body, "leave_type")
        start_date = str_field(body, "start_date")
        end_date = str_field(body, "end_date")
        reason = str_field(body, "reason")
        if not leave_type or not is_valid_date(start_date) or not is_valid_date(end_date) or not reason:
            return json_error("All fields are required.", 400)
        if end_date < start_date:
            return json_error("End date must be on or after the start date.", 400)
        days = (datetime.strptime(end_date, "%Y-%m-%d")
                - datetime.strptime(start_date, "%Y-%m-%d")).days + 1
        with conn.cursor() as cur:
            cur.execute(
                "INSERT INTO hr_leave_requests "
                "(hr_user_id, leave_type, start_date, end_date, days, reason, status) "
                "VALUES (%s, %s, %s, %s, %s, %s, 'pending')",
                (user["id"], leave_type, start_date, end_date, days, reason),
            )
        conn.commit()
        log_audit(conn, int(user["id"]), "hr_leave_requested", "leave",
                  "Requested personal leave")
        return json_ok({"message": "Leave request submitted"}, status=201)

    if method == "POST" and action == "cancel":
        leave_id = int_field(body, "leave_id")
        if not leave_id:
            return json_error("leave_id is required.", 400)
        with conn.cursor() as cur:
            cur.execute(
                "SELECT id, status FROM hr_leave_requests WHERE id=%s AND hr_user_id=%s",
                (leave_id, user["id"]),
            )
            row = cur.fetchone()
            if not row:
                return json_error("Leave request not found.", 404)
            if row["status"] == "rejected":
                return json_error("This leave has already been rejected.", 409)
            cur.execute("DELETE FROM hr_leave_requests WHERE id=%s", (leave_id,))
        conn.commit()
        log_audit(conn, int(user["id"]), "hr_leave_cancelled", "leave",
                  f"Cancelled personal leave #{leave_id}")
        return json_ok({"message": "Leave cancelled"})

    return json_error("Unsupported request.", 400)


def _fetch_leave_with_employee(conn, leave_id):
    with conn.cursor() as cur:
        cur.execute(
            "SELECT lr.*, e.firstname, e.lastname, e.email, e.employee_code "
            "FROM leave_requests lr JOIN employees e ON e.id = lr.employee_id "
            "WHERE lr.leave_id=%s LIMIT 1",
            (leave_id,),
        )
        return cur.fetchone()


def _build_letter_html(leave):
    name = h(f"{leave['firstname']} {leave['lastname']}")
    decision = "approved" if leave["status"] == "approved" else "declined"
    color = "#2ecc71" if leave["status"] == "approved" else "#e74c3c"
    date = datetime.utcnow().strftime("%B %d, %Y")
    notes = f"<p><strong>Notes:</strong> {h(leave['admin_notes'])}</p>" if leave.get("admin_notes") else ""
    return (
        "<div style='padding:24px;font-family:sans-serif;color:#2c3e50;'>"
        "<h3>FortishieldMatrix — Leave Request Decision</h3>"
        f"<p>Date: {date}</p><p>Dear {name},</p>"
        f"<p>Your {h(leave['leave_type'])} request from {h(str(leave['start_date']))} "
        f"to {h(str(leave['end_date']))} ({int(leave['days'])} day(s)) has been "
        f"<strong style='color:{color}'>{decision}</strong>.</p>"
        f"{notes}<p>Regards,<br>Human Resources</p></div>"
    )


@bp.route("/hr_leave_letter.php", methods=["GET", "POST"])
@role_required(["hr", "admin"])
def hr_leave_letter():
    conn = db()
    user = g.current_user
    method = request.method
    body = json_body() if method == "POST" else {}
    action = request.args.get("action") or body.get("action")

    if method == "GET" and action == "preview":
        leave_id = int_field(request.args, "leave_id")
        if not leave_id:
            return json_error("leave_id is required.", 400)
        leave = _fetch_leave_with_employee(conn, leave_id)
        if not leave:
            return json_error("Leave request not found.", 404)
        if leave["status"] == "pending":
            return json_error("This leave request has not been decided yet.", 409)
        return json_ok({"letter": _build_letter_html(leave)})

    if method == "POST":
        leave_id = int_field(body, "leave_id")
        send_method = enum_field(body, "method", ["email", "portal", "both"], "both")
        if not leave_id:
            return json_error("leave_id is required.", 400)
        leave = _fetch_leave_with_employee(conn, leave_id)
        if not leave:
            return json_error("Leave request not found.", 404)

        letter = _build_letter_html(leave)

        if send_method in ("email", "both"):
            print(f"[LEAVE LETTER] would email leave #{leave_id} to {leave['email']}")

        if send_method in ("portal", "both"):
            with conn.cursor() as cur:
                cur.execute(
                    "INSERT INTO generated_documents "
                    "(employee_id, template, content, generated_by) "
                    "VALUES (%s, 'leave_letter', %s, %s)",
                    (leave["employee_id"], letter, user["id"]),
                )
            conn.commit()

        log_audit(conn, int(user["id"]), "leave_letter_sent", "leave",
                  f"Sent leave letter for #{leave_id} via {send_method}")
        return json_ok({"message": "Letter sent"})

    return json_error("Unsupported request.", 400)