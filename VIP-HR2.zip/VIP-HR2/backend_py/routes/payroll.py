"""payroll.py — get_hr_payroll_data, process_hr_payroll"""
from flask import Blueprint, request, g
from db import db
from helpers import (
    json_ok, json_error, json_body, str_field, int_field, float_field,
    enum_field, log_audit,
)
from auth import role_required

bp = Blueprint("payroll", __name__)


@bp.route("/get_hr_payroll_data.php", methods=["GET"])
@role_required(["hr", "admin"])
def get_payroll_data():
    conn = db()
    with conn.cursor() as cur:
        cur.execute("SELECT status, COUNT(*) AS c FROM payroll GROUP BY status")
        by_status = {"pending": 0, "processing": 0, "paid": 0}
        for row in cur.fetchall():
            by_status[row["status"]] = int(row["c"])
        cur.execute("SELECT COUNT(*) AS c FROM employees WHERE status='Active'")
        total_employees = int(cur.fetchone()["c"])

    department = str_field(request.args, "department")
    month = str_field(request.args, "month")
    status = enum_field(request.args, "status",
                        ["pending", "approved", "denied", "processing", "paid"])

    sql = (
        "SELECT e.employee_code, CONCAT(e.firstname,' ',e.lastname) AS employee_name, "
        "d.name AS department, p.pay_period, p.basic_salary, "
        "(p.tax + p.insurance + p.other_deductions) AS deductions, p.net_salary, "
        "p.status, p.payment_date "
        "FROM payroll p JOIN employees e ON e.id = p.employee_id "
        "LEFT JOIN departments d ON d.id = e.department_id WHERE 1=1"
    )
    params = []
    if department:
        sql += " AND d.name = %s"; params.append(department)
    if month:
        sql += " AND p.pay_period = %s"; params.append(month)
    if status:
        sql += " AND p.status = %s"; params.append(status)
    sql += " ORDER BY p.created_at DESC"

    with conn.cursor() as cur:
        cur.execute(sql, params)
        payrolls = cur.fetchall()
    for r in payrolls:
        if r.get("payment_date"): r["payment_date"] = str(r["payment_date"])
        for k in ("basic_salary", "deductions", "net_salary"):
            if r.get(k) is not None:
                r[k] = float(r[k])

    return json_ok({
        "stats": {
            "total_employees": total_employees,
            "pending": by_status["pending"],
            "processing": by_status["processing"],
            "completed": by_status["paid"],
        },
        "payrolls": payrolls,
    })


@bp.route("/process_hr_payroll.php", methods=["POST"])
@role_required(["hr", "admin"])
def process_payroll():
    conn = db()
    body = json_body()
    action = str_field(body, "action", "create")
    if action != "create":
        return json_error("Unsupported action.", 400)

    employee_id = int_field(body, "employee_id")
    pay_period = str_field(body, "pay_period")
    basic = float_field(body, "basic_salary", 0) or 0
    if not employee_id or not pay_period or not basic:
        return json_error("Employee, pay period, and basic salary are required.", 400)

    allowances = float_field(body, "allowances", 0) or 0
    tax = float_field(body, "tax", 0) or 0
    insurance = float_field(body, "insurance", 0) or 0
    other = float_field(body, "other_deductions", 0) or 0
    net = basic + allowances - tax - insurance - other

    with conn.cursor() as cur:
        cur.execute("SELECT id FROM employees WHERE id=%s LIMIT 1", (employee_id,))
        if not cur.fetchone():
            return json_error("Employee not found.", 404)
        cur.execute(
            "INSERT INTO payroll "
            "(employee_id, pay_period, basic_salary, allowances, tax, insurance, "
            "other_deductions, net_salary, status, payment_date, created_at) "
            "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, 'pending', %s, NOW())",
            (employee_id, pay_period, basic, allowances, tax, insurance, other, net,
             str_field(body, "payment_date") or None),
        )
        new_id = cur.lastrowid
    conn.commit()

    log_audit(conn, int(g.current_user["id"]), "payroll_processed", "payroll",
              f"Processed payroll #{new_id} for period {pay_period}")
    return json_ok({"message": "Payroll processed", "id": new_id}, status=201)