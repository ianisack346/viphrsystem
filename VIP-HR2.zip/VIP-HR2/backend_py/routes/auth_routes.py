"""auth_routes.py — hr_login, hr_register, logout, csrf_token, get_hr_session_info"""
import re
import secrets
import time
from flask import Blueprint, request, session, jsonify

from db import db
from helpers import json_ok, json_error, json_body, log_audit
from auth import (
    current_user, is_rate_limited, record_failed_attempt, clear_rate_limit,
)

try:
    import bcrypt
    _HAS_BCRYPT = True
except ImportError:
    _HAS_BCRYPT = False

bp = Blueprint("auth", __name__)

LOGIN_DUMMY_HASH = "pbkdf2:sha256:600000$decoy$0000000000000000000000000000000000000000000000000000000000000000"
CSRF_LIFETIME = 1800


def _csrf_token() -> str:
    if not session.get("csrf"):
        session["csrf"] = secrets.token_hex(32)
        session["csrf_issued_at"] = int(time.time())
    return session["csrf"]


def _require_csrf_header():
    sent = request.headers.get("X-CSRF-Token") or request.form.get("csrf_token") or ""
    expected = session.get("csrf", "")
    if not expected or not sent or sent != expected:
        return json_error("Invalid or expired CSRF token.", 419)
    return None


def _verify_password(raw_password: str, stored_hash: str) -> bool:
    if not stored_hash:
        return False
    try:
        if stored_hash.startswith("$2"):
            if not _HAS_BCRYPT:
                return False
            fixed = stored_hash.replace("$2y$", "$2b$", 1)
            return bcrypt.checkpw(raw_password.encode("utf-8"), fixed.encode("utf-8"))
        from werkzeug.security import check_password_hash
        return check_password_hash(stored_hash, raw_password)
    except Exception:
        return False


def _hash_password(raw: str) -> str:
    from werkzeug.security import generate_password_hash
    return generate_password_hash(raw, method="pbkdf2:sha256:600000")


# ---------- GET /csrf_token.php ----------
@bp.route("/csrf_token.php", methods=["GET"])
def csrf_token_endpoint():
    rotate = request.args.get("rotate") == "1"
    if rotate or not session.get("csrf"):
        session["csrf"] = secrets.token_hex(32)
        session["csrf_issued_at"] = int(time.time())
    issued = int(session.get("csrf_issued_at", time.time()))
    if (time.time() - issued) > CSRF_LIFETIME:
        session["csrf"] = secrets.token_hex(32)
        session["csrf_issued_at"] = int(time.time())
        issued = int(session["csrf_issued_at"])

    resp = jsonify({
        "success": True,
        "csrf": session["csrf"],
        "expires_in": CSRF_LIFETIME,
        "issued_at": issued,
    })
    resp.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    resp.headers["Pragma"] = "no-cache"
    resp.headers["Expires"] = "0"
    resp.headers["X-Content-Type-Options"] = "nosniff"
    return resp


# ---------- POST /hr_login.php ----------
@bp.route("/hr_login.php", methods=["POST"])
def hr_login():
    csrf_fail = _require_csrf_header()
    if csrf_fail:
        return csrf_fail

    body = json_body()
    username = (body.get("username") or "").strip()
    password = body.get("password") or ""

    if not username or not password:
        return json_error("Username and password are required.", 400)

    ip = request.remote_addr or "0.0.0.0"
    if is_rate_limited(f"ip:{ip}", 5, 900):
        return json_error("Too many attempts. Please try again later.", 429)

    conn = db()
    with conn.cursor() as cur:
        cur.execute(
            "SELECT id, username, email, password_hash, role, full_name, "
            "profile_photo, hr_code, status FROM hr_users "
            "WHERE username=%s OR email=%s LIMIT 1",
            (username, username),
        )
        user = cur.fetchone()

    hash_to_check = (user["password_hash"] if (user and user.get("password_hash")) else LOGIN_DUMMY_HASH)
    ok_pw = _verify_password(password, hash_to_check) if hash_to_check else False
    active = bool(user and user.get("status") == "active")

    if not (ok_pw and user and active):
        record_failed_attempt(f"ip:{ip}")
        log_audit(conn, user["id"] if user else None, "login_failed", "auth",
                  f"Failed login for {username} from {ip}")
        return json_error("Invalid username or password.", 401)

    session.clear()
    session.permanent = True
    session["hr_user_id"] = int(user["id"])
    session["hr_user"] = {
        "id": int(user["id"]),
        "username": user["username"],
        "email": user["email"],
        "full_name": user["full_name"],
        "role": user["role"],
        "hr_code": user["hr_code"],
        "profile_photo": user["profile_photo"] or "logo.png",
    }
    session["__created"] = time.time()
    session["csrf"] = secrets.token_hex(32)
    session["csrf_issued_at"] = int(time.time())

    clear_rate_limit(f"ip:{ip}")

    with conn.cursor() as cur:
        cur.execute("UPDATE hr_users SET last_login=NOW() WHERE id=%s", (user["id"],))
    conn.commit()

    log_audit(conn, int(user["id"]), "login_success", "auth",
              f"Successful login for {user['username']}")

    return json_ok({"user": session["hr_user"], "csrf": session["csrf"]}, "Signed in.")


# ---------- POST /hr_register.php ----------
@bp.route("/hr_register.php", methods=["POST"])
def hr_register():
    csrf_fail = _require_csrf_header()
    if csrf_fail:
        return csrf_fail

    ip = request.remote_addr or "0.0.0.0"
    if is_rate_limited(f"reg:{ip}", 10, 3600):
        log_audit(db(), None, "register_rate_limited", "auth", f"Rate limit hit for {ip}")
        return json_error("Too many registration attempts. Please try again later.", 429)

    body = json_body()
    full_name = (body.get("full_name") or "").strip()
    username = (body.get("username") or "").strip().lower()
    hr_code = (body.get("hr_code") or "").strip()
    email = (body.get("email") or "").strip().lower()
    role = (body.get("role") or "").strip()
    try:
        dept_id = int(body.get("department") or 0)
    except (TypeError, ValueError):
        dept_id = 0
    password = body.get("password") or ""

    if len(full_name) > 150 or len(username) > 30 or len(email) > 150 or len(password) > 200:
        return json_error("One of the fields exceeds max length.", 400)
    if len(full_name) < 3:
        return json_error("Please enter your full name.", 400)
    if not re.fullmatch(r"[a-z0-9._-]{3,30}", username):
        return json_error("Username must be 3-30 chars: letters, digits, dot, dash, underscore.", 400)
    if not re.fullmatch(r"\d{4}/HR/\d{4}", hr_code):
        return json_error("HR code must match YYYY/HR/XXXX.", 400)
    if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email):
        return json_error("Please provide a valid email address.", 400)
    if role not in ("hr", "manager", "employee"):
        return json_error("Invalid role selected.", 400)
    if dept_id <= 0:
        return json_error("Please select a department.", 400)
    if not (
        len(password) >= 8
        and re.search(r"[A-Z]", password)
        and re.search(r"[a-z]", password)
        and re.search(r"[0-9]", password)
        and re.search(r"[^A-Za-z0-9]", password)
    ):
        return json_error("Password does not meet the required strength.", 400)

    conn = db()
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT id FROM departments WHERE id=%s", (dept_id,))
            if not cur.fetchone():
                return json_error("Selected department does not exist.", 400)

            cur.execute(
                "SELECT id FROM hr_users WHERE username=%s OR email=%s OR hr_code=%s LIMIT 1",
                (username, email, hr_code),
            )
            if cur.fetchone():
                return json_error("That username, email or HR code is already registered.", 409)

            parts = re.split(r"\s+", full_name, maxsplit=1)
            first = parts[0]
            last = parts[1] if len(parts) > 1 else ""

            cur.execute(
                "INSERT INTO employees "
                "(employee_code, firstname, lastname, email, department_id, position, status) "
                "VALUES (%s, %s, %s, %s, %s, 'HR', 'Active')",
                (hr_code, first, last, email, dept_id),
            )
            employee_id = cur.lastrowid

            pwd_hash = _hash_password(password)
            cur.execute(
                "INSERT INTO hr_users "
                "(employee_id, username, email, password_hash, role, full_name, hr_code, status) "
                "VALUES (%s, %s, %s, %s, %s, %s, %s, 'active')",
                (employee_id, username, email, pwd_hash, role, full_name, hr_code),
            )
            new_id = cur.lastrowid
        conn.commit()

        log_audit(conn, new_id, "register_success", "auth",
                  f"New {role} account: {username} ({email})")

        return json_ok({"user": {
            "id": new_id, "username": username, "email": email,
            "full_name": full_name, "role": role, "hr_code": hr_code,
        }}, "Account created.")

    except Exception as e:
        conn.rollback()
        if "Duplicate entry" in str(e) or "1062" in str(e):
            return json_error("That username, email or HR code is already registered.", 409)
        print(f"[hr_register] {e}")
        return json_error("Registration failed. Please try again.", 500)


# ---------- GET/POST /logout.php ----------
@bp.route("/logout.php", methods=["GET", "POST"])
def logout():
    conn = db()
    user = session.get("hr_user")
    if user and user.get("id"):
        log_audit(conn, int(user["id"]), "logout", "auth",
                  f"{user.get('full_name', '')} logged out")
    session.clear()
    return json_ok({"message": "Logged out"})


# ---------- GET /get_hr_session_info.php ----------
@bp.route("/get_hr_session_info.php", methods=["GET"])
def get_hr_session_info():
    user = current_user()
    if not user:
        return json_error("Not authenticated.", 401)

    conn = db()
    with conn.cursor() as cur:
        cur.execute(
            "SELECT id, username, email, role, full_name, profile_photo, hr_code, status "
            "FROM hr_users WHERE id=%s LIMIT 1",
            (user["id"],),
        )
        row = cur.fetchone()

    if not row or row["status"] != "active":
        session.clear()
        return json_error("Account no longer active.", 401)

    session["hr_user"] = {
        "id": int(row["id"]),
        "username": row["username"],
        "email": row["email"],
        "full_name": row["full_name"],
        "role": row["role"],
        "hr_code": row["hr_code"],
        "profile_photo": row["profile_photo"] or "logo.png",
    }

    return json_ok({
        "user": session["hr_user"],
        "hr_code": row["hr_code"],
        "csrf": _csrf_token(),
    })