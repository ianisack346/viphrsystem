"""documents.py — all document endpoints"""
import os
import secrets
from datetime import datetime, timedelta
from flask import Blueprint, request, g, send_file
from db import db
from helpers import (
    json_ok, json_error, json_body, str_field, int_field, float_field, enum_field,
    is_valid_date, log_audit, format_bytes, h,
)
from auth import role_required
from uploads import handle_secure_upload
from config import Config

bp = Blueprint("documents", __name__)


@bp.route("/getDocumentsData.php", methods=["GET"])
@role_required(["hr", "admin"])
def get_documents_data():
    conn = db()
    with conn.cursor() as cur:
        cur.execute(
            "SELECT d.id, d.title, d.description, d.document_type, d.file_name, "
            "d.file_type, d.file_size, d.version_count, d.status, d.expiry_date, "
            "d.upload_date, d.download_count, dept.name AS department_name, "
            "e.firstname AS emp_first_name, e.lastname AS emp_last_name, "
            "hu.full_name AS uploaded_by_name "
            "FROM documents d "
            "LEFT JOIN departments dept ON dept.id = d.department_id "
            "LEFT JOIN employees e ON e.id = d.employee_id "
            "LEFT JOIN hr_users hu ON hu.id = d.uploaded_by "
            "WHERE d.deleted_at IS NULL ORDER BY d.upload_date DESC"
        )
        rows = cur.fetchall()

    total_storage = 0
    type_distribution = {}
    recent_uploads = 0
    cutoff = datetime.utcnow() - timedelta(days=7)

    for r in rows:
        total_storage += int(r["file_size"] or 0)
        r["file_size_formatted"] = format_bytes(int(r["file_size"] or 0))
        td = r.get("document_type") or "other"
        type_distribution[td] = type_distribution.get(td, 0) + 1
        if r.get("upload_date") and isinstance(r["upload_date"], datetime):
            if r["upload_date"] >= cutoff:
                recent_uploads += 1
        for k in ("upload_date", "expiry_date"):
            if r.get(k): r[k] = str(r[k])

    return json_ok({
        "data": rows,
        "total_count": len(rows),
        "statistics": {
            "total_storage": total_storage,
            "recent_uploads": recent_uploads,
            "type_distribution": [{"type": k, "count": v}
                                  for k, v in type_distribution.items()],
        },
    })


@bp.route("/getDocumentDetails.php", methods=["GET"])
@role_required(["hr", "admin"])
def get_document_details():
    conn = db()
    doc_id = int_field(request.args, "id")
    if not doc_id:
        return json_error("id is required.", 400)

    with conn.cursor() as cur:
        cur.execute(
            "SELECT d.*, dept.name AS department_name, "
            "e.firstname AS first_name, e.lastname AS last_name, "
            "hu.full_name AS uploaded_by_name "
            "FROM documents d "
            "LEFT JOIN departments dept ON dept.id = d.department_id "
            "LEFT JOIN employees e ON e.id = d.employee_id "
            "LEFT JOIN hr_users hu ON hu.id = d.uploaded_by "
            "WHERE d.id = %s AND d.deleted_at IS NULL LIMIT 1",
            (doc_id,),
        )
        doc = cur.fetchone()
    if not doc:
        return json_error("Document not found.", 404)
    doc["document_id"] = int(doc["id"])
    for k, v in list(doc.items()):
        if hasattr(v, "isoformat"):
            doc[k] = str(v)
    return json_ok({"data": doc})


@bp.route("/uploadDocument.php", methods=["POST"])
@role_required(["hr", "admin"])
def upload_document():
    conn = db()
    title = str_field(request.form, "title")
    doc_type = str_field(request.form, "document_type")
    if not title or not doc_type:
        return json_error("Title and document type are required.", 400)

    file = request.files.get("document")
    if not file:
        return json_error("A file is required.", 400)

    try:
        uploaded = handle_secure_upload(
            file, Config.DOC_UPLOAD_DIR,
            Config.ALLOWED_DOC_EXT, Config.ALLOWED_DOC_MIME, Config.MAX_UPLOAD_BYTES,
        )
    except ValueError as e:
        return json_error(str(e), 400)

    department_id = int_field(request.form, "department_id")
    access_level = enum_field(request.form, "access_level",
                              ["private", "department", "public"], "private")
    expiry = str_field(request.form, "expiry_date")
    expiry = expiry if is_valid_date(expiry) else None
    ext = uploaded["file_name"].rsplit(".", 1)[-1].lower() if "." in uploaded["file_name"] else ""

    with conn.cursor() as cur:
        cur.execute(
            "INSERT INTO documents "
            "(title, description, document_type, department_id, file_name, stored_name, "
            "file_type, file_size, access_level, expiry_date, status, version_count, uploaded_by) "
            "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 'active', 1, %s)",
            (title, str_field(request.form, "description"), doc_type, department_id,
             uploaded["file_name"], uploaded["stored_name"], ext, uploaded["size"],
             access_level, expiry, g.current_user["id"]),
        )
        new_id = cur.lastrowid
    conn.commit()

    log_audit(conn, int(g.current_user["id"]), "document_uploaded", "documents",
              f'Uploaded "{title}"')
    return json_ok({"message": "Document uploaded", "id": new_id}, status=201)


@bp.route("/updateDocument.php", methods=["POST"])
@role_required(["hr", "admin"])
def update_document():
    conn = db()
    doc_id = int_field(request.form, "document_id")
    if not doc_id:
        return json_error("document_id is required.", 400)

    with conn.cursor() as cur:
        cur.execute("SELECT * FROM documents WHERE id=%s AND deleted_at IS NULL LIMIT 1", (doc_id,))
        doc = cur.fetchone()
    if not doc:
        return json_error("Document not found.", 404)

    title = str_field(request.form, "title", doc["title"])
    description = str_field(request.form, "description", doc["description"] or "")
    doc_type = str_field(request.form, "document_type", doc["document_type"])
    department_id = int_field(request.form, "department_id", doc["department_id"])
    access_level = enum_field(request.form, "access_level",
                              ["private", "department", "public"], doc["access_level"])
    expiry_raw = str_field(request.form, "expiry_date")
    expiry = expiry_raw if is_valid_date(expiry_raw) else doc["expiry_date"]

    new_stored = doc["stored_name"]; new_name = doc["file_name"]
    new_type = doc["file_type"]; new_size = doc["file_size"]; version_inc = 0

    file = request.files.get("document")
    if file and file.filename:
        try:
            uploaded = handle_secure_upload(
                file, Config.DOC_UPLOAD_DIR,
                Config.ALLOWED_DOC_EXT, Config.ALLOWED_DOC_MIME, Config.MAX_UPLOAD_BYTES,
            )
        except ValueError as e:
            return json_error(str(e), 400)
        old_path = os.path.join(Config.DOC_UPLOAD_DIR, doc["stored_name"])
        if os.path.isfile(old_path):
            try: os.unlink(old_path)
            except OSError: pass
        new_stored = uploaded["stored_name"]
        new_name = uploaded["file_name"]
        new_type = uploaded["file_name"].rsplit(".", 1)[-1].lower() if "." in uploaded["file_name"] else ""
        new_size = uploaded["size"]
        version_inc = 1

    with conn.cursor() as cur:
        cur.execute(
            "UPDATE documents SET title=%s, description=%s, document_type=%s, "
            "department_id=%s, access_level=%s, expiry_date=%s, file_name=%s, "
            "stored_name=%s, file_type=%s, file_size=%s, version_count = version_count + %s "
            "WHERE id=%s",
            (title, description, doc_type, department_id, access_level, expiry,
             new_name, new_stored, new_type, new_size, version_inc, doc_id),
        )
    conn.commit()

    log_audit(conn, int(g.current_user["id"]), "document_updated", "documents",
              f"Updated document #{doc_id}")
    return json_ok({"message": "Document updated"})


@bp.route("/deleteDocument.php", methods=["POST"])
@role_required(["hr", "admin"])
def delete_document():
    conn = db()
    body = json_body()
    doc_id = int_field(body, "document_id")
    if not doc_id:
        return json_error("document_id is required.", 400)

    with conn.cursor() as cur:
        cur.execute("SELECT id, title FROM documents WHERE id=%s AND deleted_at IS NULL LIMIT 1", (doc_id,))
        doc = cur.fetchone()
        if not doc:
            return json_error("Document not found.", 404)
        cur.execute("UPDATE documents SET deleted_at=NOW(), status='archived' WHERE id=%s", (doc_id,))
    conn.commit()

    log_audit(conn, int(g.current_user["id"]), "document_deleted", "documents",
              f'Deleted document "{doc["title"]}" (#{doc_id})')
    return json_ok({"message": "Document deleted"})


@bp.route("/downloadDocument.php", methods=["GET"])
@role_required(["hr", "admin"])
def download_document():
    conn = db()
    doc_id = int_field(request.args, "id")
    if not doc_id:
        return json_error("id is required.", 400)

    with conn.cursor() as cur:
        cur.execute(
            "SELECT stored_name, file_name FROM documents "
            "WHERE id=%s AND deleted_at IS NULL LIMIT 1",
            (doc_id,),
        )
        doc = cur.fetchone()
    if not doc:
        return json_error("Document not found.", 404)

    path = os.path.join(Config.DOC_UPLOAD_DIR, os.path.basename(doc["stored_name"]))
    if not os.path.isfile(path):
        return json_error("File is missing from storage.", 404)

    with conn.cursor() as cur:
        cur.execute("UPDATE documents SET download_count = download_count + 1 WHERE id=%s", (doc_id,))
    conn.commit()

    return send_file(path, as_attachment=True,
                     download_name=os.path.basename(doc["file_name"]),
                     mimetype="application/octet-stream")


@bp.route("/generate_hr_document.php", methods=["POST"])
@role_required(["hr", "admin"])
def generate_hr_document():
    conn = db()
    body = json_body()

    template = enum_field(body, "template",
                          ["offer_letter", "contract", "warning", "nda"])
    employee_id = int_field(body, "employee_id")
    if not template or not employee_id:
        return json_error("template and employee_id are required.", 400)

    with conn.cursor() as cur:
        cur.execute(
            "SELECT e.*, d.name AS department_name FROM employees e "
            "LEFT JOIN departments d ON d.id = e.department_id WHERE e.id=%s LIMIT 1",
            (employee_id,),
        )
        emp = cur.fetchone()
    if not emp:
        return json_error("Employee not found.", 404)

    name = h(f"{emp['firstname']} {emp['lastname']}")
    today = datetime.utcnow().strftime("%B %d, %Y")
    titles = {
        "offer_letter": "Offer of Employment",
        "contract": "Employment Contract",
        "warning": "Formal Warning Letter",
        "nda": "Non-Disclosure Agreement",
    }

    if template == "offer_letter":
        salary = float_field(body, "salary")
        start_date = str_field(body, "start_date")
        position = str_field(body, "position", emp["position"] or "")
        if not salary or not is_valid_date(start_date):
            return json_error("Salary and a valid start date are required.", 400)
        content = (
            f"<h2>{titles[template]}</h2><p>Date: {today}</p>"
            f"<p>Dear {name},</p>"
            f"<p>We are pleased to offer you the position of <strong>{h(position)}</strong> "
            f"in the {h(emp['department_name'] or 'N/A')} department, at a monthly "
            f"salary of TZS {salary:,.2f}, starting {h(start_date)}.</p>"
            "<p>Regards,<br>Human Resources</p>"
        )
    elif template == "contract":
        salary = float_field(body, "salary")
        start_date = str_field(body, "start_date")
        duration = str_field(body, "duration")
        terms = str_field(body, "terms")
        if not salary or not is_valid_date(start_date) or not duration:
            return json_error("Salary, start date, and duration are required.", 400)
        content = (
            f"<h2>{titles[template]}</h2><p>Date: {today}</p>"
            f"<p>This contract is entered into between FortishieldMatrix and {name} for "
            f"the position of {h(emp['position'] or '')}, effective {h(start_date)}, "
            f"for a duration of {h(duration)}, at a monthly salary of TZS {salary:,.2f}.</p>"
            + (f"<p><strong>Additional terms:</strong> {h(terms)}</p>" if terms else "")
            + "<p>Regards,<br>Human Resources</p>"
        )
    elif template == "warning":
        violation = str_field(body, "violation")
        action = str_field(body, "action_taken")
        if not violation or not action:
            return json_error("Violation and action taken are required.", 400)
        content = (
            f"<h2>{titles[template]}</h2><p>Date: {today}</p>"
            f"<p>Dear {name},</p>"
            "<p>This letter serves as formal notice regarding the following matter:</p>"
            f"<p>{h(violation).replace(chr(10), '<br>')}</p>"
            f"<p><strong>Action taken:</strong> {h(action).replace(chr(10), '<br>')}</p>"
            "<p>Regards,<br>Human Resources</p>"
        )
    else:  # nda
        project = str_field(body, "project")
        duration = str_field(body, "duration", "1 year")
        conf_info = str_field(body, "confidential_info")
        if not project:
            return json_error("Project name is required.", 400)
        content = (
            f"<h2>{titles[template]}</h2><p>Date: {today}</p>"
            f"<p>This Non-Disclosure Agreement is made between FortishieldMatrix and "
            f"{name} regarding project <strong>{h(project)}</strong>, valid for {h(duration)}.</p>"
            + (f"<p><strong>Confidential information covers:</strong> {h(conf_info)}</p>"
               if conf_info else "")
            + "<p>Regards,<br>Human Resources</p>"
        )

    try:
        os.makedirs(Config.DOC_UPLOAD_DIR, exist_ok=True)
        stored_name = f"{secrets.token_hex(16)}.html"
        full_path = os.path.join(Config.DOC_UPLOAD_DIR, stored_name)
        with open(full_path, "w", encoding="utf-8") as f:
            f.write(f"<!DOCTYPE html><html><body>{content}</body></html>")
        file_size = os.path.getsize(full_path)
        display_name = f"{titles[template]} - {emp['firstname']} {emp['lastname']}.html"

        with conn.cursor() as cur:
            cur.execute(
                "INSERT INTO generated_documents "
                "(employee_id, template, content, generated_by) VALUES (%s, %s, %s, %s)",
                (employee_id, template, content, g.current_user["id"]),
            )
            gen_id = cur.lastrowid
            cur.execute(
                "INSERT INTO documents "
                "(title, description, document_type, employee_id, file_name, stored_name, "
                "file_type, file_size, access_level, status, version_count, uploaded_by) "
                "VALUES (%s, 'Auto-generated document', %s, %s, %s, %s, 'html', %s, "
                "'private', 'active', 1, %s)",
                (titles[template], template, employee_id, display_name,
                 stored_name, file_size, g.current_user["id"]),
            )
        conn.commit()
    except Exception as e:
        conn.rollback()
        print(f"[GENERATE DOCUMENT] {e}")
        return json_error("Could not generate document.", 500)

    log_audit(conn, int(g.current_user["id"]), "document_generated", "documents",
              f"Generated {template} for {name}")
    return json_ok({"message": "Document generated", "id": gen_id})


@bp.route("/get_hr_document_requests.php", methods=["GET"])
@role_required(["hr", "admin"])
def get_document_requests():
    conn = db()
    status = enum_field(request.args, "status",
                        ["pending", "approved", "denied", "completed"])
    urgency = enum_field(request.args, "urgency", ["normal", "urgent", "immediate"])

    sql = (
        "SELECT dr.id, dr.employee_id, "
        "CONCAT(e.firstname, ' ', e.lastname) AS employee_name, "
        "e.employee_code, d.name AS department, dr.document_type, dr.reason, "
        "dr.urgency, dr.status, dr.created_at "
        "FROM document_requests dr "
        "JOIN employees e ON e.id = dr.employee_id "
        "LEFT JOIN departments d ON d.id = e.department_id WHERE 1=1"
    )
    params = []
    if status:
        sql += " AND dr.status = %s"; params.append(status)
    if urgency:
        sql += " AND dr.urgency = %s"; params.append(urgency)
    sql += ' ORDER BY FIELD(dr.urgency,"immediate","urgent","normal"), dr.created_at DESC'

    with conn.cursor() as cur:
        cur.execute(sql, params)
        rows = cur.fetchall()
    for r in rows:
        if r.get("created_at"): r["created_at"] = str(r["created_at"])
    return json_ok({"requests": rows})


@bp.route("/update_document_request.php", methods=["POST"])
@role_required(["hr", "admin"])
def update_document_request():
    conn = db()
    body = json_body()
    req_id = int_field(body, "request_id")
    status = enum_field(body, "status", ["approved", "denied", "completed"])
    response = str_field(body, "hr_response")

    if not req_id or not status:
        return json_error("request_id and a valid status are required.", 400)

    with conn.cursor() as cur:
        cur.execute("SELECT id FROM document_requests WHERE id=%s LIMIT 1", (req_id,))
        if not cur.fetchone():
            return json_error("Request not found.", 404)
        if status == "completed":
            cur.execute(
                "UPDATE document_requests SET status=%s, hr_response=%s, "
                "completed_date=NOW() WHERE id=%s",
                (status, response, req_id),
            )
        else:
            cur.execute(
                "UPDATE document_requests SET status=%s, hr_response=%s WHERE id=%s",
                (status, response, req_id),
            )
    conn.commit()

    log_audit(conn, int(g.current_user["id"]), "document_request_updated", "documents",
              f"Request #{req_id} → {status}")
    return json_ok({"message": "Request updated"})