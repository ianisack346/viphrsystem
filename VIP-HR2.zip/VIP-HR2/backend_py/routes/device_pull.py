"""device_pull.py — Fetches attendance logs from Hikvision DS-K1T321 device"""
import os
import time
import requests
from datetime import datetime, timedelta
from calendar import monthrange
from flask import Blueprint, jsonify, request
from requests.auth import HTTPDigestAuth

from db import db

bp = Blueprint("device_pull", __name__)

DEVICE_IP     = os.getenv("HIKVISION_IP", "192.168.100.34")
DEVICE_USER   = os.getenv("HIKVISION_USER", "admin")
DEVICE_PASS   = os.getenv("HIKVISION_PASS", "12345678vip@@")
DEVICE_SERIAL = os.getenv("HIKVISION_SERIAL", "GQ2131615")

PAGE_SIZE = 30
SLEEP_BETWEEN_REQUESTS = 0.35
MAX_RETRIES = 3

# Valid "successful verify" minor codes from Hikvision
VALID_MINORS = {38, 39, 75, 76}


def _post_isapi(endpoint, payload):
    url = f"http://{DEVICE_IP}{endpoint}?format=json"
    last_exc = None

    for attempt in range(1, MAX_RETRIES + 1):
        try:
            r = requests.post(
                url, json=payload,
                auth=HTTPDigestAuth(DEVICE_USER, DEVICE_PASS),
                verify=False, timeout=30
            )
            if r.status_code == 401:
                print(f"[DEVICE] 401 on attempt {attempt}, retrying in {attempt*2}s")
                time.sleep(attempt * 2)
                last_exc = requests.HTTPError(f"401 Unauthorized on attempt {attempt}")
                continue
            r.raise_for_status()
            return r.json()
        except requests.HTTPError as e:
            last_exc = e
            print(f"[DEVICE] HTTP error on attempt {attempt}: {e}")
            time.sleep(attempt * 2)
        except requests.RequestException as e:
            last_exc = e
            print(f"[DEVICE] request error on attempt {attempt}: {e}")
            time.sleep(attempt * 2)

    raise last_exc


def _fetch_range(start_dt, end_dt):
    all_events = []
    position = 0
    page_num = 0

    while True:
        page_num += 1
        payload = {
            "AcsEventCond": {
                "searchID": f"search-{int(start_dt.timestamp())}-{page_num}",
                "searchResultPosition": position,
                "maxResults": PAGE_SIZE,
                "major": 0,
                "minor": 0,
                "startTime": start_dt.strftime("%Y-%m-%dT%H:%M:%S+03:00"),
                "endTime": end_dt.strftime("%Y-%m-%dT%H:%M:%S+03:00")
            }
        }
        try:
            data = _post_isapi("/ISAPI/AccessControl/AcsEvent", payload)
        except Exception as e:
            print(f"[DEVICE] page error {page_num}: {e}")
            break

        acs = data.get("AcsEvent", {})
        page = acs.get("InfoList", [])
        status = acs.get("responseStatusStrg", "OK")
        total = acs.get("totalMatches", 0)

        print(f"[DEVICE] {start_dt.strftime('%Y-%m')} page {page_num}: "
              f"pos={position} got={len(page)} total={total} status={status}")

        all_events.extend(page)

        if status != "MORE" or not page:
            break

        position += len(page)

        if page_num > 1000:
            print("[DEVICE] safety cutoff at 1000 pages")
            break

        time.sleep(SLEEP_BETWEEN_REQUESTS)

    return all_events


def _fetch_all_events(start_time, end_time):
    all_events = []
    cursor = start_time.replace(day=1, hour=0, minute=0, second=0, microsecond=0)

    while cursor <= end_time:
        last_day = monthrange(cursor.year, cursor.month)[1]
        month_end = cursor.replace(day=last_day, hour=23, minute=59, second=59)

        if month_end > end_time:
            month_end = end_time

        print(f"[DEVICE] === fetching {cursor.strftime('%Y-%m')} ===")
        month_events = _fetch_range(cursor, month_end)
        all_events.extend(month_events)
        print(f"[DEVICE] === {cursor.strftime('%Y-%m')} done: {len(month_events)} events ===")

        if cursor.month == 12:
            cursor = cursor.replace(year=cursor.year + 1, month=1, day=1)
        else:
            cursor = cursor.replace(month=cursor.month + 1, day=1)

    print(f"[DEVICE] DONE: {len(all_events)} events total")
    return all_events


@bp.route("/device_pull.php", methods=["GET"])
def device_pull():
    conn = db()
    days = int(request.args.get("days", 365))
    debug = request.args.get("debug") == "1"

    end_time = datetime.now()
    start_time = end_time - timedelta(days=days)

    events = _fetch_all_events(start_time, end_time)

    inserted = 0
    skipped_dup = 0
    skipped_not_punch = 0
    seen_majors = {}
    inserted_samples = []

    # Debug counters for what got rejected and why
    rejected_minor_counts = {}

    for ev in events:
        major = ev.get("major")
        minor = ev.get("minor")
        key = f"{major}/{minor}"
        seen_majors[key] = seen_majors.get(key, 0) + 1

        # Only accept successful face/fingerprint/card verify events
        if major != 5 or minor not in VALID_MINORS:
            skipped_not_punch += 1
            rejected_minor_counts[key] = rejected_minor_counts.get(key, 0) + 1
            continue

        emp_no = ev.get("employeeNoString")
        emp_name = ev.get("name", "")
        time_str = ev.get("time")
        serial = ev.get("serialNo")

        if not emp_no or not time_str:
            continue

        try:
            punch_time = datetime.fromisoformat(time_str.replace("+03:00", ""))
        except ValueError:
            continue

        with conn.cursor() as cur:
            cur.execute(
                "SELECT id FROM device_punches "
                "WHERE device_serial=%s AND employee_no=%s AND punch_time=%s",
                (DEVICE_SERIAL, emp_no, punch_time)
            )
            if cur.fetchone():
                skipped_dup += 1
                continue

            cur.execute(
                "INSERT INTO device_punches "
                "(device_serial, employee_no, employee_name, punch_time, punch_type, serial_no) "
                "VALUES (%s, %s, %s, %s, 'check-in', %s)",
                (DEVICE_SERIAL, emp_no, emp_name, punch_time, serial)
            )
            inserted += 1
            if len(inserted_samples) < 10:
                inserted_samples.append({
                    "employee_no": emp_no,
                    "name": emp_name,
                    "minor": minor,
                    "time": str(punch_time)
                })
    conn.commit()

    response = {
        "success": True,
        "message": (
            f"Pulled {len(events)} events. "
            f"Inserted {inserted} punches. "
            f"Skipped: {skipped_not_punch} non-punch, {skipped_dup} duplicate."
        ),
        "inserted": inserted,
        "skipped_not_punch": skipped_not_punch,
        "skipped_duplicate": skipped_dup,
        "total_from_device": len(events),
        "sample_inserted": inserted_samples,
        "valid_minors_accepted": sorted(VALID_MINORS),
    }
    if debug:
        response["majors_seen"] = seen_majors
        response["rejected_minor_counts"] = rejected_minor_counts
    return jsonify(response), 200