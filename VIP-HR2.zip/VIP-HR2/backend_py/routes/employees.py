"""employees.py — get_all_employeess, addEmployee"""
import re
from flask import Blueprint, request, g
from db import db
from helpers import (
    json_ok, json_error, json_body, str_field, int_field, enum_field, log_audit,
)
from auth import role_required

bp = Blueprint("employees", __name__)


@bp.route("/get_all_employeess.php", methods=["GET"])
@role_required(["hr", "admin", "manager"])
def get_all_employees():
    conn = db()
    status = enum_field(request.args, "status", ["Active", "Inactive"])
    department = str_field(request.args, "department")
    search = str_field(request.args, "search")

    sql = (
        "SELECT e.id, e.employee_code, e.firstname, e.lastname, e.email, e.phone, "
        "d.name AS department, e.position, e.status, e.date_hired "
        "FROM employees e LEFT JOIN departments d ON d.id = e.department_id "
        "WHERE 1=1"
    )
    params = []
    if status:
        sql += " AND e.status = %s"
        params.append(status)
    if department:
        sql += " AND d.name = %s"
        params.append(department)
    if search:
        sql += (" AND (e.firstname LIKE %s OR e.lastname LIKE %s "
                "OR e.employee_code LIKE %s OR e.email LIKE %s)")
        like = f"%{search}%"
        params.extend([like, like, like, like])
    sql += " ORDER BY e.firstname, e.lastname"

    with conn.cursor() as cur:
        cur.execute(sql, params)
        rows = cur.fetchall()

    employees = [
        {
            "id": int(r["id"]),
            "employee_id": int(r["id"]),
            "staff_profile_id": int(r["id"]),
            "employee_code": r["employee_code"],
            "firstname": r["firstname"],
            "lastname": r["lastname"],
            "email": r["email"],
            "phone": r["phone"],
            "department": r["department"],
            "position": r["position"],
            "role": r["position"],
            "status": r["status"],
            "date_hired": str(r["date_hired"]) if r["date_hired"] else None,
        }
        for r in rows
    ]
    return json_ok({"employees": employees})


@bp.route("/addEmployee.php", methods=["POST"])
@role_required(["hr", "admin"])
def add_employee():
    conn = db()
    body = json_body()

    employee_code = str_field(body, "employee_id")
    first_name = str_field(body, "first_name")
    last_name = str_field(body, "last_name")
    email = str_field(body, "email")
    department_name = str_field(body, "department")
    position = str_field(body, "position")
    status = enum_field(body, "status", ["active", "inactive"], "active")

    if not employee_code or not first_name or not last_name:
        return json_error("Employee ID, first name and last name are required.", 400)
    if email and not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email):
        return json_error("Invalid email address.", 400)
    if not email:
        email = re.sub(r"[^a-z0-9]", "", employee_code.lower()) + "@company.local"

    with conn.cursor() as cur:
        cur.execute(
            "SELECT id FROM employees WHERE employee_code=%s OR email=%s LIMIT 1",
            (employee_code, email),
        )
        if cur.fetchone():
            return json_error("An employee with that code or email already exists.", 409)

        department_id = None
        if department_name:
            cur.execute("SELECT id FROM departments WHERE name=%s LIMIT 1", (department_name,))
            dept = cur.fetchone()
            if dept:
                department_id = int(dept["id"])
            else:
                cur.execute("INSERT INTO departments (name) VALUES (%s)", (department_name,))
                department_id = cur.lastrowid

        cur.execute(
            "INSERT INTO employees "
            "(employee_code, firstname, lastname, email, department_id, position, status, date_hired) "
            "VALUES (%s, %s, %s, %s, %s, %s, %s, CURDATE())",
            (employee_code, first_name, last_name, email, department_id,
             position, status.capitalize()),
        )
        new_id = cur.lastrowid
    conn.commit()

    log_audit(conn, int(g.current_user["id"]), "employee_added", "employees",
              f"Added employee {first_name} {last_name} ({employee_code})")
    return json_ok({"message": "Employee created", "id": new_id}, status=201)