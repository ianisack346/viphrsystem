"""training.py — save_training, get_trainings"""
from datetime import datetime
from flask import Blueprint, request, g
from db import db
from helpers import (
    json_ok, json_error, json_body, str_field, int_field, float_field,
    log_audit, paginate,
)
from auth import role_required

bp = Blueprint("training", __name__)


def _parse_dt(s):
    for fmt in ("%Y-%m-%dT%H:%M", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(s, fmt)
        except (ValueError, TypeError):
            continue
    return None


@bp.route("/save_training.php", methods=["POST"])
@role_required(["hr", "admin"])
def save_training():
    conn = db()
    body = json_body()

    title = str_field(body, "title")
    start_date = str_field(body, "start_date")
    end_date = str_field(body, "end_date")
    trainer_name = str_field(body, "trainer_name")

    if not title or not start_date or not end_date or not trainer_name:
        return json_error("Title, start/end date, and trainer name are required.", 400)

    start_dt = _parse_dt(start_date)
    end_dt = _parse_dt(end_date)
    if not start_dt or not end_dt:
        return json_error("Invalid date format.", 400)
    if end_dt <= start_dt:
        return json_error("End date must be after start date.", 400)

    target_dept_id = None
    target_dept_name = str_field(body, "target_department")
    if target_dept_name:
        with conn.cursor() as cur:
            cur.execute("SELECT id FROM departments WHERE name=%s LIMIT 1", (target_dept_name,))
            d = cur.fetchone()
            target_dept_id = int(d["id"]) if d else None

    status = str_field(body, "status", "Draft")
    if status not in ["Draft", "Scheduled", "Open for Registration",
                      "In Progress", "Completed", "Cancelled"]:
        status = "Draft"

    participants = body.get("participants") if isinstance(body.get("participants"), list) else []

    try:
        with conn.cursor() as cur:
            cur.execute(
                "INSERT INTO trainings "
                "(title, type, description, start_date, end_date, duration, "
                "max_participants, format, location, virtual_details, trainer_name, "
                "trainer_email, trainer_bio, target_audience, target_department_id, "
                "prerequisites, materials_needed, objectives, cost_per_participant, "
                "total_budget, budget_code, status, certificate_available, mandatory, "
                "send_notifications, created_by) "
                "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, "
                "%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
                (
                    title, str_field(body, "type"), str_field(body, "description"),
                    start_dt.strftime("%Y-%m-%d %H:%M:%S"),
                    end_dt.strftime("%Y-%m-%d %H:%M:%S"),
                    int_field(body, "duration", 0) or 0,
                    int_field(body, "max_participants", 0) or 0,
                    str_field(body, "format"), str_field(body, "location"),
                    str_field(body, "virtual_details"), trainer_name,
                    str_field(body, "trainer_email"), str_field(body, "trainer_bio"),
                    str_field(body, "target_audience"), target_dept_id,
                    str_field(body, "prerequisites"), str_field(body, "materials_needed"),
                    str_field(body, "objectives"),
                    float_field(body, "cost_per_participant", 0) or 0,
                    float_field(body, "total_budget", 0) or 0,
                    str_field(body, "budget_code"), status,
                    1 if body.get("certificate_available") else 0,
                    1 if body.get("mandatory") else 0,
                    1 if body.get("send_notifications") else 0,
                    g.current_user["id"],
                ),
            )
            training_id = cur.lastrowid

            added = 0
            for p in participants:
                if isinstance(p, dict):
                    emp_id = int_field(p, "employee_id")
                    if emp_id:
                        cur.execute(
                            "INSERT IGNORE INTO training_participants "
                            "(training_id, employee_id) VALUES (%s, %s)",
                            (training_id, emp_id),
                        )
                        added += 1
            if added > 0:
                cur.execute(
                    "UPDATE trainings SET current_participants=%s WHERE id=%s",
                    (added, training_id),
                )
        conn.commit()
    except Exception as e:
        conn.rollback()
        print(f"[SAVE TRAINING] {e}")
        return json_error("Could not save training.", 500)

    log_audit(conn, int(g.current_user["id"]), "training_saved", "training",
              f'Saved training "{title}" ({status})')
    return json_ok({"message": "Training saved", "id": training_id}, status=201)


@bp.route("/get_trainings.php", methods=["GET"])
@role_required(["hr", "admin"])
def get_trainings():
    conn = db()
    offset, limit = paginate(100, 500)
    with conn.cursor() as cur:
        cur.execute(
            "SELECT id, title, type, start_date, end_date, duration, max_participants, "
            "current_participants, status FROM trainings "
            "ORDER BY start_date DESC LIMIT %s OFFSET %s",
            (limit, offset),
        )
        rows = cur.fetchall()
    for r in rows:
        for k in ("start_date", "end_date"):
            if r.get(k): r[k] = str(r[k])
    return json_ok({"trainings": rows})