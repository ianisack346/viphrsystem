"""attendance_aggregator.py — routes device_punches to hr_attendance OR attendance_records"""
from datetime import datetime, timedelta
from flask import Blueprint, jsonify, request
from db import db
from auth import role_required

bp = Blueprint("attendance_aggregator", __name__)

LATE_CUTOFF_HOUR = 8
LATE_CUTOFF_MINUTE = 30
DUPLICATE_WINDOW_MINUTES = 3


def _dedupe(punches):
    if not punches:
        return []
    kept = [punches[0]]
    for p in punches[1:]:
        gap = (p - kept[-1]).total_seconds() / 60
        if gap >= DUPLICATE_WINDOW_MINUTES:
            kept.append(p)
    return kept


@bp.route("/aggregate_device_punches.php", methods=["POST", "GET"])
@role_required(["hr", "admin"])
def aggregate_device_punches():
    conn = db()
    days = int(request.args.get("days", 30))
    end_date = datetime.now().date()
    start_date = end_date - timedelta(days=days)

    i_staff = u_staff = i_hr = u_hr = skipped = 0
    processed = 0

    with conn.cursor() as cur:
        cur.execute(
            "SELECT employee_no, DATE(punch_time) AS d "
            "FROM device_punches "
            "WHERE DATE(punch_time) >= %s AND DATE(punch_time) <= %s "
            "GROUP BY employee_no, DATE(punch_time)",
            (start_date, end_date)
        )
        pairs = cur.fetchall()

    for pair in pairs:
        emp_no = pair["employee_no"]
        day = pair["d"]
        processed += 1

        # FIRST: Is this an HR user?
        with conn.cursor() as cur:
            cur.execute(
                "SELECT id FROM hr_users WHERE device_employee_no=%s LIMIT 1",
                (emp_no,)
            )
            hr_user = cur.fetchone()

        if hr_user:
            hr_id = int(hr_user["id"])
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT punch_time FROM device_punches "
                    "WHERE employee_no=%s AND DATE(punch_time)=%s "
                    "ORDER BY punch_time ASC",
                    (emp_no, day)
                )
                punches = [r["punch_time"] for r in cur.fetchall()]

            deduped = _dedupe(punches)
            if not deduped:
                continue

            check_in = deduped[0]
            check_out = deduped[-1] if len(deduped) > 1 else None
            cutoff = check_in.replace(hour=LATE_CUTOFF_HOUR, minute=LATE_CUTOFF_MINUTE, second=0)
            status = "late" if check_in > cutoff else "present"

            with conn.cursor() as cur:
                cur.execute(
                    "SELECT id FROM hr_attendance WHERE hr_user_id=%s AND date=%s LIMIT 1",
                    (hr_id, day)
                )
                existing = cur.fetchone()

                if existing:
                    cur.execute(
                        "UPDATE hr_attendance SET check_in_time=%s, check_out_time=%s, status=%s WHERE id=%s",
                        (check_in.strftime("%H:%M:%S"),
                         check_out.strftime("%H:%M:%S") if check_out else None,
                         status, existing["id"])
                    )
                    u_hr += 1
                else:
                    cur.execute(
                        "INSERT INTO hr_attendance (hr_user_id, date, check_in_time, check_out_time, status) "
                        "VALUES (%s, %s, %s, %s, %s)",
                        (hr_id, day,
                         check_in.strftime("%H:%M:%S"),
                         check_out.strftime("%H:%M:%S") if check_out else None,
                         status)
                    )
                    i_hr += 1
            continue

        # SECOND: Regular employee
        with conn.cursor() as cur:
            cur.execute("SELECT id FROM employees WHERE device_employee_no=%s LIMIT 1", (emp_no,))
            emp = cur.fetchone()
            if not emp:
                cur.execute("SELECT id FROM employees WHERE employee_code=%s LIMIT 1", (emp_no,))
                emp = cur.fetchone()

        if not emp:
            skipped += 1
            continue

        emp_id = int(emp["id"])

        with conn.cursor() as cur:
            cur.execute(
                "SELECT punch_time FROM device_punches "
                "WHERE employee_no=%s AND DATE(punch_time)=%s "
                "ORDER BY punch_time ASC",
                (emp_no, day)
            )
            punches = [r["punch_time"] for r in cur.fetchall()]

        deduped = _dedupe(punches)
        if not deduped:
            continue

        check_in = deduped[0]
        check_out = deduped[-1] if len(deduped) > 1 else None
        cutoff = check_in.replace(hour=LATE_CUTOFF_HOUR, minute=LATE_CUTOFF_MINUTE, second=0)
        status = "late" if check_in > cutoff else "present"

        with conn.cursor() as cur:
            cur.execute(
                "SELECT id FROM attendance_records WHERE employee_id=%s AND date=%s LIMIT 1",
                (emp_id, day)
            )
            existing = cur.fetchone()

            if existing:
                cur.execute(
                    "UPDATE attendance_records SET check_in_time=%s, check_out_time=%s, status=%s WHERE id=%s",
                    (check_in.strftime("%H:%M:%S"),
                     check_out.strftime("%H:%M:%S") if check_out else None,
                     status, existing["id"])
                )
                u_staff += 1
            else:
                cur.execute(
                    "INSERT INTO attendance_records (employee_id, date, check_in_time, check_out_time, status) "
                    "VALUES (%s, %s, %s, %s, %s)",
                    (emp_id, day,
                     check_in.strftime("%H:%M:%S"),
                     check_out.strftime("%H:%M:%S") if check_out else None,
                     status)
                )
                i_staff += 1

    conn.commit()

    return jsonify({
        "success": True,
        "days": days,
        "pairs_processed": processed,
        "inserted_staff": i_staff,
        "updated_staff": u_staff,
        "inserted_hr": i_hr,
        "updated_hr": u_hr,
        "skipped_no_employee": skipped,
    }), 200