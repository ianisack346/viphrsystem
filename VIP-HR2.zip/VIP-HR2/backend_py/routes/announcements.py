"""announcements.py — create_announcement, get_announcements, delete_announcement"""
from flask import Blueprint, request, g
from db import db
from helpers import json_ok, json_error, str_field, int_field, enum_field, log_audit
from auth import role_required

bp = Blueprint("announcements", __name__)


@bp.route("/create_announcement.php", methods=["POST"])
@role_required(["hr", "admin"])
def create_announcement():
    conn = db()
    body = request.form.to_dict() or {}
    if not body:
        body = request.get_json(silent=True) or {}

    title = str_field(body, "title")
    message = str_field(body, "message")
    audience = enum_field(body, "audience", ["all", "role", "department", "specific"], "all")

    if not title or not message:
        return json_error("Title and message are required.", 400)

    target_role = (enum_field(body, "target_role",
                              ["employee", "cso", "admin", "dept_manager"])
                   if audience == "role" else None)
    target_dept = int_field(body, "target_department_id") if audience == "department" else None
    target_user_ids = None
    if audience == "specific":
        raw = str_field(body, "user_ids")
        ids = [str(int(x)) for x in raw.split(",") if x.strip().isdigit()]
        target_user_ids = ",".join(ids) if ids else None

    with conn.cursor() as cur:
        cur.execute(
            "INSERT INTO announcements "
            "(title, message, audience, target_role, target_department_id, "
            "target_user_ids, status, posted_by) "
            "VALUES (%s, %s, %s, %s, %s, %s, 'active', %s)",
            (title, message, audience, target_role, target_dept,
             target_user_ids, g.current_user["id"]),
        )
        new_id = cur.lastrowid
    conn.commit()

    log_audit(conn, int(g.current_user["id"]), "announcement_created", "announcements",
              f'Posted "{title}"')
    return json_ok({"message": "Announcement created", "id": new_id}, status=201)


@bp.route("/get_announcements.php", methods=["GET"])
@role_required(["hr", "admin"])
def get_announcements():
    conn = db()
    status = enum_field(request.args, "status", ["active", "inactive"])
    limit = min(200, max(1, int_field(request.args, "limit", 100) or 100))

    sql = (
        "SELECT a.id, a.title, a.message, a.audience, a.target_role, "
        "a.target_department_id, a.status, COALESCE(hu.full_name, 'HR') AS posted_by, "
        "a.date_posted FROM announcements a "
        "LEFT JOIN hr_users hu ON hu.id = a.posted_by WHERE 1=1"
    )
    params = []
    if status:
        sql += " AND a.status=%s"; params.append(status)
    sql += f" ORDER BY a.date_posted DESC LIMIT {limit}"

    with conn.cursor() as cur:
        cur.execute(sql, params)
        rows = cur.fetchall()
    for r in rows:
        if r.get("date_posted"): r["date_posted"] = str(r["date_posted"])
    return json_ok({"data": rows})


@bp.route("/delete_announcement.php", methods=["POST"])
@role_required(["hr", "admin"])
def delete_announcement():
    conn = db()
    body = request.get_json(silent=True) or {}
    ann_id = int_field(body, "id")
    if not ann_id:
        return json_error("id is required.", 400)

    with conn.cursor() as cur:
        cur.execute("DELETE FROM announcements WHERE id=%s", (ann_id,))
        if cur.rowcount == 0:
            return json_error("Announcement not found.", 404)
    conn.commit()

    log_audit(conn, int(g.current_user["id"]), "announcement_deleted", "announcements",
              f"Deleted announcement #{ann_id}")
    return json_ok({"message": "Announcement deleted"})