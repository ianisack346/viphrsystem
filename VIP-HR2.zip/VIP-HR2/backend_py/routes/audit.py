"""audit.py — get_hr_audit_logs"""
from flask import Blueprint
from db import db
from helpers import json_ok, paginate
from auth import role_required

bp = Blueprint("audit", __name__)


@bp.route("/get_hr_audit_logs.php", methods=["GET"])
@role_required(["hr", "admin"])
def get_audit_logs():
    conn = db()
    offset, limit = paginate(100, 500)
    with conn.cursor() as cur:
        cur.execute(
            "SELECT al.id, al.action_type, al.module, al.description, al.created_at, "
            "COALESCE(hu.full_name, 'System') AS hr_name "
            "FROM audit_logs al LEFT JOIN hr_users hu ON hu.id = al.hr_user_id "
            "ORDER BY al.created_at DESC LIMIT %s OFFSET %s",
            (limit, offset),
        )
        rows = cur.fetchall()
    for r in rows:
        if r.get("created_at"): r["created_at"] = str(r["created_at"])
    return json_ok({"logs": rows})