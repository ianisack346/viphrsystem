"""performance.py — save_performance_review, get_performance_reviews"""
from flask import Blueprint, request, g
from db import db
from helpers import (
    json_ok, json_error, json_body, str_field, int_field, float_field,
    enum_field, is_valid_date, log_audit, paginate,
)
from auth import role_required

bp = Blueprint("performance", __name__)


@bp.route("/save_performance_review.php", methods=["POST"])
@role_required(["hr", "admin"])
def save_performance_review():
    conn = db()
    body = json_body()

    employee_ref = str_field(body, "employee_id")
    review_period = str_field(body, "review_period")
    review_date = str_field(body, "review_date")
    reviewer = str_field(body, "reviewer")
    overall_rating = str_field(body, "overall_rating")
    overall_score = float_field(body, "overall_score", 0) or 0
    metrics = body.get("metrics") if isinstance(body.get("metrics"), dict) else {}
    status = enum_field(body, "status",
                        ["Draft", "Completed", "Pending Review", "Approved"], "Draft")
    next_review_date = str_field(body, "next_review_date")

    if not employee_ref or not review_period or not is_valid_date(review_date) or not overall_rating:
        return json_error("Employee, review period, review date, and overall rating are required.", 400)

    with conn.cursor() as cur:
        if employee_ref.isdigit():
            cur.execute("SELECT id FROM employees WHERE id=%s LIMIT 1", (int(employee_ref),))
        else:
            cur.execute("SELECT id FROM employees WHERE employee_code=%s LIMIT 1", (employee_ref,))
        emp = cur.fetchone()
        if not emp:
            return json_error("Employee not found.", 404)

        cur.execute(
            "INSERT INTO performance_reviews "
            "(employee_id, review_period, review_date, reviewer, quality_of_work, "
            "productivity, teamwork, communication, initiative, attendance_score, "
            "overall_rating, overall_score, strengths, improvement_areas, goals, comments, "
            "status, next_review_date, created_by) "
            "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
            (
                emp["id"], review_period, review_date, reviewer,
                int_field(metrics, "quality_of_work", 0) or 0,
                int_field(metrics, "productivity", 0) or 0,
                int_field(metrics, "teamwork", 0) or 0,
                int_field(metrics, "communication", 0) or 0,
                int_field(metrics, "initiative", 0) or 0,
                int_field(metrics, "attendance", 0) or 0,
                overall_rating, overall_score,
                str_field(body, "strengths"),
                str_field(body, "improvement_areas"),
                str_field(body, "goals"),
                str_field(body, "comments"),
                status,
                next_review_date if is_valid_date(next_review_date) else None,
                g.current_user["id"],
            ),
        )
        new_id = cur.lastrowid
    conn.commit()

    log_audit(conn, int(g.current_user["id"]), "performance_review_saved", "performance",
              f"Saved review #{new_id} ({status})")
    return json_ok({"message": "Performance review saved", "id": new_id}, status=201)


@bp.route("/get_performance_reviews.php", methods=["GET"])
@role_required(["hr", "admin"])
def get_performance_reviews():
    conn = db()
    offset, limit = paginate(100, 500)
    with conn.cursor() as cur:
        cur.execute(
            "SELECT pr.id, CONCAT(e.firstname, ' ', e.lastname) AS employee_name, "
            "pr.review_period, pr.review_date, pr.overall_score, pr.status "
            "FROM performance_reviews pr JOIN employees e ON e.id = pr.employee_id "
            "ORDER BY pr.review_date DESC LIMIT %s OFFSET %s",
            (limit, offset),
        )
        rows = cur.fetchall()
    for r in rows:
        if r.get("review_date"): r["review_date"] = str(r["review_date"])
    return json_ok({"reviews": rows})