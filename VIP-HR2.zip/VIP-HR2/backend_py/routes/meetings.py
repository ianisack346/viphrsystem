"""meetings.py — hr_meeting_handler (schedule / cancel)"""
from flask import Blueprint, request, g
from db import db
from helpers import (
    json_ok, json_error, json_body, str_field, int_field, enum_field,
    is_valid_date, log_audit,
)
from auth import role_required

bp = Blueprint("meetings", __name__)


@bp.route("/hr_meeting_handler.php", methods=["POST"])
@role_required(["hr", "admin"])
def hr_meeting_handler():
    conn = db()
    body = json_body()
    action = enum_field(body, "action", ["schedule", "cancel"])

    if action == "cancel":
        meeting_id = int_field(body, "meeting_id")
        if not meeting_id:
            return json_error("meeting_id is required.", 400)
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE meetings SET status='cancelled' "
                "WHERE meeting_id=%s AND status='scheduled'",
                (meeting_id,),
            )
            if cur.rowcount == 0:
                return json_error("Meeting not found or already resolved.", 404)
        conn.commit()
        log_audit(conn, int(g.current_user["id"]), "meeting_cancelled", "meetings",
                  f"Cancelled meeting #{meeting_id}")
        return json_ok({"message": "Meeting cancelled"})

    if action == "schedule":
        title = str_field(body, "title")
        subject = str_field(body, "subject")
        objective = str_field(body, "objective")
        date = str_field(body, "meeting_date")
        start = str_field(body, "start_time")
        end = str_field(body, "end_time")
        scope = enum_field(body, "scope",
                           ["all", "department", "managers", "specific"])

        if not title or not subject or not objective or not is_valid_date(date) \
                or not start or not end or not scope:
            return json_error("All required meeting fields must be filled.", 400)
        if end <= start:
            return json_error("End time must be after start time.", 400)

        department_id = None
        dept_name = str_field(body, "department")
        if dept_name:
            with conn.cursor() as cur:
                cur.execute("SELECT id FROM departments WHERE name=%s LIMIT 1", (dept_name,))
                d = cur.fetchone()
                department_id = int(d["id"]) if d else None

        try:
            with conn.cursor() as cur:
                cur.execute(
                    "INSERT INTO meetings "
                    "(title, subject, objectives, meeting_date, start_time, end_time, "
                    "scope, department_id, location, notes, status, created_by) "
                    "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 'scheduled', %s)",
                    (title, subject, objective, date, start, end, scope,
                     department_id, str_field(body, "location"),
                     str_field(body, "notes"), g.current_user["id"]),
                )
                meeting_id = cur.lastrowid

                attendees = str_field(body, "attendees")
                if attendees:
                    ids = [int(x) for x in attendees.split(",") if x.strip().isdigit()]
                    for eid in ids:
                        cur.execute(
                            "INSERT IGNORE INTO meeting_attendees "
                            "(meeting_id, employee_id) VALUES (%s, %s)",
                            (meeting_id, eid),
                        )
            conn.commit()
        except Exception as e:
            conn.rollback()
            print(f"[MEETING SCHEDULE] {e}")
            return json_error("Could not schedule meeting.", 500)

        log_audit(conn, int(g.current_user["id"]), "meeting_scheduled", "meetings",
                  f'Scheduled "{title}"')
        return json_ok({"message": "Meeting scheduled", "meeting_id": meeting_id},
                       status=201)

    return json_error("Unsupported request.", 400)