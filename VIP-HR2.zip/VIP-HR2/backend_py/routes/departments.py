"""departments.py — get_hr_departments"""
from flask import Blueprint
from db import db
from helpers import json_ok
from auth import role_required

bp = Blueprint("departments", __name__)


@bp.route("/get_hr_departments.php", methods=["GET"])
@role_required(["hr", "admin", "manager"])
def get_departments():
    conn = db()
    with conn.cursor() as cur:
        cur.execute("SELECT id, name, code FROM departments ORDER BY name")
        return json_ok({"departments": cur.fetchall()})