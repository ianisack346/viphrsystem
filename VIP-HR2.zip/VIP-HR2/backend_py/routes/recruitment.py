"""recruitment.py — save_recruitment, getRecruitmentData, get_application_detail,
update_application_status, delete_recruitment"""
from flask import Blueprint, request, g
from db import db
from helpers import (
    json_ok, json_error, json_body, str_field, int_field, float_field,
    enum_field, is_valid_date, log_audit,
)
from auth import role_required

bp = Blueprint("recruitment", __name__)


@bp.route("/save_recruitment.php", methods=["POST"])
@role_required(["hr", "admin"])
def save_recruitment():
    conn = db()
    body = json_body()

    position_title = str_field(body, "position_title")
    department_name = str_field(body, "department")
    closing_date = str_field(body, "closing_date")

    if not position_title or not department_name or not is_valid_date(closing_date):
        return json_error("Position title, department, and a valid closing date are required.", 400)

    with conn.cursor() as cur:
        cur.execute("SELECT id FROM departments WHERE name=%s LIMIT 1", (department_name,))
        dept = cur.fetchone()
        department_id = int(dept["id"]) if dept else None

    priority = enum_field(body, "priority", ["Low", "Medium", "High", "Urgent"], "Medium")

    with conn.cursor() as cur:
        cur.execute(
            "INSERT INTO recruitment_vacancies "
            "(position_title, department_id, job_description, job_requirements, "
            "closing_date, priority, employment_type, min_qualification, "
            "experience_years, num_posts, location, salary_min, salary_max, "
            "salary_grade, internal_notes, status, posted_by) "
            "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 'open', %s)",
            (
                position_title, department_id,
                str_field(body, "job_description"),
                str_field(body, "job_requirements"),
                closing_date, priority,
                str_field(body, "employment_type"),
                str_field(body, "min_qualification"),
                int_field(body, "experience_years", 0) or 0,
                int_field(body, "num_posts", 1) or 1,
                str_field(body, "location"),
                float_field(body, "salary_min"),
                float_field(body, "salary_max"),
                str_field(body, "salary_grade"),
                str_field(body, "internal_notes"),
                g.current_user["id"],
            ),
        )
        new_id = cur.lastrowid
    conn.commit()

    notified = bool(body.get("notify"))
    log_audit(conn, int(g.current_user["id"]), "vacancy_posted", "recruitment",
              f'Posted vacancy "{position_title}"'
              + (" (candidates notified)" if notified else ""))
    return json_ok({"message": "Vacancy posted", "id": new_id}, status=201)


@bp.route("/getRecruitmentData.php", methods=["GET"])
@role_required(["hr", "admin"])
def get_recruitment_data():
    conn = db()
    status = enum_field(request.args, "status",
                        ["pending", "under_review", "shortlisted",
                         "interview", "approved", "rejected"])
    department = str_field(request.args, "department")
    priority = enum_field(request.args, "priority", ["Low", "Medium", "High", "Urgent"])
    search = str_field(request.args, "search")

    sql = (
        "SELECT a.id AS application_id, a.id, "
        "v.position_title AS position_applied, v.position_title AS position, "
        "v.priority, CONCAT(c.first_name, ' ', c.last_name) AS applicant_name, "
        "c.email, c.phone, a.status, DATE(a.submission_date) AS application_date "
        "FROM rms_applications a "
        "JOIN rms_candidates c ON c.id = a.user_id "
        "JOIN recruitment_vacancies v ON v.id = a.vacancy_id "
        "LEFT JOIN departments d ON d.id = v.department_id WHERE 1=1"
    )
    params = []
    if status:
        sql += " AND a.status = %s"; params.append(status)
    if department:
        sql += " AND d.name = %s"; params.append(department)
    if priority:
        sql += " AND v.priority = %s"; params.append(priority)
    if search:
        sql += " AND (c.first_name LIKE %s OR c.last_name LIKE %s OR c.email LIKE %s)"
        like = f"%{search}%"; params.extend([like, like, like])
    sql += " ORDER BY a.submission_date DESC"

    with conn.cursor() as cur:
        cur.execute(sql, params)
        rows = cur.fetchall()
    for r in rows:
        if r.get("application_date"):
            r["application_date"] = str(r["application_date"])
    return json_ok({"data": rows})


@bp.route("/get_application_detail.php", methods=["GET"])
@role_required(["hr", "admin"])
def get_application_detail():
    conn = db()
    app_id = int_field(request.args, "application_id")
    if not app_id:
        return json_error("application_id is required.", 400)

    with conn.cursor() as cur:
        cur.execute(
            "SELECT a.*, c.first_name, c.last_name, c.email, c.phone, c.nin, "
            "c.date_of_birth, c.region, c.district, c.ward, c.village, c.address, "
            "c.disability_status, c.profession, v.position_title, "
            "v.reference_number AS vacancy_ref "
            "FROM rms_applications a "
            "JOIN rms_candidates c ON c.id = a.user_id "
            "JOIN recruitment_vacancies v ON v.id = a.vacancy_id "
            "WHERE a.id = %s",
            (app_id,),
        )
        app = cur.fetchone()
        if not app:
            return json_error("Application not found.", 404)

        cur.execute("SELECT * FROM rms_education WHERE application_id=%s ORDER BY id", (app_id,))
        education = cur.fetchall()
        cur.execute("SELECT * FROM rms_documents WHERE application_id=%s ORDER BY doc_type", (app_id,))
        documents = cur.fetchall()
        cur.execute("SELECT * FROM rms_status_tracker WHERE application_id=%s ORDER BY id", (app_id,))
        tracker = cur.fetchall()

    for r in [app] + education + documents + tracker:
        for k, v in list(r.items()):
            if hasattr(v, "isoformat"):
                r[k] = str(v)

    return json_ok({
        "application": app, "education": education,
        "documents": documents, "status_tracker": tracker,
    })


@bp.route("/update_application_status.php", methods=["POST"])
@role_required(["hr", "admin"])
def update_application_status():
    conn = db()
    body = json_body()

    app_id = int_field(body, "application_id")
    status = enum_field(body, "status",
                        ["under_review", "shortlisted", "interview", "approved", "rejected"])
    step_name = str_field(body, "step_name")
    step_status = enum_field(body, "step_status", ["pending", "completed"], "completed")
    description = str_field(body, "description")

    if not app_id:
        return json_error("application_id is required.", 400)

    with conn.cursor() as cur:
        cur.execute("SELECT id FROM rms_applications WHERE id=%s LIMIT 1", (app_id,))
        if not cur.fetchone():
            return json_error("Application not found.", 404)

    try:
        with conn.cursor() as cur:
            if status:
                cur.execute(
                    "UPDATE rms_applications SET status=%s, updated_at=NOW() WHERE id=%s",
                    (status, app_id),
                )
            if step_name:
                cur.execute(
                    "UPDATE rms_status_tracker SET step_status=%s, step_date=CURDATE(), "
                    "description=%s WHERE application_id=%s AND step_name=%s",
                    (step_status, description, app_id, step_name),
                )
        conn.commit()
    except Exception as e:
        conn.rollback()
        print(f"[APPLICATION STATUS] {e}")
        return json_error("Could not update application.", 500)

    log_audit(conn, int(g.current_user["id"]), "application_status_updated", "recruitment",
              f"Application #{app_id}"
              + (f" → {status}" if status else "")
              + (f'; stage "{step_name}" → {step_status}' if step_name else ""))
    return json_ok({"message": "Status updated successfully"})


@bp.route("/delete_recruitment.php", methods=["POST"])
@role_required(["hr", "admin"])
def delete_recruitment():
    conn = db()
    body = json_body()
    app_id = int_field(body, "application_id")
    if not app_id:
        return json_error("application_id is required.", 400)

    with conn.cursor() as cur:
        cur.execute("SELECT id FROM rms_applications WHERE id=%s LIMIT 1", (app_id,))
        if not cur.fetchone():
            return json_error("Application not found.", 404)
        cur.execute("DELETE FROM rms_applications WHERE id=%s", (app_id,))
    conn.commit()

    log_audit(conn, int(g.current_user["id"]), "application_deleted", "recruitment",
              f"Deleted application #{app_id}")
    return json_ok({"message": "Application deleted"})