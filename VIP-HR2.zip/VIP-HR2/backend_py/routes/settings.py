"""settings.py — hr_settings_handler (load / save)"""
from flask import Blueprint, request, g
from db import db
from helpers import json_ok, json_error, json_body, log_audit
from auth import role_required

bp = Blueprint("settings", __name__)

ALLOWED_KEYS = {
    "companyName", "companyTimezone", "companyCurrency",
    "monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday",
    "workStartTime", "workEndTime", "gracePeriod", "autoCheckout", "remoteWorkDays",
    "overtimeRate", "annualLeave", "sickLeave", "carryForward", "approvalHierarchy",
    "passwordExpiry", "maxLoginAttempts", "twoFactorAuth", "deviceRestrictions",
    "sessionTimeout", "auditLogging", "smtpServer", "smtpPort", "fromEmail", "fromName",
    "leaveReminders", "attendanceReminders", "payrollReminders",
    "uiTheme", "defaultDashboard", "auditRetention", "attendanceRetention",
    "performanceRetention", "payrollRetention", "backupFrequency", "backupTime",
    "backupLocation",
}


@bp.route("/hr_settings_handler.php", methods=["GET", "POST"])
@role_required(["hr", "admin"])
def hr_settings_handler():
    conn = db()
    action = request.args.get("action") or ("save" if request.method == "POST" else "load")

    if action == "load":
        with conn.cursor() as cur:
            cur.execute("SELECT setting_key, setting_value FROM system_settings")
            rows = cur.fetchall()
        settings = {r["setting_key"]: r["setting_value"] for r in rows}
        return json_ok({"settings": settings})

    if action == "save":
        body = json_body()
        settings = body.get("settings") or {}
        if not isinstance(settings, dict) or not settings:
            return json_error("No settings supplied.", 400)

        try:
            with conn.cursor() as cur:
                for k, v in settings.items():
                    if k not in ALLOWED_KEYS:
                        continue
                    cur.execute(
                        "INSERT INTO system_settings (setting_key, setting_value) "
                        "VALUES (%s, %s) ON DUPLICATE KEY UPDATE "
                        "setting_value=VALUES(setting_value)",
                        (k, str(v)),
                    )
            conn.commit()
        except Exception as e:
            conn.rollback()
            print(f"[SETTINGS SAVE] {e}")
            return json_error("Could not save settings.", 500)

        log_audit(conn, int(g.current_user["id"]), "settings_update", "settings",
                  "Updated system settings")
        return json_ok({"message": "Settings saved"})

    return json_error("Unknown action.", 400)