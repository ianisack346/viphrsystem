"""attendance.py — getAttendanceData, hr_attendance_handler, getHrTimeBook"""
from datetime import datetime
from flask import Blueprint, request, g, jsonify
from db import db
from helpers import (
    json_ok, json_error, json_body, str_field, int_field, enum_field,
    float_field, log_audit, paginate,
)
from auth import role_required, login_required

bp = Blueprint("attendance", __name__)


@bp.route("/getAttendanceData.php", methods=["GET"])
@role_required(["hr", "admin"])
def get_attendance_data():
    conn = db()
    offset, limit = paginate(100, 500)
    with conn.cursor() as cur:
        cur.execute(
            "SELECT e.employee_code, e.firstname AS first_name, e.lastname AS last_name, "
            "d.name AS department, ar.date, ar.check_in_time, ar.check_out_time, "
            "CASE WHEN ar.check_in_time IS NOT NULL AND ar.check_out_time IS NOT NULL "
            "THEN TIME_FORMAT(TIMEDIFF(ar.check_out_time, ar.check_in_time), '%%H:%%i') "
            "ELSE NULL END AS duration "
            "FROM attendance_records ar "
            "JOIN employees e ON e.id = ar.employee_id "
            "LEFT JOIN departments d ON d.id = e.department_id "
            "ORDER BY ar.date DESC, e.firstname LIMIT %s OFFSET %s",
            (limit, offset),
        )
        rows = cur.fetchall()
    for r in rows:
        if r.get("date") is not None: r["date"] = str(r["date"])
        for k in ("check_in_time", "check_out_time"):
            if r.get(k) is not None: r[k] = str(r[k])
    return jsonify(rows), 200


@bp.route("/hr_attendance_handler.php", methods=["GET", "POST"])
@login_required
def hr_attendance_handler():
    conn = db()
    user = g.current_user
    today = datetime.utcnow().strftime("%Y-%m-%d")

    if request.method == "GET" and request.args.get("action") == "get_today_status":
        with conn.cursor() as cur:
            cur.execute(
                "SELECT status, check_in_time, check_out_time FROM hr_attendance "
                "WHERE hr_user_id=%s AND date=%s",
                (user["id"], today),
            )
            record = cur.fetchone()
        if record:
            for k in ("check_in_time", "check_out_time"):
                if record.get(k) is not None: record[k] = str(record[k])
        return json_ok({"record": record})

    if request.method == "POST":
        body = json_body()
        action = enum_field(body, "action", ["check_in", "check_out"])

        if action == "check_in":
            status = enum_field(body, "status",
                                ["present", "present_late", "late", "absent"])
            reason = str_field(body, "reason")
            lat = float_field(body, "latitude")
            lng = float_field(body, "longitude")

            if not status:
                return json_error("A valid status is required.", 400)
            if status in ("late", "absent") and not reason:
                return json_error("A reason is required for late or absent check-ins.", 400)
            if lat is None or lng is None:
                return json_error("Location is required to check in.", 400)

            if datetime.utcnow().isoweekday() == 7:
                return json_error("Check-ins are not allowed on Sundays.", 403)

            with conn.cursor() as cur:
                cur.execute(
                    "SELECT id FROM hr_attendance WHERE hr_user_id=%s AND date=%s",
                    (user["id"], today),
                )
                if cur.fetchone():
                    return json_error("You have already checked in today.", 409)
                now = datetime.utcnow().strftime("%H:%M:%S")
                cur.execute(
                    "INSERT INTO hr_attendance "
                    "(hr_user_id, date, check_in_time, status, reason, latitude, longitude) "
                    "VALUES (%s, %s, %s, %s, %s, %s, %s)",
                    (user["id"], today, now, status, reason, lat, lng),
                )
            conn.commit()
            log_audit(conn, int(user["id"]), "hr_check_in", "attendance",
                      f"Checked in as {status}")
            return json_ok({"message": "Checked in", "check_in_time": now})

        if action == "check_out":
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT id, check_out_time FROM hr_attendance "
                    "WHERE hr_user_id=%s AND date=%s",
                    (user["id"], today),
                )
                record = cur.fetchone()
                if not record:
                    return json_error("You have not checked in today.", 409)
                if record["check_out_time"]:
                    return json_error("You have already checked out today.", 409)
                now = datetime.utcnow().strftime("%H:%M:%S")
                cur.execute(
                    "UPDATE hr_attendance SET check_out_time=%s WHERE id=%s",
                    (now, record["id"]),
                )
            conn.commit()
            log_audit(conn, int(user["id"]), "hr_check_out", "attendance", "Checked out")
            return json_ok({"message": "Checked out", "check_out_time": now})

    return json_error("Unsupported request.", 400)


@bp.route("/getHrTimeBook.php", methods=["GET"])
@role_required(["hr", "admin"])
def get_hr_time_book():
    conn = db()
    offset, limit = paginate(100, 500)
    with conn.cursor() as cur:
        cur.execute(
            "SELECT hu.full_name AS employee_name, hu.hr_code AS employee_code, "
            "ha.check_in_time AS check_in, ha.check_out_time AS check_out, "
            "CASE WHEN ha.check_in_time IS NOT NULL AND ha.check_out_time IS NOT NULL "
            "THEN TIME_FORMAT(TIMEDIFF(ha.check_out_time, ha.check_in_time), '%%H:%%i') "
            "ELSE NULL END AS total_hours, ha.status "
            "FROM hr_attendance ha JOIN hr_users hu ON hu.id = ha.hr_user_id "
            "ORDER BY ha.date DESC, hu.full_name LIMIT %s OFFSET %s",
            (limit, offset),
        )
        rows = cur.fetchall()
    for r in rows:
        for k in ("check_in", "check_out"):
            if r.get(k) is not None: r[k] = str(r[k])
    return jsonify(rows), 200