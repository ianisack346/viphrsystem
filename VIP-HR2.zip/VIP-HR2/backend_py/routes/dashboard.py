"""dashboard.py — all dashboard GET endpoints"""
from datetime import datetime, timedelta
from flask import Blueprint, request, jsonify
from db import db
from helpers import json_ok, int_field
from auth import role_required

bp = Blueprint("dashboard", __name__)


def _scalar(cur, sql, params=()):
    cur.execute(sql, params)
    row = cur.fetchone()
    if not row:
        return 0
    return int(list(row.values())[0] or 0)


def _ser(rows, keys):
    for r in rows:
        for k in keys:
            if r.get(k) is not None:
                r[k] = str(r[k])
    return rows


@bp.route("/get_dashboard_stats.php", methods=["GET"])
@role_required(["hr", "admin"])
def get_dashboard_stats():
    conn = db()
    today = datetime.utcnow().strftime("%Y-%m-%d")
    with conn.cursor() as cur:
        total_employees = _scalar(cur, "SELECT COUNT(*) AS cnt FROM employees WHERE status='Active'")
        pending_leaves = _scalar(cur, "SELECT COUNT(*) AS cnt FROM leave_requests WHERE status='pending'")

        cur.execute(
            "SELECT status, COUNT(*) AS cnt FROM attendance_records "
            "WHERE date=%s GROUP BY status",
            (today,),
        )
        by_status = {"present": 0, "present_late": 0, "late": 0, "absent": 0}
        for row in cur.fetchall():
            by_status[row["status"]] = int(row["cnt"])

        overdue_trainings = _scalar(
            cur,
            "SELECT COUNT(*) AS cnt FROM trainings "
            "WHERE end_date < NOW() AND status NOT IN ('Completed','Cancelled')"
        )

        leave_types = ["Annual", "Sick", "Personal", "Maternity"]
        leave_counts = []
        for lt in leave_types:
            cur.execute(
                "SELECT COUNT(*) AS cnt FROM leave_requests "
                "WHERE leave_type LIKE CONCAT(%s, '%%') AND status='approved'",
                (lt,),
            )
            leave_counts.append(int(cur.fetchone()["cnt"]))

    return json_ok({
        "total_employees": total_employees,
        "pending_leaves": pending_leaves,
        "present_today": by_status["present"],
        "present_late_today": by_status["present"] + by_status["present_late"],
        "late_employees": by_status["late"],
        "absent_today": by_status["absent"],
        "overdue_trainings": overdue_trainings,
        "leave_types": leave_types,
        "leave_counts": leave_counts,
    })


@bp.route("/get_recent_activity.php", methods=["GET"])
@role_required(["hr", "admin"])
def get_recent_activity():
    conn = db()
    limit = min(50, max(1, int_field(request.args, "limit", 10) or 10))
    with conn.cursor() as cur:
        cur.execute(
            "SELECT action_type AS type, description, created_at "
            "FROM audit_logs ORDER BY created_at DESC LIMIT %s",
            (limit,),
        )
        rows = cur.fetchall()
    return jsonify(_ser(rows, ["created_at"])), 200


@bp.route("/get_attendance_heatmap.php", methods=["GET"])
@role_required(["hr", "admin"])
def get_attendance_heatmap():
    conn = db()
    days = []
    cursor = datetime.utcnow().date()
    while len(days) < 5:
        if cursor.weekday() < 5:
            days.append(cursor.strftime("%Y-%m-%d"))
        cursor -= timedelta(days=1)
    days.reverse()

    present, late, absent, labels = [], [], [], []
    with conn.cursor() as cur:
        for date in days:
            cur.execute(
                "SELECT status, COUNT(*) AS cnt FROM attendance_records "
                "WHERE date=%s GROUP BY status",
                (date,),
            )
            counts = {"present": 0, "present_late": 0, "late": 0, "absent": 0}
            for row in cur.fetchall():
                counts[row["status"]] = int(row["cnt"])
            labels.append(datetime.strptime(date, "%Y-%m-%d").strftime("%a"))
            present.append(counts["present"] + counts["present_late"])
            late.append(counts["late"])
            absent.append(counts["absent"])

    return json_ok({"days": labels, "present": present,
                    "late": late, "absent": absent})


@bp.route("/get_UpcomingTrainings.php", methods=["GET"])
@role_required(["hr", "admin"])
def get_upcoming_trainings():
    conn = db()
    limit = min(20, max(1, int_field(request.args, "limit", 5) or 5))
    with conn.cursor() as cur:
        cur.execute(
            "SELECT title, start_date, trainer_name AS trainer FROM trainings "
            "WHERE start_date >= NOW() AND status NOT IN ('Cancelled','Completed') "
            "ORDER BY start_date ASC LIMIT %s",
            (limit,),
        )
        rows = cur.fetchall()
    return jsonify(_ser(rows, ["start_date"])), 200


@bp.route("/get_UpcomingMeetings.php", methods=["GET"])
@role_required(["hr", "admin"])
def get_upcoming_meetings():
    conn = db()
    limit = min(200, max(1, int_field(request.args, "limit", 5) or 5))
    with conn.cursor() as cur:
        cur.execute(
            "SELECT m.meeting_id, m.title, m.subject, m.objectives, m.meeting_date, "
            "m.meeting_date AS date, m.start_time, m.end_time, m.start_time AS time, "
            "m.scope, d.name AS department_name, m.status "
            "FROM meetings m LEFT JOIN departments d ON d.id = m.department_id "
            "ORDER BY m.meeting_date DESC, m.start_time DESC LIMIT %s",
            (limit,),
        )
        rows = cur.fetchall()
    return jsonify(_ser(rows, ["meeting_date", "date", "start_time", "end_time", "time"])), 200


@bp.route("/get_UpcomingEvents.php", methods=["GET"])
@role_required(["hr", "admin"])
def get_upcoming_events():
    conn = db()
    limit = min(20, max(1, int_field(request.args, "limit", 5) or 5))
    with conn.cursor() as cur:
        # company_events may not have `location` or may use different col names.
        # Try the common shape; if the query fails we fall back to empty list.
        try:
            cur.execute(
                "SELECT title, event_date, location FROM company_events "
                "WHERE event_date >= CURDATE() ORDER BY event_date ASC LIMIT %s",
                (limit,),
            )
            rows = cur.fetchall()
        except Exception:
            conn.rollback()
            rows = []
    return jsonify(_ser(rows, ["event_date"])), 200