"""helpers.py — input helpers, JSON responses, audit log"""
from datetime import datetime
from flask import jsonify, request
from db import db as _db


# ---------- JSON responses ----------
def json_ok(data: dict = None, msg: str = "", status: int = 200):
    payload = {"success": True, "message": msg}
    if data:
        payload.update(data)
    return jsonify(payload), status


def json_error(msg: str, status: int = 400):
    return jsonify({"success": False, "message": msg}), status


# ---------- Input helpers ----------
def json_body() -> dict:
    data = request.get_json(silent=True)
    return data if isinstance(data, dict) else {}


def str_field(src: dict, key: str, default: str = "") -> str:
    v = src.get(key, default)
    return v.strip() if isinstance(v, str) else default


def int_field(src: dict, key: str, default=None):
    v = src.get(key)
    if v is None or v == "":
        return default
    try:
        return int(v)
    except (ValueError, TypeError):
        return default


def float_field(src: dict, key: str, default=None):
    v = src.get(key)
    if v is None or v == "":
        return default
    try:
        return float(v)
    except (ValueError, TypeError):
        return default


def enum_field(src: dict, key: str, allowed: list, default: str = "") -> str:
    v = src.get(key)
    v = v.strip() if isinstance(v, str) else ""
    return v if v in allowed else default


def paginate(default_limit: int = 100, max_limit: int = 500):
    limit = int_field(request.args, "limit", default_limit) or default_limit
    limit = max(1, min(limit, max_limit))
    page = max(1, int_field(request.args, "page", 1) or 1)
    return (page - 1) * limit, limit


# ---------- Dates ----------
def is_valid_date(s: str) -> bool:
    if not s or not isinstance(s, str):
        return False
    for fmt in ("%Y-%m-%d", "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M"):
        try:
            datetime.strptime(s, fmt)
            return True
        except ValueError:
            continue
    return False


# ---------- HTML escape ----------
def h(value) -> str:
    if value is None:
        return ""
    return (
        str(value)
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#39;")
    )


# ---------- File size ----------
def format_bytes(n: int) -> str:
    units = ["B", "KB", "MB", "GB"]
    size = abs(int(n or 0))
    i = 0
    while size >= 1024 and i < len(units) - 1:
        size /= 1024
        i += 1
    return f"{round(size, 2)} {units[i]}"


# ---------- Audit log ----------
def log_audit(conn, user_id, action_type: str, module: str, description: str):
    try:
        with conn.cursor() as cur:
            cur.execute(
                "INSERT INTO audit_logs (action_type, module, description, hr_user_id) "
                "VALUES (%s, %s, %s, %s)",
                (action_type, module, description, user_id),
            )
        conn.commit()
    except Exception as e:
        print(f"[audit] {e}")