"""scheduler.py — background jobs:
   1. Pull Hikvision punches every 5 minutes → device_punches
   2. Aggregate device_punches → hr_attendance (for HR) OR attendance_records (for staff) every 15 minutes
"""
from datetime import datetime, timedelta
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.interval import IntervalTrigger
import atexit
import os


# valid successful face/fingerprint verification codes from the device
VALID_MINORS = (38, 39, 75, 76)


def _pull_job(app):
    """Pull last 2 days of punches from the device."""
    with app.app_context():
        try:
            from routes.device_pull import _fetch_all_events
            from db import db

            conn = db()
            end = datetime.now()
            start = end - timedelta(days=2)
            events = _fetch_all_events(start, end)

            serial = os.getenv("HIKVISION_SERIAL", "GQ2131615")
            inserted = 0

            for ev in events:
                if ev.get("major") != 5 or ev.get("minor") not in VALID_MINORS:
                    continue
                emp_no_raw = ev.get("employeeNoString")
                emp_no = emp_no_raw.lstrip("0") if emp_no_raw else ""
                emp_name = ev.get("name", "")
                time_str = ev.get("time")
                serial_no = ev.get("serialNo")
                if not emp_no or not time_str:
                    continue
                try:
                    punch_time = datetime.fromisoformat(time_str.replace("+03:00", ""))
                except ValueError:
                    continue
                with conn.cursor() as cur:
                    cur.execute(
                        "SELECT id FROM device_punches "
                        "WHERE device_serial=%s AND employee_no=%s AND punch_time=%s",
                        (serial, emp_no, punch_time)
                    )
                    if cur.fetchone():
                        continue
                    cur.execute(
                        "INSERT INTO device_punches "
                        "(device_serial, employee_no, employee_name, punch_time, punch_type, serial_no) "
                        "VALUES (%s, %s, %s, %s, 'check-in', %s)",
                        (serial, emp_no, emp_name, punch_time, serial_no)
                    )
                    inserted += 1
            conn.commit()
            print(f"[SCHEDULER:pull] complete, inserted {inserted} new punches")
        except Exception as e:
            print(f"[SCHEDULER:pull ERROR] {e}")


def _aggregate_job(app):
    """Aggregate device_punches -> hr_attendance (HR) OR attendance_records (staff)."""
    with app.app_context():
        try:
            from db import db
            conn = db()

            LATE_CUTOFF_HOUR = 8
            LATE_CUTOFF_MINUTE = 30
            DUPLICATE_WINDOW_MINUTES = 3

            end_date = datetime.now().date()
            start_date = end_date - timedelta(days=30)

            def _dedupe(punches):
                if not punches:
                    return []
                kept = [punches[0]]
                for p in punches[1:]:
                    if (p - kept[-1]).total_seconds() / 60 >= DUPLICATE_WINDOW_MINUTES:
                        kept.append(p)
                return kept

            with conn.cursor() as cur:
                cur.execute(
                    "SELECT employee_no, DATE(punch_time) AS d FROM device_punches "
                    "WHERE DATE(punch_time) >= %s AND DATE(punch_time) <= %s "
                    "GROUP BY employee_no, DATE(punch_time)",
                    (start_date, end_date)
                )
                pairs = cur.fetchall()

            i_staff = u_staff = i_hr = u_hr = skipped = 0

            for pair in pairs:
                emp_no = pair["employee_no"]
                day = pair["d"]

                # FIRST: Is this an HR user?
                with conn.cursor() as cur:
                    cur.execute("SELECT id FROM hr_users WHERE device_employee_no=%s LIMIT 1", (emp_no,))
                    hr_user = cur.fetchone()

                if hr_user:
                    hr_id = int(hr_user["id"])
                    with conn.cursor() as cur:
                        cur.execute(
                            "SELECT punch_time FROM device_punches WHERE employee_no=%s AND DATE(punch_time)=%s ORDER BY punch_time ASC",
                            (emp_no, day)
                        )
                        punches = [r["punch_time"] for r in cur.fetchall()]

                    deduped = _dedupe(punches)
                    if not deduped:
                        continue

                    check_in, check_out = deduped[0], (deduped[-1] if len(deduped) > 1 else None)
                    cutoff = check_in.replace(hour=LATE_CUTOFF_HOUR, minute=LATE_CUTOFF_MINUTE, second=0)
                    status = "late" if check_in > cutoff else "present"

                    with conn.cursor() as cur:
                        cur.execute("SELECT id FROM hr_attendance WHERE hr_user_id=%s AND date=%s LIMIT 1", (hr_id, day))
                        existing = cur.fetchone()
                        if existing:
                            cur.execute("UPDATE hr_attendance SET check_in_time=%s, check_out_time=%s, status=%s WHERE id=%s",
                                (check_in.strftime("%H:%M:%S"), check_out.strftime("%H:%M:%S") if check_out else None, status, existing["id"]))
                            u_hr += 1
                        else:
                            cur.execute("INSERT INTO hr_attendance (hr_user_id, date, check_in_time, check_out_time, status) VALUES (%s, %s, %s, %s, %s)",
                                (hr_id, day, check_in.strftime("%H:%M:%S"), check_out.strftime("%H:%M:%S") if check_out else None, status))
                            i_hr += 1
                    continue

                # SECOND: Regular employee
                with conn.cursor() as cur:
                    cur.execute("SELECT id FROM employees WHERE device_employee_no=%s LIMIT 1", (emp_no,))
                    emp = cur.fetchone()
                    if not emp:
                        cur.execute("SELECT id FROM employees WHERE employee_code=%s LIMIT 1", (emp_no,))
                        emp = cur.fetchone()

                if not emp:
                    skipped += 1
                    continue

                emp_id = int(emp["id"])
                with conn.cursor() as cur:
                    cur.execute(
                        "SELECT punch_time FROM device_punches WHERE employee_no=%s AND DATE(punch_time)=%s ORDER BY punch_time ASC",
                        (emp_no, day)
                    )
                    punches = [r["punch_time"] for r in cur.fetchall()]

                deduped = _dedupe(punches)
                if not deduped:
                    continue

                check_in, check_out = deduped[0], (deduped[-1] if len(deduped) > 1 else None)
                cutoff = check_in.replace(hour=LATE_CUTOFF_HOUR, minute=LATE_CUTOFF_MINUTE, second=0)
                status = "late" if check_in > cutoff else "present"

                with conn.cursor() as cur:
                    cur.execute("SELECT id FROM attendance_records WHERE employee_id=%s AND date=%s LIMIT 1", (emp_id, day))
                    existing = cur.fetchone()
                    if existing:
                        cur.execute("UPDATE attendance_records SET check_in_time=%s, check_out_time=%s, status=%s WHERE id=%s",
                            (check_in.strftime("%H:%M:%S"), check_out.strftime("%H:%M:%S") if check_out else None, status, existing["id"]))
                        u_staff += 1
                    else:
                        cur.execute("INSERT INTO attendance_records (employee_id, date, check_in_time, check_out_time, status) VALUES (%s, %s, %s, %s, %s)",
                            (emp_id, day, check_in.strftime("%H:%M:%S"), check_out.strftime("%H:%M:%S") if check_out else None, status))
                        i_staff += 1

            conn.commit()
            print(f"[SCHEDULER:aggregate] HR: {i_hr} new, {u_hr} updated | Staff: {i_staff} new, {u_staff} updated | Skipped: {skipped}")
        except Exception as e:
            print(f"[SCHEDULER:aggregate ERROR] {e}")


def start_scheduler(app):
    """Start background jobs. Called once from app.py."""
    scheduler = BackgroundScheduler(daemon=True)
    scheduler.start()

    scheduler.add_job(
        func=lambda: _pull_job(app),
        trigger=IntervalTrigger(minutes=5),
        id="hikvision_pull",
        replace_existing=True,
        max_instances=1,
    )

    scheduler.add_job(
        func=lambda: _aggregate_job(app),
        trigger=IntervalTrigger(minutes=15),
        id="attendance_aggregate",
        replace_existing=True,
        max_instances=1,
    )

    atexit.register(lambda: scheduler.shutdown(wait=False))
    print("[SCHEDULER] started — pull every 5 min, aggregate every 15 min")
    return scheduler