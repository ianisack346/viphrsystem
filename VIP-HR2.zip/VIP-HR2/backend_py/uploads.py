"""uploads.py — mirrors handle_secure_upload() from PHP functions.php"""
import os
import secrets
from werkzeug.utils import secure_filename


def handle_secure_upload(file_storage, target_dir, allowed_ext, allowed_mime, max_bytes):
    if not file_storage or not file_storage.filename:
        raise ValueError("No file uploaded.")

    original = file_storage.filename
    ext = original.rsplit(".", 1)[-1].lower() if "." in original else ""
    if ext not in allowed_ext:
        raise ValueError(f"File type .{ext} not allowed.")

    if file_storage.mimetype and allowed_mime and file_storage.mimetype not in allowed_mime:
        raise ValueError("File MIME type not allowed.")

    file_storage.seek(0, os.SEEK_END)
    size = file_storage.tell()
    file_storage.seek(0)
    if size > max_bytes:
        raise ValueError("File too large.")

    os.makedirs(target_dir, exist_ok=True)
    stored_name = f"{secrets.token_hex(16)}.{ext}"
    full_path = os.path.join(target_dir, stored_name)
    file_storage.save(full_path)

    return {
        "stored_name": stored_name,
        "file_name": secure_filename(original) or original,
        "size": size,
    }