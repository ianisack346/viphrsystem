"""auth.py — session auth, CSRF check, role decorators"""
import time
from functools import wraps
from urllib.parse import urlparse
from flask import session, request, g
from db import db as _db
from helpers import json_error


# ---------- user loading ----------
def current_user():
    uid = session.get("hr_user_id")
    if not uid:
        return None
    if getattr(g, "_cached_user", None) and g._cached_user["id"] == uid:
        return g._cached_user

    conn = _db()
    with conn.cursor() as cur:
        cur.execute(
            "SELECT id, employee_id, username, email, role, full_name, profile_photo, "
            "hr_code, status FROM hr_users WHERE id=%s AND status='active' LIMIT 1",
            (uid,),
        )
        user = cur.fetchone()
    g._cached_user = user
    return user


# ---------- CSRF via Origin header ----------
def _allowed_origins():
    scheme = "https" if request.is_secure else "http"
    return [f"{scheme}://{request.host}"]


def _parse_origin(url: str) -> str:
    p = urlparse(url)
    port = f":{p.port}" if p.port else ""
    return f"{p.scheme}://{p.hostname}{port}"


def check_csrf():
    """PHP-style: only check Origin/Referer for state-changing methods."""
    if request.method not in ("POST", "PUT", "PATCH", "DELETE"):
        return None
    candidate = request.headers.get("Origin") or request.headers.get("Referer")
    if candidate is None:
        return None  # same as PHP: don't hard-fail on absence
    if _parse_origin(candidate) in [_parse_origin(o) for o in _allowed_origins()]:
        return None
    return json_error("Request blocked (origin verification failed).", 403)


# ---------- decorators ----------
def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        user = current_user()
        if not user:
            return json_error("Not authenticated. Please log in again.", 401)
        csrf_fail = check_csrf()
        if csrf_fail:
            return csrf_fail
        g.current_user = user
        return f(*args, **kwargs)
    return wrapper


def role_required(roles):
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            user = current_user()
            if not user:
                return json_error("Not authenticated. Please log in again.", 401)
            csrf_fail = check_csrf()
            if csrf_fail:
                return csrf_fail
            if user["role"] not in roles:
                return json_error("You do not have permission to perform this action.", 403)
            g.current_user = user
            return f(*args, **kwargs)
        return wrapper
    return decorator


# ---------- rate limit ----------
def is_rate_limited(bucket: str, max_attempts: int, window_seconds: int) -> bool:
    try:
        conn = _db()
        now = int(time.time())
        with conn.cursor() as cur:
            cur.execute(
                "SELECT attempts, first_seen FROM login_attempts WHERE bucket=%s LIMIT 1",
                (bucket,),
            )
            row = cur.fetchone()
        if not row:
            return False
        if (now - int(row["first_seen"])) > window_seconds:
            clear_rate_limit(bucket)
            return False
        return int(row["attempts"]) >= max_attempts
    except Exception as e:
        print(f"[rate_limit:check] {e}")
        return False


def record_failed_attempt(bucket: str):
    try:
        conn = _db()
        now = int(time.time())
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO login_attempts (bucket, attempts, first_seen, last_seen)
                VALUES (%s, 1, %s, %s)
                ON DUPLICATE KEY UPDATE
                    attempts   = IF(%s - first_seen > 900, 1, attempts + 1),
                    first_seen = IF(%s - first_seen > 900, %s, first_seen),
                    last_seen  = %s
                """,
                (bucket, now, now, now, now, now, now),
            )
        conn.commit()
    except Exception as e:
        print(f"[rate_limit:record] {e}")


def clear_rate_limit(bucket: str):
    try:
        conn = _db()
        with conn.cursor() as cur:
            cur.execute("DELETE FROM login_attempts WHERE bucket=%s", (bucket,))
        conn.commit()
    except Exception as e:
        print(f"[rate_limit:clear] {e}")