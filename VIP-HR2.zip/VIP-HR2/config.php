<?php
/**
 * config.php
 * Central configuration. Never hardcode real credentials here in production —
 * this reads from environment variables (set in your web server vhost, a
 * .env loaded earlier, or php-fpm pool config) and falls back to safe local
 * defaults only for convenience during first-time setup.
 */

// ---- Environment ----------------------------------------------------
define('APP_ENV', getenv('APP_ENV') ?: 'production'); // 'production' | 'development'

// ---- Database ---------------------------------------------------------
define('DB_HOST', getenv('DB_HOST') ?: '127.0.0.1');
define('DB_PORT', getenv('DB_PORT') ?: '3306');
define('DB_NAME', getenv('DB_NAME') ?: 'fsm_ems');
define('DB_USER', getenv('DB_USER') ?: 'fsm_app');
define('DB_PASS', getenv('DB_PASS') ?: ''); // set via environment, not here

// ---- Uploads ------------------------------------------------------------
define('UPLOAD_ROOT', __DIR__ . '/../uploads');
define('DOC_UPLOAD_DIR', UPLOAD_ROOT . '/documents');
define('PHOTO_UPLOAD_DIR', UPLOAD_ROOT . '/photos');
define('RECRUITMENT_UPLOAD_DIR', UPLOAD_ROOT . '/recruitment');
define('MAX_UPLOAD_BYTES', 50 * 1024 * 1024); // 50MB, matches frontend copy
define('ALLOWED_DOC_EXT', ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'jpg', 'jpeg', 'png']);
define('ALLOWED_DOC_MIME', [
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'image/jpeg',
    'image/png',
]);

// ---- Error handling / reporting -----------------------------------------
error_reporting(E_ALL);
ini_set('log_errors', '1');
ini_set('display_errors', APP_ENV === 'development' ? '1' : '0'); // never leak errors in prod

// ---- Session hardening ---------------------------------------------------
// Must run before session_start(); auth.php calls session_start() after
// including this file, so set the cookie params here.
if (session_status() === PHP_SESSION_NONE) {
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => '',
        'secure' => $secure,      // requires HTTPS in production
        'httponly' => true,       // JS can't read the session cookie
        'samesite' => 'Lax',      // mitigates most CSRF while allowing normal nav
    ]);
    ini_set('session.use_strict_mode', '1');
    ini_set('session.cookie_httponly', '1');
}

// ---- Timezone ----------------------------------------------------------
date_default_timezone_set('Africa/Nairobi'); // EAT, matches Arusha
